from __future__ import annotations
import hashlib,json,os,subprocess,sys,time
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path.cwd(); SUPPORT_REF='artifacts/git-delivery-support/T034-r3-18271be3-f0ae-45bf-9d80-3d830ad21038'; SUPPORT=ROOT/SUPPORT_REF
OUT=SUPPORT/'local-checks/closing-C/attempt-1'; PLAN=SUPPORT/'check-plan.json'; PLAN_SHA='b564d7b7d129051fc1f2fcea17c16d9ba60828db9d2913c33a917b0942d7a4aa'
PARENT='42104732e3fd917d0671cc2bd17f1060a88e0572'; CANDIDATE='ea8763c63e711e5ed87fc3bf7307d11ba286a709'
CHECKS=[
 ('bootstrap_check',['python','-B','tools/ci/bootstrap_check.py']),
 ('test_bootstrap_check',['python','-B','tools/ci/test_bootstrap_check.py']),
 ('delivery_policy_plan',['python','-B','tools/ci/delivery_policy.py','check-plan','--plan',str(PLAN),'--sha256',PLAN_SHA]),
 ('spec_check',['python','-B','tools/spec_check/check.py']),
 ('test_spec_check',['python','-B','tools/spec_check/test_spec_check.py']),
 ('test_delivery_policy',['python','-B','tools/ci/test_delivery_policy.py']),
 ('test_checkpoint_digest',['python','-B','tools/ci/test_checkpoint_digest.py']),
 ('check_gofmt',['python','-B','tools/ci/check_gofmt.py']),
 ('go_test_all',['go','test','./...']),
 ('go_vet_all',['go','vet','./...']),
 ('go_build_all',['go','build','./...']),
]
def git(*args): return subprocess.check_output(['git',*args],cwd=ROOT,text=True,encoding='ascii').strip()
def stamp(): return datetime.now(timezone.utc).isoformat(timespec='microseconds').replace('+00:00','Z')
def digest(data): return hashlib.sha256(data).hexdigest()
if git('rev-parse','HEAD')!=CANDIDATE or git('rev-parse','HEAD^')!=PARENT or git('branch','--show-current')!='main': raise SystemExit('closing checks require exact C with direct parent P on main')
if subprocess.run(['git','diff','--quiet'],cwd=ROOT).returncode or subprocess.run(['git','diff','--cached','--quiet'],cwd=ROOT).returncode: raise SystemExit('tracked worktree/index must be clean')
plan_bytes=PLAN.read_bytes()
if digest(plan_bytes)!=PLAN_SHA: raise SystemExit('frozen check plan digest mismatch')
if OUT.exists(): raise SystemExit('preserve existing closing attempt-1')
OUT.mkdir(parents=True)
tree=git('rev-parse','HEAD^{tree}'); rows=[]
for index,(name,argv) in enumerate(CHECKS,1):
 started=stamp(); timer=time.monotonic(); proc=subprocess.run(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=os.environ.copy(),check=False); duration=round(time.monotonic()-timer,3); completed=stamp()
 (OUT/f'{name}.stdout.txt').write_bytes(proc.stdout); (OUT/f'{name}.stderr.txt').write_bytes(proc.stderr)
 rows.append({'name':name,'argv':argv,'started_at_utc':started,'completed_at_utc':completed,'duration_seconds':duration,'exit_code':proc.returncode,'stdout_sha256':digest(proc.stdout),'stderr_sha256':digest(proc.stderr)})
 print(f"{'PASS' if proc.returncode==0 else 'FAIL'} {index}/{len(CHECKS)} {name}",flush=True)
 if proc.returncode: break
if git('rev-parse','HEAD')!=CANDIDATE or git('rev-parse','HEAD^{tree}')!=tree or git('write-tree')!=tree or subprocess.run(['git','diff','--quiet'],cwd=ROOT).returncode or subprocess.run(['git','diff','--cached','--quiet'],cwd=ROOT).returncode: raise SystemExit('closing candidate tree changed during checks')
passed=sum(row['exit_code']==0 for row in rows)
result={'format_version':1,'kind':'local_check_execution','task_id':'T034','task_revision':3,'delivery_id':'18271be3-f0ae-45bf-9d80-3d830ad21038','phase':'closing','base_sha':PARENT,'candidate_sha':CANDIDATE,'tested_tree_sha':tree,'check_plan_sha256':PLAN_SHA,'check_count':len(CHECKS),'executed_checks':len(rows),'passed_checks':passed,'failed_checks':len(rows)-passed,'result':'PASS' if len(rows)==len(CHECKS) and passed==len(CHECKS) else 'FAIL','checks':rows}
summary=json.dumps(result,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()+b'\n'; (OUT/'summary.json').write_bytes(summary)
receipt={k:v for k,v in result.items() if k not in ('checks','executed_checks')}; receipt.update({'kind':'local_check_receipt','runner_summary_ref':f'{SUPPORT_REF}/local-checks/closing-C/attempt-1/summary.json','runner_summary_sha256':digest(summary),'created_at_utc':stamp(),'checks':rows}); (OUT/'closing-receipt.json').write_text(json.dumps(receipt,sort_keys=True,separators=(',',':'),ensure_ascii=False)+'\n',encoding='utf-8')
print(f"RESULT={result['result']} {passed}/{len(CHECKS)} candidate={CANDIDATE} tree={tree} summary_sha256={digest(summary)}",flush=True); sys.exit(0 if result['result']=='PASS' else 1)
