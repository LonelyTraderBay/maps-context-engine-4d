from pathlib import Path
src=Path('artifacts/git-delivery-support/T035-r1-e01d3e3d-2d59-4be8-ad95-937d4436bb75/collect_payload_ready_ci_T035_final.py').read_text(encoding='utf-8')
repl={
 'TASK = "T035"':'TASK = "T034"','REVISION = 1':'REVISION = 3',
 'DELIVERY = "e01d3e3d-2d59-4be8-ad95-937d4436bb75"':'DELIVERY = "18271be3-f0ae-45bf-9d80-3d830ad21038"',
 'BASE = "8548570c0c3d56f8900b09f53c45f302d6776f3f"':'BASE = "ee14e15f0169a0a0ec8c4eafd648dbdbc6a2fa95"',
 'SUBJECT = "b398d4fcf211aecc200af62e7326fee429067eff"':'SUBJECT = "42104732e3fd917d0671cc2bd17f1060a88e0572"',
 'PLAN_SHA = "4613709c969881e2d059b9ca372931b372dff37e7a6cc9ddeed800b5dbb9b615"':'PLAN_SHA = "b564d7b7d129051fc1f2fcea17c16d9ba60828db9d2913c33a917b0942d7a4aa"',
 'f"artifacts/git-delivery-support/{TASK}-r1-{DELIVERY}"':'f"artifacts/git-delivery-support/{TASK}-r3-{DELIVERY}"',
 'collector/payload-ready-final':'collector/p3',
}
for a,b in repl.items():
 if a not in src:raise SystemExit(f'missing final payload collector field: {a}')
 src=src.replace(a,b)
Path('artifacts/git-delivery-support/T034-r3-18271be3-f0ae-45bf-9d80-3d830ad21038/collect_payload_ready_ci_T034_final.py').write_text(src,encoding='utf-8',newline='\n')