from pathlib import Path
source=Path('artifacts/git-delivery-support/T035-r1-e01d3e3d-2d59-4be8-ad95-937d4436bb75/collect_code_payload_ci_T035.py').read_text(encoding='utf-8')
replacements={
 'TASK = "T035"':'TASK = "T034"',
 'REVISION = 1':'REVISION = 3',
 'DELIVERY = "e01d3e3d-2d59-4be8-ad95-937d4436bb75"':'DELIVERY = "18271be3-f0ae-45bf-9d80-3d830ad21038"',
 'BASE = "49da628828d2bc700c105ffd24454edd15fcebfe"':'BASE = "e32f7daa80835ef9bca5978b636909b47bd4d4e6"',
 'SUBJECT = "8548570c0c3d56f8900b09f53c45f302d6776f3f"':'SUBJECT = "ee14e15f0169a0a0ec8c4eafd648dbdbc6a2fa95"',
 'PLAN_SHA = "4613709c969881e2d059b9ca372931b372dff37e7a6cc9ddeed800b5dbb9b615"':'PLAN_SHA = "b564d7b7d129051fc1f2fcea17c16d9ba60828db9d2913c33a917b0942d7a4aa"',
 'T035-r1-e01d3e3d-2d59-4be8-ad95-937d4436bb75':'T034-r3-18271be3-f0ae-45bf-9d80-3d830ad21038',
 'payload-code-attempt-1':'payload-code-confirmation-1',
 'collector/payload-code':'collector/payload-code-confirmation-1',
}
for old,new in replacements.items():
 if old not in source: raise SystemExit(f'missing collector template field: {old}')
 source=source.replace(old,new)
Path('artifacts/git-delivery-support/T034-r3-18271be3-f0ae-45bf-9d80-3d830ad21038/collect_payload_code_ci_T034.py').write_text(source,encoding='utf-8',newline='\n')