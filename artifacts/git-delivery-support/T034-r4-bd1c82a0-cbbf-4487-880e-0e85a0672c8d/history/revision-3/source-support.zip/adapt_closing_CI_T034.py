from pathlib import Path
src=Path('artifacts/git-delivery-support/T035-r1-e01d3e3d-2d59-4be8-ad95-937d4436bb75/collect_closing_CI_T035.py').read_text(encoding='utf-8')
repl={
 'TASK = "T035"':'TASK = "T034"','REVISION = 1':'REVISION = 3',
 'DELIVERY = "e01d3e3d-2d59-4be8-ad95-937d4436bb75"':'DELIVERY = "18271be3-f0ae-45bf-9d80-3d830ad21038"',
 'BASE = "b398d4fcf211aecc200af62e7326fee429067eff"':'BASE = "42104732e3fd917d0671cc2bd17f1060a88e0572"',
 'SUBJECT = "1c0f0b6f969e8b44a027cd1391a1003b66f51dff"':'SUBJECT = "ea8763c63e711e5ed87fc3bf7307d11ba286a709"',
 'PLAN_SHA = "4613709c969881e2d059b9ca372931b372dff37e7a6cc9ddeed800b5dbb9b615"':'PLAN_SHA = "b564d7b7d129051fc1f2fcea17c16d9ba60828db9d2913c33a917b0942d7a4aa"',
 'f"artifacts/git-delivery-support/{TASK}-r1-{DELIVERY}"':'f"artifacts/git-delivery-support/{TASK}-r3-{DELIVERY}"',
 'collector/c"':'collector/c3"',
}
for a,b in repl.items():
 if a not in src:raise SystemExit(f'missing closing CI template: {a}')
 src=src.replace(a,b)
Path('artifacts/git-delivery-support/T034-r3-18271be3-f0ae-45bf-9d80-3d830ad21038/collect_closing_CI_T034.py').write_text(src,encoding='utf-8',newline='\n')