from pathlib import Path
src=Path('artifacts/git-delivery-support/T035-r1-e01d3e3d-2d59-4be8-ad95-937d4436bb75/run_closing_checks_T035.py').read_text(encoding='utf-8')
repl={
 'T035-r1-e01d3e3d-2d59-4be8-ad95-937d4436bb75':'T034-r3-18271be3-f0ae-45bf-9d80-3d830ad21038',
 'PLAN_SHA=\'4613709c969881e2d059b9ca372931b372dff37e7a6cc9ddeed800b5dbb9b615\'':'PLAN_SHA=\'b564d7b7d129051fc1f2fcea17c16d9ba60828db9d2913c33a917b0942d7a4aa\'',
 'PARENT=\'b398d4fcf211aecc200af62e7326fee429067eff\'; CANDIDATE=\'1c0f0b6f969e8b44a027cd1391a1003b66f51dff\'':'PARENT=\'42104732e3fd917d0671cc2bd17f1060a88e0572\'; CANDIDATE=\'ea8763cf7d61e8c2932132986082a5f6db20f7f1\'',
 "'T035','task_revision':1,'delivery_id':'e01d3e3d-2d59-4be8-ad95-937d4436bb75'":"'T034','task_revision':3,'delivery_id':'18271be3-f0ae-45bf-9d80-3d830ad21038'",
}
for a,b in repl.items():
 if a not in src: raise SystemExit(f'missing closing runner field: {a}')
 src=src.replace(a,b)
Path('artifacts/git-delivery-support/T034-r3-18271be3-f0ae-45bf-9d80-3d830ad21038/run_closing_checks_T034.py').write_text(src,encoding='utf-8',newline='\n')