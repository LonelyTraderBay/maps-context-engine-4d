import re
from pathlib import Path
src=Path('artifacts/git-delivery-support/T035-r1-e01d3e3d-2d59-4be8-ad95-937d4436bb75/prepare_archive_T035.py').read_text(encoding='utf-8')
repl={
 "ROOT=Path.cwd(); TASK='T035'; REV=1; DELIVERY='e01d3e3d-2d59-4be8-ad95-937d4436bb75'; PRIORITY='P0'":"ROOT=Path.cwd(); TASK='T034'; REV=3; DELIVERY='18271be3-f0ae-45bf-9d80-3d830ad21038'; PRIORITY='P0'",
 "BASE='49da628828d2bc700c105ffd24454edd15fcebfe'":"BASE='e32f7daa80835ef9bca5978b636909b47bd4d4e6'",
 "PAYLOAD=PAYLOAD_COMMITS[-1]; CLOSING='1c0f0b6f969e8b44a027cd1391a1003b66f51dff'":"PAYLOAD=PAYLOAD_COMMITS[-1]; CLOSING='ea8763c63e711e5ed87fc3bf7307d11ba286a709'",
 "PLAN_SHA='4613709c969881e2d059b9ca372931b372dff37e7a6cc9ddeed800b5dbb9b615'":"PLAN_SHA='b564d7b7d129051fc1f2fcea17c16d9ba60828db9d2913c33a917b0942d7a4aa'",
 "SUPPORT_REF=f'artifacts/git-delivery-support/{TASK}-r1-{DELIVERY}'":"SUPPORT_REF=f'artifacts/git-delivery-support/{TASK}-r3-{DELIVERY}'",
 "archive-view/ci/payload-ready-final/payload-observation.archive.json":"archive-view/ci/payload-ready/payload-observation.archive.json",
}
for a,b in repl.items():
 if a not in src:raise SystemExit(f'missing archive template: {a}')
 src=src.replace(a,b)
src=re.sub(r"PAYLOAD_COMMITS=\[.*?\]\n", "PAYLOAD_COMMITS=['b24ce65a31bf98cd25e4fb72bb1acd09225fcad5','d1780b679521a81ce6df5573e65b33c888006820','5b61a5f2ab2ebedd6ba488b314189b754b3d2a9a','ab5882941644ed5b7acd2e94b0088304c99db2ef','834c041a15c391c1f197dd45665be11dbcdcb785','ee14e15f0169a0a0ec8c4eafd648dbdbc6a2fa95','42104732e3fd917d0671cc2bd17f1060a88e0572']\n",src,count=1,flags=re.S)
needle='copy_tree(SUPPORT,SUPPORT_REF)\n'
insert="copy_tree(SUPPORT,SUPPORT_REF)\ncopy_tree(ROOT/'artifacts/acceptance/T034/runs/windows-20261019-payload-ee14e15','artifacts/acceptance/T034/runs/windows-20261019-payload-ee14e15')\n"
if needle not in src:raise SystemExit('support copy call not found')
src=src.replace(needle,insert,1)
Path('artifacts/git-delivery-support/T034-r3-18271be3-f0ae-45bf-9d80-3d830ad21038/prepare_archive_T034.py').write_text(src,encoding='utf-8',newline='\n')