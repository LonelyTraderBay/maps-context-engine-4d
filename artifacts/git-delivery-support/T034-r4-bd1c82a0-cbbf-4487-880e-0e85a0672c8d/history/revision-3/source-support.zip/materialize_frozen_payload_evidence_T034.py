from __future__ import annotations
import hashlib, json, shutil, subprocess
from pathlib import Path
ROOT=Path.cwd()
SUPPORT_REF='artifacts/git-delivery-support/T034-r3-18271be3-f0ae-45bf-9d80-3d830ad21038'
SUPPORT=ROOT/SUPPORT_REF
ATTEMPT=SUPPORT/'local-checks/payload/attempt-2'
OUT=SUPPORT/'local-checks/payload-frozen'
PLAN_REF=f'{SUPPORT_REF}/check-plan.json'
EXPECTED='ee14e15f0169a0a0ec8c4eafd648dbdbc6a2fa95'
PLAN_SHA='b564d7b7d129051fc1f2fcea17c16d9ba60828db9d2913c33a917b0942d7a4aa'
def sha(data: bytes)->str:return hashlib.sha256(data).hexdigest()
def write(path: Path, value: object)->bytes:
    data=json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')
    path.parent.mkdir(parents=True,exist_ok=True); path.write_bytes(data); return data
if OUT.exists(): raise SystemExit('payload-frozen evidence exists; preserve and inspect')
if subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()!=EXPECTED: raise SystemExit('HEAD changed from exact payload SHA')
plan_path=SUPPORT/'check-plan.json'; plan_bytes=plan_path.read_bytes()
if sha(plan_bytes)!=PLAN_SHA: raise SystemExit('frozen plan hash mismatch')
plan=json.loads(plan_bytes.decode('utf-8','strict'))
summary=json.loads((ATTEMPT/'summary.json').read_text(encoding='utf-8'))
if summary.get('result')!='PASS' or summary.get('subject_sha')!=EXPECTED or summary.get('check_plan_sha256')!=PLAN_SHA or len(summary.get('checks',[]))!=11 or any(x.get('exit_code')!=0 for x in summary['checks']): raise SystemExit('frozen-plan attempt is not exact PASS 11/11')
OUT.mkdir(parents=True)
rows=[]
for item, frozen_ref in zip(summary['checks'], plan['local_check_refs'], strict=True):
    name=item['name']; source=SUPPORT/item['log']; data=source.read_bytes()
    if sha(data)!=item['log_sha256']: raise SystemExit(f'log digest mismatch: {name}')
    log_ref=f'{SUPPORT_REF}/local-checks/payload-frozen/logs/{name}.log'
    target=ROOT/log_ref; target.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(source,target)
    record={
      'format_version':1,'kind':'local_check','command_ref':' '.join(item['argv']),
      'task_id':'T034','task_revision':3,'delivery_id':'18271be3-f0ae-45bf-9d80-3d830ad21038',
      'phase':'payload','revision':EXPECTED,'result':'PASS','execution_verified':True,
      'log_refs':[log_ref],'reused_from_ref':None,
    }
    record_ref=f'{SUPPORT_REF}/local-checks/payload-frozen/records/{Path(frozen_ref).name}'
    record_bytes=write(ROOT/record_ref,record)
    rows.append({'check':item['name'],'command_ref':' '.join(item['argv']),'exit_code':0,
                 'frozen_plan_ref':frozen_ref,'record_ref':record_ref,'record_sha256':sha(record_bytes),
                 'log_ref':log_ref,'log_sha256':sha(data),'started_at_utc':item['started_at_utc'],
                 'completed_at_utc':item['completed_at_utc']})
final_summary={
 'format_version':1,'kind':'local_check_summary','delivery_id':'18271be3-f0ae-45bf-9d80-3d830ad21038',
 'task_id':'T034','task_revision':3,'phase':'payload','base_sha':'e32f7daa80835ef9bca5978b636909b47bd4d4e6',
 'candidate_sha':EXPECTED,'candidate_tree_sha':summary['tree_sha'],'check_plan_ref':PLAN_REF,
 'check_plan_sha256':PLAN_SHA,'result':'PASS','check_count':11,'executed_checks':11,'passed_checks':11,'failed_checks':0,
 'attempt_ref':f'{SUPPORT_REF}/local-checks/payload/attempt-2/summary.json','checks':rows}
summary_bytes=write(OUT/'summary.json',final_summary)
receipt={
 'format_version':1,'kind':'local_check_receipt','delivery_id':'18271be3-f0ae-45bf-9d80-3d830ad21038',
 'task_id':'T034','task_revision':3,'phase':'payload','base_sha':'e32f7daa80835ef9bca5978b636909b47bd4d4e6',
 'candidate_sha':EXPECTED,'candidate_tree_sha':summary['tree_sha'],'check_plan_ref':PLAN_REF,'check_plan_sha256':PLAN_SHA,
 'result':'PASS','check_count':11,'passed_checks':11,'failed_checks':0,
 'runner_summary_ref':f'{SUPPORT_REF}/local-checks/payload-frozen/summary.json',
 'runner_summary_sha256':sha(summary_bytes),'checks':rows}
receipt_bytes=write(OUT/'receipt.json',receipt)
print(json.dumps({'result':'PASS','candidate_sha':EXPECTED,'plan_sha256':PLAN_SHA,'checks':11,'summary_sha256':sha(summary_bytes),'receipt_sha256':sha(receipt_bytes)},sort_keys=True))