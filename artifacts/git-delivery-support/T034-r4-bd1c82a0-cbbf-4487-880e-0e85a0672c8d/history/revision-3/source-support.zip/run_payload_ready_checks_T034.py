from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path.cwd()
SUPPORT_REF = "artifacts/git-delivery-support/T034-r3-18271be3-f0ae-45bf-9d80-3d830ad21038"
SUPPORT = ROOT / SUPPORT_REF
PLAN = SUPPORT / "check-plan.json"
PLAN_SHA = "b564d7b7d129051fc1f2fcea17c16d9ba60828db9d2913c33a917b0942d7a4aa"
TASK = "T034"
REVISION = 3
DELIVERY = "18271be3-f0ae-45bf-9d80-3d830ad21038"
BASE = "e32f7daa80835ef9bca5978b636909b47bd4d4e6"
EXPECTED_HEAD = "42104732e3fd917d0671cc2bd17f1060a88e0572"
EXPECTED_PARENT = "ee14e15f0169a0a0ec8c4eafd648dbdbc6a2fa95"
ATTEMPT = SUPPORT / "local-checks/payload-ready/attempt-1"
RECORDS = SUPPORT / "local-checks/payload-ready/records"
LOGS = SUPPORT / "local-checks/payload-ready/logs"


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def write_json(path: Path, value: object) -> bytes:
    data = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    return data


def git(*args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True, encoding="utf-8").strip()


def main() -> int:
    if ATTEMPT.exists() or RECORDS.exists() or LOGS.exists():
        raise SystemExit("payload local-check output already exists; preserve and inspect before retry")
    head = git("rev-parse", "HEAD")
    if not head.startswith(EXPECTED_HEAD):
        raise SystemExit(f"HEAD is not T033 payload candidate {EXPECTED_HEAD}: {head}")
    if git("rev-parse", f"{head}^1") != EXPECTED_PARENT:
        raise SystemExit("payload commit parent does not match the ordered P1 commit")
    if git("status", "--porcelain", "--untracked-files=no"):
        raise SystemExit("tracked worktree is not clean at the frozen payload candidate")
    plan_bytes = PLAN.read_bytes()
    if digest(plan_bytes) != PLAN_SHA:
        raise SystemExit("frozen T033 check plan digest mismatch")
    plan = json.loads(plan_bytes.decode("utf-8", "strict"))
    if plan.get("local_check_refs") != [
        "local-checks/allocation/records/bootstrap.json",
        "local-checks/allocation/records/bootstrap-fixtures.json",
        "local-checks/allocation/records/delivery-plan.json",
        "local-checks/allocation/records/spec-check.json",
        "local-checks/allocation/records/spec-check-fixtures.json",
        "local-checks/allocation/records/delivery-policy-fixtures.json",
        "local-checks/allocation/records/checkpoint-digest-fixtures.json",
        "local-checks/allocation/records/go-format.json",
        "local-checks/allocation/records/go-test.json",
        "local-checks/allocation/records/go-vet.json",
        "local-checks/allocation/records/go-build.json",
    ]:
        raise SystemExit("frozen local check references changed")
    commands = [
        ("bootstrap", "python -B tools/ci/bootstrap_check.py", ["python", "-B", "tools/ci/bootstrap_check.py"]),
        ("bootstrap-fixtures", "python -B tools/ci/test_bootstrap_check.py", ["python", "-B", "tools/ci/test_bootstrap_check.py"]),
        ("delivery-plan", "python -B tools/ci/delivery_policy.py check-plan", [
            "python", "-B", "tools/ci/delivery_policy.py", "check-plan", "--plan", str(PLAN), "--sha256", PLAN_SHA,
        ]),
        ("spec-check", "python -B tools/spec_check/check.py", ["python", "-B", "tools/spec_check/check.py"]),
        ("spec-check-fixtures", "python -B tools/spec_check/test_spec_check.py", ["python", "-B", "tools/spec_check/test_spec_check.py"]),
        ("delivery-policy-fixtures", "python -B tools/ci/test_delivery_policy.py", ["python", "-B", "tools/ci/test_delivery_policy.py"]),
        ("checkpoint-digest-fixtures", "python -B tools/ci/test_checkpoint_digest.py", ["python", "-B", "tools/ci/test_checkpoint_digest.py"]),
        ("go-format", "python -B tools/ci/check_gofmt.py", ["python", "-B", "tools/ci/check_gofmt.py"]),
        ("go-test", "go test ./...", ["go", "test", "./..."]),
        ("go-vet", "go vet ./...", ["go", "vet", "./..."]),
        ("go-build", "go build ./...", ["go", "build", "./..."]),
    ]
    ATTEMPT.mkdir(parents=True)
    checks = []
    for name, command_ref, argv in commands:
        start = datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")
        clock = time.perf_counter()
        try:
            completed = subprocess.run(argv, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=1800, check=False)
            exit_code = completed.returncode
            stdout, stderr = completed.stdout, completed.stderr
        except OSError as exc:
            exit_code = 127
            stdout = b""
            stderr = str(exc).encode("utf-8", "replace")
        except subprocess.TimeoutExpired as exc:
            exit_code = 124
            stdout = exc.stdout or b""
            stderr = exc.stderr or b""
        duration = round(time.perf_counter() - clock, 3)
        completed_at = datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")
        prefix = ATTEMPT / "logs" / name
        prefix.parent.mkdir(parents=True, exist_ok=True)
        (prefix.with_suffix(".stdout.txt")).write_bytes(stdout)
        (prefix.with_suffix(".stderr.txt")).write_bytes(stderr)
        transcript = {
            "command_ref": command_ref, "argv": argv, "started_at_utc": start,
            "completed_at_utc": completed_at, "duration_seconds": duration,
            "exit_code": exit_code, "stdout_bytes": len(stdout), "stdout_sha256": digest(stdout),
            "stderr_bytes": len(stderr), "stderr_sha256": digest(stderr),
        }
        transcript_bytes = write_json(prefix.with_suffix(".transcript.json"), transcript)
        checks.append({
            "name": name, "command_ref": command_ref, "argv": argv, "exit_code": exit_code,
            "duration_seconds": duration, "stdout_sha256": digest(stdout), "stderr_sha256": digest(stderr),
            "transcript_sha256": digest(transcript_bytes),
            "attempt_log_refs": [
                (prefix.with_suffix(".stdout.txt")).relative_to(SUPPORT).as_posix(),
                (prefix.with_suffix(".stderr.txt")).relative_to(SUPPORT).as_posix(),
                (prefix.with_suffix(".transcript.json")).relative_to(SUPPORT).as_posix(),
            ],
        })
        print(f"{name}: exit={exit_code} duration={duration}s", flush=True)
        if exit_code:
            print(stderr.decode("utf-8", "replace")[-4000:], flush=True)
            print(stdout.decode("utf-8", "replace")[-4000:], flush=True)

    tree_sha = git("rev-parse", "HEAD^{tree}")
    passed = sum(row["exit_code"] == 0 for row in checks)
    summary = {
        "format_version": 1, "kind": "local_check_summary", "delivery_id": DELIVERY,
        "task_id": TASK, "task_revision": REVISION, "phase": "payload", "base_sha": BASE,
        "candidate_sha": head, "candidate_tree_sha": tree_sha, "check_plan_sha256": PLAN_SHA,
        "created_at_utc": datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z"),
        "check_count": len(commands), "executed_checks": len(checks), "passed_checks": passed,
        "failed_checks": len(checks) - passed, "result": "PASS" if passed == len(commands) else "FAIL",
        "checkout_binding": {"tracked_worktree_clean": True, "preexisting_untracked_paths_preserved": True},
        "environment_note": "The shared checkout contains pre-existing untracked artifact fixtures; go test ./... includes those fixture packages locally. Hosted checks bind the exact committed SHA in a clean checkout.",
        "checks": checks,
    }
    attempt_summary = ATTEMPT / "summary.json"
    write_json(attempt_summary, summary)
    if summary["result"] != "PASS":
        print(f"payload local checks FAILED; retained at {attempt_summary}", flush=True)
        return 1

    RECORDS.mkdir(parents=True)
    LOGS.mkdir(parents=True)
    local_rows = []
    for row, local_ref in zip(checks, plan["local_check_refs"], strict=True):
        name = row["name"]
        source_prefix = ATTEMPT / "logs" / name
        final_names = [f"{name}.stdout.txt", f"{name}.stderr.txt", f"{name}.transcript.json"]
        final_refs = []
        for source, final_name in zip((source_prefix.with_suffix(".stdout.txt"), source_prefix.with_suffix(".stderr.txt"), source_prefix.with_suffix(".transcript.json")), final_names, strict=True):
            destination = LOGS / final_name
            shutil.copyfile(source, destination)
            final_refs.append((destination.relative_to(ROOT)).as_posix())
        record = {
            "format_version": 1, "kind": "local_check", "command_ref": row["command_ref"],
            "task_id": TASK, "task_revision": REVISION, "delivery_id": DELIVERY,
            "phase": "payload", "revision": head, "result": "PASS", "execution_verified": True,
            "log_refs": final_refs, "reused_from_ref": None,
        }
        output_ref = f"local-checks/payload-ready/records/{Path(local_ref).name}"
        record_bytes = write_json(SUPPORT / output_ref, record)
        local_rows.append({
            "check": name, "command_ref": row["command_ref"], "exit_code": row["exit_code"],
            "record_ref": f"{SUPPORT_REF}/{output_ref}", "record_sha256": digest(record_bytes),
            "stdout_sha256": row["stdout_sha256"], "stderr_sha256": row["stderr_sha256"],
            "transcript_sha256": row["transcript_sha256"],
        })
    summary["checks"] = local_rows
    summary_bytes = write_json(SUPPORT / "local-checks/payload-ready/summary.json", summary)
    receipt = {
        "format_version": 1, "kind": "local_check_receipt", "delivery_id": DELIVERY,
        "task_id": TASK, "task_revision": REVISION, "phase": "payload", "base_sha": BASE,
        "candidate_sha": head, "candidate_tree_sha": tree_sha, "check_plan_sha256": PLAN_SHA,
        "created_at_utc": summary["created_at_utc"], "check_count": len(commands),
        "passed_checks": passed, "failed_checks": 0, "result": "PASS",
        "runner_summary_ref": f"{SUPPORT_REF}/local-checks/payload-ready/summary.json",
        "runner_summary_sha256": digest(summary_bytes), "checks": local_rows,
    }
    receipt_bytes = write_json(SUPPORT / "local-checks/payload-ready/receipt.json", receipt)
    print(json.dumps({"result": "PASS", "passed": passed, "candidate_sha": head, "tree_sha": tree_sha,
                      "summary_sha256": digest(summary_bytes), "receipt_sha256": digest(receipt_bytes)}, sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
