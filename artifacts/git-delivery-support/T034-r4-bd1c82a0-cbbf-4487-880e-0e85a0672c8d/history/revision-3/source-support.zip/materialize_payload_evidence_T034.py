from __future__ import annotations
import hashlib, json, subprocess, time
from datetime import datetime, timezone
from pathlib import Path
ROOT = Path.cwd()
SUPPORT_REF = Path('artifacts/git-delivery-support/T034-r3-18271be3-f0ae-45bf-9d80-3d830ad21038')
SUPPORT = ROOT / SUPPORT_REF
PLAN = SUPPORT / 'check-plan.json'
PAYLOAD_PLAN = SUPPORT / 'payload-check-plan.json'
LOCAL_ROOT = SUPPORT / 'local-checks/payload'
ATTEMPT = LOCAL_ROOT / 'attempt-1'
RECORDS = LOCAL_ROOT / 'records'
EXPECTED = 'ee14e15f0169a0a0ec8c4eafd648dbdbc6a2fa95'
BASE = 'e32f7daa80835ef9bca5978b636909b47bd4d4e6'
DELIVERY = '18271be3-f0ae-45bf-9d80-3d830ad21038'
PLAN_BYTES = PLAN.read_bytes()

def digest(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()

def write_json(path: Path, value: object) -> bytes:
    data = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    return data

def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec='microseconds').replace('+00:00', 'Z')

if subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip() != EXPECTED:
    raise SystemExit('payload evidence subject is not the checked code payload')
if hashlib.sha256(PLAN_BYTES).hexdigest() != 'b564d7b7d129051fc1f2fcea17c16d9ba60828db9d2913c33a917b0942d7a4aa':
    raise SystemExit('allocation check plan changed')
if (RECORDS.exists() and any(RECORDS.iterdir())) or (LOCAL_ROOT / 'receipt.json').exists():
    raise SystemExit('payload check evidence already exists; preserve and inspect')
summary_path = ATTEMPT / 'summary.json'
summary = json.loads(summary_path.read_text(encoding='utf-8'))
if summary.get('subject_sha') != EXPECTED or summary.get('result') != 'PASS' or len(summary.get('checks', [])) != 11:
    raise SystemExit('11-check attempt is missing or failed')

plan = json.loads(PLAN_BYTES.decode('utf-8'))
plan['local_check_refs'] = [ref.replace('local-checks/allocation/records/', 'local-checks/payload/records/') for ref in plan['local_check_refs']]
plan_bytes = json.dumps(plan, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
if PAYLOAD_PLAN.exists() and PAYLOAD_PLAN.read_bytes() != plan_bytes:
    raise SystemExit('existing payload check plan differs; preserve and inspect')
if not PAYLOAD_PLAN.exists():
    PAYLOAD_PLAN.write_bytes(plan_bytes)
plan_sha = digest(plan_bytes)

check = next(row for row in summary['checks'] if row['name'] == 'delivery_policy_plan')
argv = ['python','-B','tools/ci/delivery_policy.py','check-plan','--plan',str(PAYLOAD_PLAN),'--sha256',plan_sha]
started = now(); tick = time.perf_counter()
result = subprocess.run(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120,check=False)
completed = now(); duration = round(time.perf_counter()-tick,3)
log_path = ATTEMPT / 'delivery_policy_plan.log'
log_path.write_bytes(result.stdout)
if result.returncode != 0:
    raise SystemExit(f'payload check plan validation failed: {result.stdout.decode("utf-8","replace")}')
check.update({'argv':argv,'started_at_utc':started,'completed_at_utc':completed,'duration_seconds':duration,
              'exit_code':0,'log':log_path.relative_to(SUPPORT).as_posix(),'log_sha256':digest(result.stdout)})
summary['check_plan_sha256'] = plan_sha
summary_path.write_text(json.dumps(summary,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')

RECORDS.mkdir(parents=True, exist_ok=True)
local_names = [Path(ref).name for ref in plan['local_check_refs']]
check_names = {
    'python -B tools/ci/bootstrap_check.py': 'bootstrap_check',
    'python -B tools/ci/test_bootstrap_check.py': 'test_bootstrap_check',
    'python -B tools/ci/delivery_policy.py check-plan': 'delivery_policy_plan',
    'python -B tools/spec_check/check.py': 'spec_check',
    'python -B tools/spec_check/test_spec_check.py': 'test_spec_check',
    'python -B tools/ci/test_delivery_policy.py': 'test_delivery_policy',
    'python -B tools/ci/test_checkpoint_digest.py': 'test_checkpoint_digest',
    'python -B tools/ci/check_gofmt.py': 'go_format',
    'go test ./...': 'go_test_all',
    'go vet ./...': 'go_vet_all',
    'go build ./...': 'go_build_all',
}
by_name = {row['name']: row for row in summary['checks']}
local_rows = []
for index, command_ref in enumerate(dict.fromkeys(command for check_item in plan['checks'] for command in check_item['command_refs'])):
    row = by_name.get(check_names[command_ref])
    if row is None or row['exit_code'] != 0:
        raise SystemExit(f'missing PASS record for command {command_ref}')
    name = local_names[index]
    log = SUPPORT / row['log']
    transcript_path = ATTEMPT / (Path(row['log']).stem + '.transcript.json')
    transcript = {'format_version':1,'command_ref':command_ref,'argv':row['argv'],
                  'started_at_utc':row['started_at_utc'],'completed_at_utc':row['completed_at_utc'],
                  'duration_seconds':row['duration_seconds'],'exit_code':row['exit_code'],
                  'log_sha256':digest(log.read_bytes())}
    transcript_bytes = write_json(transcript_path,transcript)
    record = {'format_version':1,'kind':'local_check','command_ref':command_ref,'task_id':'T034',
              'task_revision':3,'delivery_id':DELIVERY,'phase':'payload','revision':EXPECTED,
              'result':'PASS','execution_verified':True,
              'log_refs':[(SUPPORT_REF / log.relative_to(SUPPORT)).as_posix(),
                          (SUPPORT_REF / transcript_path.relative_to(SUPPORT)).as_posix()],
              'reused_from_ref':None}
    record_path = RECORDS / name
    record_bytes = write_json(record_path,record)
    local_rows.append({'command_ref':command_ref,'record_ref':(SUPPORT_REF / record_path.relative_to(SUPPORT)).as_posix(),
                       'record_sha256':digest(record_bytes),'log_sha256':digest(log.read_bytes()),
                       'transcript_sha256':digest(transcript_bytes)})

payload_summary = {'format_version':1,'kind':'local_check_summary','task_id':'T034','task_revision':3,
                   'delivery_id':DELIVERY,'phase':'payload','base_sha':BASE,'candidate_sha':EXPECTED,
                   'candidate_tree_sha':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=ROOT,text=True).strip(),
                   'check_plan_ref':(SUPPORT_REF / PAYLOAD_PLAN.relative_to(SUPPORT)).as_posix(),
                   'check_plan_sha256':plan_sha,'result':'PASS','planned_checks':11,'completed_checks':11,
                   'passed_checks':11,'failed_checks':0,'checks':local_rows,
                   'attempt_ref':(SUPPORT_REF / summary_path.relative_to(SUPPORT)).as_posix()}
payload_summary_bytes = write_json(LOCAL_ROOT / 'summary.json',payload_summary)
receipt = {'format_version':1,'kind':'local_check_receipt','task_id':'T034','task_revision':3,
           'delivery_id':DELIVERY,'phase':'payload','base_sha':BASE,'candidate_sha':EXPECTED,
           'candidate_tree_sha':payload_summary['candidate_tree_sha'],'check_plan_ref':payload_summary['check_plan_ref'],
           'check_plan_sha256':plan_sha,'result':'PASS','check_count':11,'passed_checks':11,'failed_checks':0,
           'runner_summary_ref':(SUPPORT_REF / (LOCAL_ROOT / 'summary.json').relative_to(SUPPORT)).as_posix(),
           'runner_summary_sha256':digest(payload_summary_bytes)}
receipt_bytes = write_json(LOCAL_ROOT / 'receipt.json',receipt)
print(json.dumps({'plan_sha256':plan_sha,'receipt_sha256':digest(receipt_bytes),'checks':11,'result':'PASS'},sort_keys=True))
