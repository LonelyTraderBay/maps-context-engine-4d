from __future__ import annotations
import hashlib,json,subprocess,sys
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path.cwd();TASK='T034';REV=3;GATE='G4';PRIORITY='P0';DELIVERY='18271be3-f0ae-45bf-9d80-3d830ad21038';BASE='e32f7daa80835ef9bca5978b636909b47bd4d4e6';CODE='ee14e15f0169a0a0ec8c4eafd648dbdbc6a2fa95';PAYLOAD='42104732e3fd917d0671cc2bd17f1060a88e0572';ALLOCATION='b24ce65a31bf98cd25e4fb72bb1acd09225fcad5';PLAN='b564d7b7d129051fc1f2fcea17c16d9ba60828db9d2913c33a917b0942d7a4aa';RUN='39204567127'
SUPPORT_REF=f'artifacts/git-delivery-support/{TASK}-r{REV}-{DELIVERY}';SUPPORT=ROOT/SUPPORT_REF;SPEC=ROOT/'Maps-Context-Engine-4D_SPEC.md';CANDIDATE=SUPPORT/'closing-C-T034-SPEC-candidate.md'
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True,encoding='utf-8').strip()
def read(ref):
 x=json.loads((ROOT/ref).read_text(encoding='utf-8',errors='strict'))
 if not isinstance(x,dict):raise SystemExit(f'object required: {ref}')
 return x
def sha(ref):return hashlib.sha256((ROOT/ref).read_bytes()).hexdigest()
def s22(lines,key,old,new):
 p=f'    {key}: ';idx=[i for i,x in enumerate(lines) if x.startswith(p)]
 if len(idx)!=1 or json.loads(lines[idx[0]][len(p):])!=old:raise SystemExit(f'S22 changed: {key}')
 lines[idx[0]]=p+json.dumps(new,ensure_ascii=False)
if git('branch','--show-current')!='main' or git('rev-parse','HEAD')!=PAYLOAD or git('ls-remote','origin','refs/heads/main').split()!=[PAYLOAD,'refs/heads/main']:raise SystemExit('closing proposal requires verified payload-ready P on local and remote main')
if git('rev-parse',f'{PAYLOAD}^')!=CODE:raise SystemExit('payload-ready checkpoint is not a direct child of the verified code payload')
if subprocess.run(['git','diff-index','--quiet','HEAD','--'],cwd=ROOT).returncode or subprocess.run(['git','diff','--cached','--quiet'],cwd=ROOT).returncode:raise SystemExit('tracked tree/index must be clean before closing proposal')
if SPEC.read_bytes()!=subprocess.check_output(['git','show',f'{PAYLOAD}:Maps-Context-Engine-4D_SPEC.md'],cwd=ROOT):raise SystemExit('working SPEC differs from verified payload-ready P')
if CANDIDATE.exists():raise SystemExit('closing SPEC candidate exists; preserve and inspect')
local_ref=f'{SUPPORT_REF}/local-checks/payload-ready/receipt.json';lr=read(local_ref);ls=read(f'{SUPPORT_REF}/local-checks/payload-ready/summary.json')
ci_root=f'{SUPPORT_REF}/archive-view/ci/payload-ready';ci=read(f'{ci_root}/collector-summary.json');col=read(f'{ci_root}/collection.json');obs=read(f'{ci_root}/payload-observation.archive.json')
push_root=f'{SUPPORT_REF}/archive-view/operations/payload-ready-attempt-1';push=read(f'{push_root}/push-operation.json');dest=read(f'{push_root}/destination-observation.json');life=read(f'{push_root}/command-lifecycle.json')
if (lr.get('candidate_sha'),lr.get('candidate_tree_sha'),lr.get('phase'),lr.get('check_plan_sha256'),lr.get('result'),lr.get('check_count'),lr.get('passed_checks'),lr.get('failed_checks'))!=(PAYLOAD,git('show','-s','--format=%T',PAYLOAD),'payload',PLAN,'PASS',11,11,0):raise SystemExit('payload-ready local receipt mismatch')
if ls.get('candidate_sha')!=PAYLOAD or ls.get('check_plan_sha256')!=PLAN or ls.get('passed_checks')!=11:raise SystemExit('payload-ready local summary mismatch')
if (ci.get('subject_sha'),ci.get('phase'),ci.get('check_plan_sha256'),ci.get('result'),ci.get('check_count'),ci.get('passed_count'),ci.get('run_ids'))!=(PAYLOAD,'payload',PLAN,'PASS',4,4,[RUN]):raise SystemExit('payload-ready exact-SHA CI mismatch')
if (col.get('subject_sha'),col.get('collection_id'),col.get('repository_id'),col.get('check_plan_sha256'))!=(PAYLOAD,ci.get('collection_id'),1421031011,PLAN):raise SystemExit('payload-ready collection identity mismatch')
if (obs.get('subject_sha'),obs.get('parent_sha'),obs.get('observed_remote_sha'),obs.get('check_plan_sha256'),obs.get('result'),obs.get('required_set_verified'))!=(PAYLOAD,BASE,PAYLOAD,PLAN,'PASS',True):raise SystemExit('payload-ready observation mismatch')
if (push.get('candidate_sha'),push.get('preflight',{}).get('observed_remote_sha'),push.get('postflight',{}).get('observed_remote_sha'))!=(PAYLOAD,CODE,PAYLOAD):raise SystemExit('payload-ready normal push pre/postflight mismatch')
if dest.get('candidate_sha')!=PAYLOAD or dest.get('visibility_verified') is not True or dest.get('identity_verified') is not True or life.get('result',{}).get('final_status')!='SUCCEEDED':raise SystemExit('payload-ready destination/lifecycle mismatch')
raw=SPEC.read_text(encoding='utf-8');lines=raw.splitlines();rows=[i for i,x in enumerate(lines) if x.startswith('| T034 |')]
if len(rows)!=1:raise SystemExit('S19 T034 row missing')
i=rows[0];cells=lines[i].split('|')
if len(cells)!=11 or cells[7].strip()!='VERIFY' or cells[8].strip()!='Codex':raise SystemExit('T034 must be VERIFY before closing proposal')
parts=cells[9].strip().split(';');ids,*items=parts;fields={};order=[]
for item in items:
 k,sep,v=item.partition('=')
 if not sep or not k or k in fields:raise SystemExit(f'invalid S19 field: {item!r}')
 order.append(k);fields[k]=v
expected={'task_revision':'3','delivery':DELIVERY,'phase':'payload-ready','base_sha':BASE,'plan_sha256':PLAN,'priority':PRIORITY,'candidate':'VERIFY','effective':'VERIFY','local':'PASS(11/11)','payload':'PENDING','payload_sha':'PENDING','payload_CI':'PENDING','closing':'PENDING','closing_sha':'PENDING','closing_CI':'PENDING','archive/live':'PENDING'}
for k,v in expected.items():
 if fields.get(k)!=v:raise SystemExit(f'S19 precondition {k} mismatch: {fields.get(k)!r}')
fields.update({'phase':'payload-ready','candidate':'DONE','effective':'VERIFY','payload_sha':PAYLOAD,'payload_CI':f'PASS(4/4:{RUN})','closing':'PENDING','closing_sha':'PENDING','closing_CI':'PENDING','archive/live':'PENDING'})
for k in ('payload_sha','payload_CI','closing','closing_sha','closing_CI','archive/live'):
 if k not in order:order.append(k)
ids_list=ids.split(',')
if 'E430' in ids_list or any(x.startswith('| E430 |') for x in lines):raise SystemExit('E430 exists; preserve and inspect')
ids_list.append('E430');cells[7]=' DONE ';cells[9]=' '+';'.join([','.join(ids_list),*(f'{k}={fields[k]}' for k in order)])+' ';lines[i]='|'.join(cells)
e429=[j for j,x in enumerate(lines) if x.startswith('| E429 | T034 | task_revision=3;delivery='+DELIVERY)]
if len(e429)!=1:raise SystemExit('expected one E429 payload proposal')
ci_refs=[f'{ci_root}/{x}' for x in ('collector-summary.json','collection.json','payload-observation.archive.json','source-graph.json')]
push_refs=[f'{push_root}/{x}' for x in ('push-operation.json','destination-observation.json','command-lifecycle.json')]
refs=[local_ref,f'{SUPPORT_REF}/local-checks/payload-ready/summary.json',*ci_refs,*push_refs,f'{SUPPORT_REF}/commit-message-payload-ready-T034.txt']
arts=';'.join(f'{r}=sha256:{sha(r)}' for r in refs);now=datetime.now(timezone.utc).isoformat(timespec='microseconds').replace('+00:00','Z')
event=(f'| E430 | T034 | task_revision={REV};delivery={DELIVERY};phase=closing-proposed;payload_sha={PAYLOAD};code_payload_sha={CODE};closing_parent_sha={PAYLOAD};tree_sha={git("show","-s","--format=%T",PAYLOAD)};plan_sha256={PLAN};priority={PRIORITY};local=PASS(11/11);payload_CI=PASS(4/4:{RUN});collection_id={ci["collection_id"]};push_operation_id={push["push_operation_id"]};candidate=DONE;effective=VERIFY;closing_sha=PENDING;closing_CI=PENDING;archive/live=PENDING '
 f'| Windows 11 x64; Go 1.27.2 windows/amd64; Python 3.12.10; GitHub Actions Ubuntu/Windows; repository ID 1421031011 '
 f'| Đề xuất closing C là con trực tiếp của payload-ready P {PAYLOAD}; ghi local và CI exact-SHA cùng push preflight/postflight. Effective vẫn VERIFY đến khi closing, archive/readback và live được xác minh. '
 f'| PASS — P {PAYLOAD} là con trực tiếp của code payload {CODE}; plan gốc {PLAN}; local 11/11 PASS; Actions {RUN} PASS 4/4, collection {ci["collection_id"]}; push operation {push["push_operation_id"]} xác nhận main tiến fast-forward từ {CODE} đến {PAYLOAD}. Closing C, archive/readback và live còn chờ. '
 f'| {arts} | {now} |')
lines.insert(e429[0]+1,event)
s22(lines,'last_verified_payload_sha',CODE,PAYLOAD);s22(lines,'closing_parent_sha','fb04688276b383467fe7233c1950cfd066a66817',PAYLOAD);s22(lines,'observed_remote_sha',CODE,PAYLOAD)
s22(lines,'last_ci_collection_ref',f'{SUPPORT_REF}/archive-view/ci/payload-code/collection.json',f'{ci_root}/collection.json')
s22(lines,'last_delivery_evidence_ref',f'{SUPPORT_REF}/archive-view/ci/payload-code/payload-observation.archive.json',f'{ci_root}/payload-observation.archive.json')
j=[k for k,x in enumerate(lines) if x.startswith('    last_ci_result: ')]
if len(j)!=1:raise SystemExit('S22 last_ci_result not unique')
lines[j[0]]='    last_ci_result: '+json.dumps(f'T034 r3 payload-ready P {PAYLOAD}: frozen-plan local 11/11 PASS; Actions {RUN} exact-SHA 4/4 collection {ci["collection_id"]}; push {push["push_operation_id"]} verifies main={PAYLOAD}. Closing C, archive/readback and fresh live verification pending.',ensure_ascii=False)
updated='\n'.join(lines)+'\n';sys.path.insert(0,str(ROOT));from tools.ci.delivery_policy import classify_closing_spec_diff,validate_commit_message
errors=classify_closing_spec_diff(raw,updated,task_id=TASK,owning_gate=GATE)
if errors:raise SystemExit('closing diff precheck failed: '+'; '.join(errors))
message=(f'docs(progress): [P0][T034] Đề xuất closing T034\n\nMục đích: Chốt ứng viên DONE sau khi payload-ready P đã qua local và exact-SHA CI.\nThay đổi: Cập nhật S19/S22, thêm E430; effective vẫn VERIFY đến archive/readback/live.\nKiểm tra: P {PAYLOAD} local 11/11, Actions {RUN} PASS 4/4; diff closing qua policy precheck.\n\nMCE4D-Delivery-ID: {DELIVERY}\nMCE4D-Delivery-Phase: closing')
errors=validate_commit_message(message,phase='closing',task_id=TASK,priority=PRIORITY)
if errors:raise SystemExit('closing commit message invalid: '+'; '.join(errors))
b=updated.encode('utf-8');CANDIDATE.write_bytes(b);SPEC.write_bytes(b);(SUPPORT/'commit-message-closing-C-T034.txt').write_text(message,encoding='utf-8',newline='\n')
print(json.dumps({'result':'PREPARED','evidence_id':'E430','payload_sha':PAYLOAD,'closing_parent_sha':PAYLOAD,'closing_diff':'PASS','artifact_refs':len(refs),'candidate':CANDIDATE.as_posix()},ensure_ascii=False,sort_keys=True))