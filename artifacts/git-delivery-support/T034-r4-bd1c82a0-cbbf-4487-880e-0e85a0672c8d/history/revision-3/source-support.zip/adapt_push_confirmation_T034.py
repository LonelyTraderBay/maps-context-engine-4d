import re
from pathlib import Path
source=Path('artifacts/git-delivery-support/T035-r1-e01d3e3d-2d59-4be8-ad95-937d4436bb75/push_payload_ready_T035_R1.py').read_text(encoding='utf-8')
replacements={
 "DELIVERY='e01d3e3d-2d59-4be8-ad95-937d4436bb75'; TASK='T035'; REV=1":"DELIVERY='18271be3-f0ae-45bf-9d80-3d830ad21038'; TASK='T034'; REV=3",
 "BASE='49da628828d2bc700c105ffd24454edd15fcebfe'; REMOTE_BASE='8548570c0c3d56f8900b09f53c45f302d6776f3f'":"BASE='e32f7daa80835ef9bca5978b636909b47bd4d4e6'; REMOTE_BASE='ee14e15f0169a0a0ec8c4eafd648dbdbc6a2fa95'",
 "STAGE=ROOT/'artifacts/git-delivery-support/T035-r1-e01d3e3d-2d59-4be8-ad95-937d4436bb75'; REL='archive-view/operations/payload-ready-attempt-1'":"STAGE=ROOT/'artifacts/git-delivery-support/T034-r3-18271be3-f0ae-45bf-9d80-3d830ad21038'; REL='archive-view/operations/payload-code-confirmation-1'",
 "local=json.loads((STAGE/'local-checks/payload-ready/receipt.json').read_text(encoding='utf-8'))":"local=json.loads((STAGE/'local-checks/payload-frozen/receipt.json').read_text(encoding='utf-8'))",
 "'T035 payload-ready push không tạo disposable output.'":"'T034 exact-SHA confirmation push không tạo disposable output.'",
 "'Đẩy payload-ready checkpoint T035 revision 1 {CANDIDATE} lên refs/heads/main từ code payload {REMOTE_BASE}.'":"'Xác nhận payload T034 revision 3 {CANDIDATE} trên refs/heads/main bằng một push exact-SHA không đổi lịch sử.'",
 "PREFLIGHT PASS; sending one normal T035 payload-ready push to origin/main":"PREFLIGHT PASS; sending one normal exact-SHA T034 confirmation push to origin/main",
 "f'T035 payload-ready scope mismatch: {paths}'":"f'T034 payload scope mismatch: {paths}'",
 "f'Frozen 11/11 payload-ready checks are not PASS on exact commit/tree'":"f'Frozen 11/11 T034 payload checks are not PASS on exact commit/tree'",
}
for old,new in replacements.items():
    if old not in source: raise SystemExit(f'missing expected template text: {old}')
    source=source.replace(old,new)
source=re.sub(r"EXPECTED_PATHS=\[.*?\]\nREPOSITORY=", "EXPECTED_PATHS=['Maps-Context-Engine-4D_SPEC.md','artifacts/acceptance/T034/matrix.json','tests/acceptance/matrix_test.go','tests/acceptance/mutation_probe.py','tests/acceptance/r1_relations_test.go','tests/acceptance/run_matrix.py']\nREPOSITORY=", source, count=1, flags=re.S)
source=source.replace("if run(['git','rev-parse',f'{CANDIDATE}^']).stdout.decode().strip()!=REMOTE_BASE: raise SystemExit('Payload-ready candidate parent is not the exact code payload SHA')", "# This fresh confirmation does not claim to have recorded the earlier transfer.")
source=source.replace("if local.get('task_revision') != REV or", "if local.get('task_revision') != REV or")
Path('artifacts/git-delivery-support/T034-r3-18271be3-f0ae-45bf-9d80-3d830ad21038/push_payload_confirmation_T034.py').write_text(source,encoding='utf-8',newline='\n')