from __future__ import annotations
import hashlib,json,os,shutil,subprocess,sys
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path.cwd(); TASK='T034'; REV=3; DELIVERY='18271be3-f0ae-45bf-9d80-3d830ad21038'; PRIORITY='P0'
BASE='e32f7daa80835ef9bca5978b636909b47bd4d4e6'
PAYLOAD_COMMITS=['b24ce65a31bf98cd25e4fb72bb1acd09225fcad5','d1780b679521a81ce6df5573e65b33c888006820','5b61a5f2ab2ebedd6ba488b314189b754b3d2a9a','ab5882941644ed5b7acd2e94b0088304c99db2ef','834c041a15c391c1f197dd45665be11dbcdcb785','ee14e15f0169a0a0ec8c4eafd648dbdbc6a2fa95','42104732e3fd917d0671cc2bd17f1060a88e0572']
PAYLOAD=PAYLOAD_COMMITS[-1]; CLOSING='ea8763c63e711e5ed87fc3bf7307d11ba286a709'
PLAN_SHA='b564d7b7d129051fc1f2fcea17c16d9ba60828db9d2913c33a917b0942d7a4aa'
SUPPORT_REF=f'artifacts/git-delivery-support/{TASK}-r3-{DELIVERY}'; SUPPORT=ROOT/SUPPORT_REF
ARCHIVE_ROOT=ROOT/'artifacts/git-delivery'; STAGE=ARCHIVE_ROOT/f'.staging-{DELIVERY}'; FINAL=ARCHIVE_ROOT/DELIVERY
sys.path.insert(0,str(ROOT))
from tools.spec_check.archive import ArchiveError,_canonical,_is_reparse,_native_path,_validate_graph

def run(*argv):
 p=subprocess.run(argv,cwd=ROOT,check=True,capture_output=True,text=True,encoding='utf-8'); return p.stdout.strip()
def read_json(path):
 value=json.loads(path.read_text(encoding='utf-8',errors='strict'))
 if not isinstance(value,dict): raise SystemExit(f'JSON object required: {path}')
 return value
def put(ref,data):
 target=_native_path(STAGE/ref); target.parent.mkdir(parents=True,exist_ok=True)
 if target.exists():
  if target.is_file() and target.read_bytes()==data: return
  if not target.is_file(): raise SystemExit(f'archive member is not a file: {ref}')
  previous=target.read_bytes(); old_sha=hashlib.sha256(previous).hexdigest()
  preserved_ref=f'archive-view/history/precheck-stage-attempt1/{old_sha}/{ref}'
  preserved=_native_path(STAGE/preserved_ref); preserved.parent.mkdir(parents=True,exist_ok=True)
  if preserved.exists() and preserved.read_bytes()!=previous: raise SystemExit(f'precheck preservation collision: {preserved_ref}')
  if not preserved.exists(): preserved.write_bytes(previous)
  target.write_bytes(data)
  return
 target.write_bytes(data)
def copy_file(source,ref):
 info=source.lstat()
 if _is_reparse(info) or not source.is_file(): raise SystemExit(f'archive source must be regular file: {source}')
 put(ref,source.read_bytes())
def copy_tree(source,ref):
 if _is_reparse(source.lstat()) or not source.is_dir(): raise SystemExit(f'archive source must be ordinary directory: {source}')
 native=_native_path(source)
 for directory,dirs,files in os.walk(native,followlinks=False):
  base=Path(directory)
  for name in dirs+files:
   if _is_reparse((base/name).lstat()): raise SystemExit(f'reparse source blocked: {base/name}')
 for directory,dirs,files in os.walk(native,followlinks=False):
  dirs.sort(); files.sort(); base=Path(directory)
  for name in files:
   source_file=base/name; relative=source_file.relative_to(native).as_posix()
   put(f'{ref}/{relative}',source_file.read_bytes())
def snapshot(sha):
 message=run('git','show','-s','--format=%B',sha); subject,sep,body=message.partition('\n')
 parents=run('git','show','-s','--format=%P',sha).split()
 paths=sorted(run('git','diff-tree','--no-commit-id','--name-only','-r',sha).splitlines())
 return {'body':body if sep else '', 'changed_paths':paths,'kind':'git_commit_snapshot','parents':parents,'sha':sha,'subject':subject}
def commit_record(sha,scope_ref):
 item=snapshot(sha)
 return {'body':item['body'],'git_evidence_ref':f'commits/{sha}.snapshot.json','scope_ref':scope_ref,'sha':sha,'subject':item['subject']}
def normalize(value,prefix):
 if isinstance(value,str) and value.startswith(prefix): return 'archive-view/'+value[len(prefix):]
 if isinstance(value,list): return [normalize(item,prefix) for item in value]
 if isinstance(value,dict): return {normalize(key,prefix):normalize(item,prefix) for key,item in value.items()}
 return value

if not SUPPORT.is_dir() or not ARCHIVE_ROOT.is_dir(): raise SystemExit('T035 support or archive root missing')
if FINAL.exists(): raise SystemExit('final archive exists; preserve and inspect')
if run('git','rev-parse','HEAD')!=CLOSING or run('git','branch','--show-current')!='main': raise SystemExit('HEAD is not verified closing C on main')
if run('git','ls-remote','origin','refs/heads/main').split()[0]!=CLOSING: raise SystemExit('remote main is not closing C')
if STAGE.exists():
 if _is_reparse(STAGE.lstat()) or not STAGE.is_dir() or any((STAGE/name).exists() for name in ('manifest.json','seal.json','archive-candidate.json')): raise SystemExit('staging exists; preserve and inspect')
else: STAGE.mkdir(exist_ok=False)
plan_bytes=(SUPPORT/'check-plan.json').read_bytes(); plan=json.loads(plan_bytes.decode('utf-8','strict'))
if plan_bytes!=_canonical(plan) or hashlib.sha256(plan_bytes).hexdigest()!=PLAN_SHA: raise SystemExit('frozen plan bytes/hash mismatch')
selector=read_json(SUPPORT/'selection.json'); allocation=read_json(SUPPORT/'allocation.json')
if (selector.get('task_id'),selector.get('task_revision'),selector.get('active_delivery_id'))!=(TASK,REV,DELIVERY): raise SystemExit('selection identity mismatch')
if (allocation.get('task_id'),allocation.get('task_revision'),allocation.get('delivery_id'))!=(TASK,REV,DELIVERY): raise SystemExit('allocation identity mismatch')
if len(plan.get('local_check_refs',[]))!=11: raise SystemExit('plan must have 11 local evidence references')

# Retain exact support artifacts cited by S21 and a normalized archive view for graph validation.
copy_tree(SUPPORT,SUPPORT_REF)
copy_tree(SUPPORT/'history','history'); copy_tree(SUPPORT/'invalidation','invalidation')
copy_tree(ROOT/'artifacts/acceptance/T034/runs/windows-20261019-payload-ee14e15','artifacts/acceptance/T034/runs/windows-20261019-payload-ee14e15')
copy_file(SUPPORT/'allocation.json','allocation.json'); copy_file(SUPPORT/'selection.json','selection.json')
copy_file(SUPPORT/'task-mode.json','task-mode.json'); copy_file(SUPPORT/'check-plan.json','check-plan.json')
copy_tree(SUPPORT/'rationale','rationale'); copy_file(SUPPORT/'authority/task-start.txt','authority/task-start.txt')
copy_file(SUPPORT/'check-plan.json','archive-view/check-plan.json')
copy_tree(SUPPORT/'archive-view','archive-view')
archive_prefix=SUPPORT_REF+'/archive-view/'
for path in sorted((STAGE/'archive-view').rglob('*.json')):
 if path.relative_to(STAGE).as_posix().startswith('archive-view/history/precheck-stage-attempt1/'): continue
 if path.name.endswith('.body.json'): continue
 try: value=json.loads(path.read_text(encoding='utf-8',errors='strict'))
 except (UnicodeDecodeError,json.JSONDecodeError): continue
 projected=json.dumps(normalize(value,archive_prefix),ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf-8')
 if path.read_bytes()!=projected: put(path.relative_to(STAGE).as_posix(),projected)

# Bind the frozen 11 commands to actual local output from the exact payload-ready commit.
local_root=SUPPORT/'local-checks/payload-ready/attempt-1'; local=read_json(SUPPORT/'local-checks/payload-ready/receipt.json'); local_summary=read_json(local_root/'summary.json')
if (local.get('candidate_sha'),local.get('candidate_tree_sha'),local.get('phase'),local.get('result'),local.get('check_count'),local.get('passed_checks'),local.get('failed_checks'))!=(PAYLOAD,run('git','show','-s','--format=%T',PAYLOAD),'payload','PASS',11,11,0): raise SystemExit('payload local receipt is not exact P PASS 11/11')
if (local_summary.get('candidate_sha'),local_summary.get('candidate_tree_sha'),local_summary.get('phase'),local_summary.get('result'),local_summary.get('check_count'),local_summary.get('passed_checks'),local_summary.get('failed_checks'))!=(PAYLOAD,run('git','show','-s','--format=%T',PAYLOAD),'payload','PASS',11,11,0): raise SystemExit('payload local execution summary is not exact P PASS 11/11')
copy_tree(SUPPORT/'local-checks','archive-view/history/local-checks-support')
copy_tree(SUPPORT/'local-checks/closing-C','local-checks/closing-C')
records_dir=STAGE/'local-checks/allocation/records'; records_dir.mkdir(parents=True,exist_ok=True)
logs_dir=STAGE/'local-checks/payload/logs'; logs_dir.mkdir(parents=True,exist_ok=True)
refs=plan['local_check_refs']; checks={row['name']:row for row in local_summary['checks']}
name_to_ref={'bootstrap':'bootstrap','bootstrap-fixtures':'bootstrap-fixtures','delivery-plan':'delivery-plan','spec-check':'spec-check','spec-check-fixtures':'spec-check-fixtures','delivery-policy-fixtures':'delivery-policy-fixtures','checkpoint-digest-fixtures':'checkpoint-digest-fixtures','go-format':'go-format','go-test':'go-test','go-vet':'go-vet','go-build':'go-build'}
planned_commands={command for check in plan.get('checks',[]) for command in check.get('command_refs',[])}
projection=[]
for record_index,(name,suffix) in enumerate(name_to_ref.items()):
 row=checks.get(name)
 if row is None or row.get('exit_code')!=0: raise SystemExit(f'local result missing/failing: {name}')
 argv=row.get('argv')
 if not isinstance(argv,list) or not argv: raise SystemExit(f'local argv missing: {name}')
 executable=Path(argv[0]).name.casefold(); normalized=' '.join(['python' if executable.startswith('python') else executable.removesuffix('.exe'),*argv[1:]])
 matches=[command for command in planned_commands if normalized==command or normalized.startswith(command+' ')]
 if len(matches)!=1: raise SystemExit(f'local command does not map uniquely to frozen plan: {name}: {normalized}')
 rel_logs=[]
 for stream in ('stdout','stderr'):
  source=local_root/'logs'/f'{name}.{stream}.txt'; target_ref=f'local-checks/payload/logs/{name}.{stream}.txt'; copy_file(source,target_ref); rel_logs.append(target_ref)
 evidence={'format_version':1,'kind':'local_check','command_ref':matches[0],'task_id':TASK,'task_revision':REV,'delivery_id':DELIVERY,'phase':'payload','revision':PAYLOAD,'result':'PASS','execution_verified':True,'log_refs':rel_logs,'reused_from_ref':None}
 ref=refs[record_index]
 if Path(ref).stem!=suffix: raise SystemExit(f'frozen local evidence reference order mismatch: {ref} != {suffix}')
 put(ref,_canonical(evidence))
 projection.append({'command_ref':matches[0],'source_ref':f'{SUPPORT_REF}/local-checks/payload-ready/attempt-1/logs/{name}.stdout.txt','source_sha256':hashlib.sha256((local_root/'logs'/f'{name}.stdout.txt').read_bytes()).hexdigest(),'projected_ref':ref,'projected_sha256':hashlib.sha256(_native_path(STAGE/ref).read_bytes()).hexdigest()})
if len(projection)!=len(refs) or len({item['command_ref'] for item in projection})!=len(planned_commands): raise SystemExit('local projections do not cover exact frozen command set')
put('local-checks/payload/projection.json',_canonical({'format_version':1,'kind':'local_check_projection','delivery_id':DELIVERY,'task_id':TASK,'task_revision':REV,'source_revision':PAYLOAD,'source_summary_ref':f'{SUPPORT_REF}/local-checks/payload-ready/attempt-1/summary.json','records':projection}))

previous=BASE; ordered=[]; typed={
 'check-plan.json':'GitCheckPlan','archive-view/check-plan.json':'GitCheckPlan','selection.json':'GitTaskDeliverySelection','history/revision-1/selection.json':'GitTaskDeliverySelection','history/revision-2/selection.json':'GitTaskDeliverySelection',
 'archive-view/ci/payload-ready-final/payload-observation.archive.json':'GitDeliveryObservation',
 'archive-view/ci/c/closing-observation.archive.json':'GitDeliveryObservation',
}
for index,sha in enumerate(PAYLOAD_COMMITS,1):
 item=snapshot(sha)
 if item['parents']!=[previous] or not item['changed_paths']: raise SystemExit(f'payload ancestry/scope invalid at {sha}')
 if f'[{TASK}]' not in item['subject'] or f'[{PRIORITY}]' not in item['subject'] or any(line.startswith('MCE4D-') for line in item['body'].splitlines()): raise SystemExit(f'payload commit policy invalid at {sha}')
 put(f'commits/{sha}.snapshot.json',_canonical(item))
 scope_ref=f'scope/payload-{index:02}.json'
 scope={'breaking_decision_ref':None,'changed_paths':item['changed_paths'],'format_version':1,'kind':'commit_scope','phase':'payload','priority':PRIORITY,'priority_reason_ref':None,'shared_invariant_ref':None,'task_ids':[TASK]}
 put(scope_ref,_canonical(scope)); typed[scope_ref]='GitCommitScopeEvidence'; ordered.append(commit_record(sha,scope_ref)); previous=sha
if previous!=PAYLOAD: raise SystemExit('ordered payload does not end at exact P')
closing_snapshot=snapshot(CLOSING)
if closing_snapshot['parents']!=[PAYLOAD] or closing_snapshot['changed_paths']!=['Maps-Context-Engine-4D_SPEC.md']: raise SystemExit('closing ancestry/scope invalid')
api=json.loads(run('gh','api',f'repos/LonelyTraderBay/maps-context-engine-4d/commits/{CLOSING}'))
api_message=api.get('commit',{}).get('message',''); api_subject,sep,api_body=api_message.partition('\n')
api_paths=sorted(item['filename'] for item in api.get('files',[]) if isinstance(item,dict) and isinstance(item.get('filename'),str))
if api.get('sha')!=CLOSING or api_subject!=closing_snapshot['subject'] or (api_body if sep else '')!=closing_snapshot['body'] or api_paths!=closing_snapshot['changed_paths']: raise SystemExit('fresh GitHub C projection differs from local Git snapshot')
put(f'commits/{CLOSING}.snapshot.json',_canonical(closing_snapshot))
closing_scope_ref='scope/closing-C.json'; put(closing_scope_ref,_canonical({'breaking_decision_ref':None,'changed_paths':closing_snapshot['changed_paths'],'format_version':1,'kind':'commit_scope','phase':'closing','priority':PRIORITY,'priority_reason_ref':None,'shared_invariant_ref':None,'task_ids':[TASK]})); typed[closing_scope_ref]='GitCommitScopeEvidence'
closing_commit_ref='archive-view/commits/closing-C.json'; put(closing_commit_ref,_canonical(commit_record(CLOSING,closing_scope_ref))); typed[closing_commit_ref]='GitCommit'

payload_obs_ref='archive-view/ci/payload-ready-final/payload-observation.archive.json'; closing_obs_ref='archive-view/ci/c/closing-observation.archive.json'
payload_obs=read_json(STAGE/payload_obs_ref); closing_obs=read_json(STAGE/closing_obs_ref)
if (payload_obs.get('delivery_id'),payload_obs.get('phase'),payload_obs.get('subject_sha'),payload_obs.get('result'),payload_obs.get('check_plan_sha256'))!=(DELIVERY,'payload',PAYLOAD,'PASS',PLAN_SHA): raise SystemExit('payload observation identity/result mismatch')
if (closing_obs.get('delivery_id'),closing_obs.get('phase'),closing_obs.get('subject_sha'),closing_obs.get('parent_sha'),closing_obs.get('result'),closing_obs.get('check_plan_sha256'))!=(DELIVERY,'closing',CLOSING,PAYLOAD,'PASS',PLAN_SHA): raise SystemExit('closing observation identity/result mismatch')
attempt_ref='archive-view/delivery-attempt-closing-C.json'
attempt={'archive_staging_path':f'artifacts/git-delivery/.staging-{DELIVERY}','assignment_ref':selector['assignment_ref'],'base_sha':BASE,'check_plan_ref':'archive-view/check-plan.json','check_plan_sha256':PLAN_SHA,'closing_marker':f'MCE4D-Delivery-ID: {DELIVERY}','closing_parent_sha':PAYLOAD,'delivery_id':DELIVERY,'format_version':1,'local_evidence_refs':refs,'noop_reason_ref':None,'ordered_commits':ordered,'payload_mode':'changes','payload_observation_ref':payload_obs_ref,'phase':'closing_proposed','planned_archive_path':f'artifacts/git-delivery/{DELIVERY}','priority':PRIORITY,'task_id':TASK,'task_revision':REV,'verified_payload_sha':PAYLOAD}
put(attempt_ref,_canonical(attempt)); typed[attempt_ref]='GitDeliveryAttempt'

kind_map={'check_execution':'GitCheckExecutionEvidence','check_source':'GitCheckSourceEvidence','ci_collection':'GitCICollectionEvidence','command_lifecycle':'GitCommandLifecycle','commit_scope':'GitCommitScopeEvidence','local_check':'GitLocalCheckEvidence','push_operation':'GitPushOperationEvidence'}
native=_native_path(STAGE)
for directory,dirs,names in os.walk(native,followlinks=False):
 base=Path(directory)
 for name in names:
  path=base/name; ref=path.relative_to(native).as_posix()
  if not ref.endswith('.json') or ref in typed or ref in {'bundle-index.json','archive-candidate.json','manifest.json','seal.json'} or ref.startswith(('history/','archive-view/history/')): continue
  try: value=json.loads(path.read_text(encoding='utf-8',errors='strict'))
  except (OSError,UnicodeDecodeError,json.JSONDecodeError): continue
  if isinstance(value,dict) and value.get('kind') in kind_map: typed[ref]=kind_map[value['kind']]

stage_files=[]
for directory,dirs,names in os.walk(native,followlinks=False):
 base=Path(directory)
 for name in names:
  path=base/name; ref=path.relative_to(native).as_posix()
  if ref not in {'bundle-index.json','archive-candidate.json','manifest.json','seal.json'}: stage_files.append(ref)
stage_files.sort()
missing=sorted(ref for ref in typed if not _native_path(STAGE/ref).is_file())
if missing: raise SystemExit(f'typed references missing: {missing}')
raw_members=[]; opaque=[]
for ref in stage_files:
 if ref in typed: continue
 if ref.startswith('archive-view/history/precheck-stage-attempt1/') and ref.endswith('/bundle-index.json'): continue
 data=_native_path(STAGE/ref).read_bytes()
 try: decoded=data.decode('utf-8','strict')
 except UnicodeDecodeError: opaque.append(ref); continue
 try: json.loads(decoded); raw_members.append(ref)
 except json.JSONDecodeError:
  if Path(ref).suffix.casefold() in {'.md','.txt','.log'}: raw_members.append(ref)
  else: opaque.append(ref)
index={'format_version':1,'objects':dict(sorted(typed.items())),'raw_members':raw_members}
put('bundle-index.json',_canonical(index))
stage_files=[]
for directory,dirs,names in os.walk(native,followlinks=False):
 base=Path(directory)
 for name in names:
  path=base/name; ref=path.relative_to(native).as_posix()
  if ref not in {'bundle-index.json','archive-candidate.json','manifest.json','seal.json'}: stage_files.append(ref)
stage_files.sort()
member_refs=sorted([*stage_files,'bundle-index.json']); files=[]
for ref in member_refs:
 data=_native_path(STAGE/ref).read_bytes(); files.append({'path':ref,'byte_length':len(data),'sha256':hashlib.sha256(data).hexdigest()})
archive={'format_version':1,'delivery_id':DELIVERY,'task_id':TASK,'task_revision':REV,'assignment_ref':selector['assignment_ref'],'attempt_ref':attempt_ref,'selection_ref':'selection.json','payload_observation_ref':payload_obs_ref,'closing_observation_ref':closing_obs_ref,'closing_commit_ref':closing_commit_ref,'closing_sha':CLOSING,'git_evidence_ref':f'commits/{CLOSING}.snapshot.json','verified_payload_sha':PAYLOAD,'check_plan_sha256':PLAN_SHA,'files':files,'retention_authority_ref':'authority/task-start.txt','created_at_utc':datetime.now(timezone.utc).isoformat(timespec='microseconds').replace('+00:00','Z')}
try: _validate_graph(STAGE,archive,ROOT/'Maps-Context-Engine-4D_SPEC.md')
except (ArchiveError,OSError,ValueError) as exc: raise SystemExit(f'archive graph precheck failed; candidate not written: {exc}') from exc
candidate=_canonical(archive); (STAGE/'archive-candidate.json').write_bytes(candidate)
print(json.dumps({'result':'GRAPH_PASS','delivery_id':DELIVERY,'task_id':TASK,'payload_sha':PAYLOAD,'closing_sha':CLOSING,'typed_objects':len(typed),'raw_members':len(raw_members),'opaque_members':len(opaque),'archive_files':len(files),'archive_bytes':sum(item['byte_length'] for item in files),'manifest_sha256':hashlib.sha256(candidate).hexdigest()},ensure_ascii=False,sort_keys=True))


