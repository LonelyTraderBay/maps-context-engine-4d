import re
from pathlib import Path
src=Path('artifacts/git-delivery-support/T035-r1-e01d3e3d-2d59-4be8-ad95-937d4436bb75/push_payload_ready_T035_R1.py').read_text(encoding='utf-8')
repl={
 "DELIVERY='e01d3e3d-2d59-4be8-ad95-937d4436bb75'; TASK='T035'; REV=1":"DELIVERY='18271be3-f0ae-45bf-9d80-3d830ad21038'; TASK='T034'; REV=3",
 "BASE='49da628828d2bc700c105ffd24454edd15fcebfe'; REMOTE_BASE='8548570c0c3d56f8900b09f53c45f302d6776f3f'":"BASE='e32f7daa80835ef9bca5978b636909b47bd4d4e6'; REMOTE_BASE='ee14e15f0169a0a0ec8c4eafd648dbdbc6a2fa95'",
 "STAGE=ROOT/'artifacts/git-delivery-support/T035-r1-e01d3e3d-2d59-4be8-ad95-937d4436bb75'; REL='archive-view/operations/payload-ready-attempt-1'":"STAGE=ROOT/'artifacts/git-delivery-support/T034-r3-18271be3-f0ae-45bf-9d80-3d830ad21038'; REL='archive-view/operations/payload-ready-attempt-1'",
 "'T035 payload-ready push không tạo disposable output.'":"'T034 payload-ready push không tạo disposable output.'",
 "'Đẩy payload-ready checkpoint T035 revision 1 {CANDIDATE} lên refs/heads/main từ code payload {REMOTE_BASE}.'":"'Đẩy payload-ready checkpoint T034 revision 3 {CANDIDATE} lên refs/heads/main từ code payload {REMOTE_BASE}.'",
 "PREFLIGHT PASS; sending one normal T035 payload-ready push to origin/main":"PREFLIGHT PASS; sending one normal T034 payload-ready push to origin/main",
 "'Frozen plan bytes/hash mismatch'":"'Frozen T034 plan bytes/hash mismatch'",
}
for a,b in repl.items():
 if a not in src: raise SystemExit(f'missing push template: {a}')
 src=src.replace(a,b)
src=re.sub(r"EXPECTED_PATHS=\[.*?\]\nREPOSITORY=", "EXPECTED_PATHS=['Maps-Context-Engine-4D_SPEC.md','artifacts/acceptance/T034/matrix.json','tests/acceptance/matrix_test.go','tests/acceptance/mutation_probe.py','tests/acceptance/r1_relations_test.go','tests/acceptance/run_matrix.py']\nREPOSITORY=", src,count=1,flags=re.S)
src=src.replace('4613709c969881e2d059b9ca372931b372dff37e7a6cc9ddeed800b5dbb9b615','b564d7b7d129051fc1f2fcea17c16d9ba60828db9d2913c33a917b0942d7a4aa')
Path('artifacts/git-delivery-support/T034-r3-18271be3-f0ae-45bf-9d80-3d830ad21038/push_payload_ready_T034.py').write_text(src,encoding='utf-8',newline='\n')