from __future__ import annotations
import hashlib,json,subprocess,sys
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path.cwd(); TASK='T034'; REV=3; DELIVERY='18271be3-f0ae-45bf-9d80-3d830ad21038'; BASE='e32f7daa80835ef9bca5978b636909b47bd4d4e6'; CODE='ee14e15f0169a0a0ec8c4eafd648dbdbc6a2fa95'; PLAN='b564d7b7d129051fc1f2fcea17c16d9ba60828db9d2913c33a917b0942d7a4aa'; RUN='39202484299'
SUPPORT_REF=f'artifacts/git-delivery-support/{TASK}-r{REV}-{DELIVERY}'; SUPPORT=ROOT/SUPPORT_REF; SPEC=ROOT/'Maps-Context-Engine-4D_SPEC.md'; CANDIDATE=SUPPORT/'payload-ready-T034-SPEC-candidate.md'
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True,encoding='utf-8').strip()
def read(ref):
 x=json.loads((ROOT/ref).read_text(encoding='utf-8',errors='strict'))
 if not isinstance(x,dict):raise SystemExit(f'object required: {ref}')
 return x
def sha(ref):return hashlib.sha256((ROOT/ref).read_bytes()).hexdigest()
def s22(lines,key,old,new):
 p=f'    {key}: '; idx=[i for i,x in enumerate(lines) if x.startswith(p)]
 if len(idx)!=1 or json.loads(lines[idx[0]][len(p):])!=old:raise SystemExit(f'S22 changed: {key}')
 lines[idx[0]]=p+json.dumps(new,ensure_ascii=False)
if git('branch','--show-current')!='main' or git('rev-parse','HEAD')!=CODE or git('ls-remote','origin','refs/heads/main').split()!=[CODE,'refs/heads/main']:raise SystemExit('code payload is not the current local/remote main')
if subprocess.run(['git','diff-index','--quiet','HEAD','--'],cwd=ROOT).returncode or subprocess.run(['git','diff','--cached','--quiet'],cwd=ROOT).returncode:raise SystemExit('tracked state is not clean')
if SPEC.read_bytes()!=subprocess.check_output(['git','show',f'{CODE}:Maps-Context-Engine-4D_SPEC.md'],cwd=ROOT):raise SystemExit('SPEC differs from code payload')
if CANDIDATE.exists():raise SystemExit('candidate already exists; preserve it')
local_ref=f'{SUPPORT_REF}/local-checks/payload-frozen/receipt.json'; local=read(local_ref); ls=read(f'{SUPPORT_REF}/local-checks/payload-frozen/summary.json')
ci_root=f'{SUPPORT_REF}/archive-view/ci/payload-code'; ci=read(f'{ci_root}/collector-summary.json'); col=read(f'{ci_root}/collection.json'); obs=read(f'{ci_root}/payload-observation.archive.json')
push_root=f'{SUPPORT_REF}/archive-view/operations/payload-code-confirmation-1'; push=read(f'{push_root}/push-operation.json'); dest=read(f'{push_root}/destination-observation.json'); life=read(f'{push_root}/command-lifecycle.json')
if (local.get('candidate_sha'),local.get('candidate_tree_sha'),local.get('phase'),local.get('check_plan_sha256'),local.get('result'),local.get('check_count'),local.get('passed_checks'),local.get('failed_checks'))!=(CODE,git('show','-s','--format=%T',CODE),'payload',PLAN,'PASS',11,11,0):raise SystemExit('frozen local receipt mismatch')
if ls.get('candidate_sha')!=CODE or ls.get('check_plan_sha256')!=PLAN or ls.get('passed_checks')!=11:raise SystemExit('frozen local summary mismatch')
if (ci.get('subject_sha'),ci.get('phase'),ci.get('check_plan_sha256'),ci.get('result'),ci.get('check_count'),ci.get('passed_count'),ci.get('run_ids'))!=(CODE,'payload',PLAN,'PASS',4,4,[RUN]):raise SystemExit('exact-SHA CI summary mismatch')
if (col.get('subject_sha'),col.get('collection_id'),col.get('repository_id'),col.get('check_plan_sha256'))!=(CODE,ci.get('collection_id'),1421031011,PLAN):raise SystemExit('CI collection identity mismatch')
if (obs.get('subject_sha'),obs.get('parent_sha'),obs.get('observed_remote_sha'),obs.get('check_plan_sha256'),obs.get('result'),obs.get('required_set_verified'))!=(CODE,BASE,CODE,PLAN,'PASS',True):raise SystemExit('CI observation mismatch')
if (push.get('candidate_sha'),push.get('preflight',{}).get('observed_remote_sha'),push.get('postflight',{}).get('observed_remote_sha'))!=(CODE,CODE,CODE) or dest.get('candidate_sha')!=CODE or dest.get('visibility_verified') is not True or dest.get('identity_verified') is not True or life.get('result',{}).get('final_status')!='SUCCEEDED':raise SystemExit('push/destination evidence mismatch')
report=read('artifacts/acceptance/T034/runs/windows-20261019-payload-ee14e15/report.json')
if report.get('tracked_worktree_clean') is not True or report.get('counts')!={'cases':69,'pass':52,'pass_limited':17,'fail':0}:raise SystemExit('acceptance matrix report mismatch')
raw=SPEC.read_text(encoding='utf-8'); lines=raw.splitlines(); rows=[i for i,x in enumerate(lines) if x.startswith('| T034 |')]
if len(rows)!=1:raise SystemExit('S19 T034 row mismatch')
i=rows[0]; cells=lines[i].split('|')
if len(cells)!=11 or cells[7].strip()!='IN_PROGRESS' or cells[8].strip()!='Codex':raise SystemExit('T034 is not in expected active state')
parts=cells[9].strip().split(';'); ids,*items=parts; fields={}; order=[]
for item in items:
 k,sep,v=item.partition('=')
 if not sep or not k or k in fields:raise SystemExit(f'invalid S19 field: {item!r}')
 order.append(k);fields[k]=v
for k,v in {'task_revision':'3','delivery':DELIVERY,'phase':'allocation-verified','base_sha':BASE,'plan_sha256':PLAN,'priority':'P0','candidate':'VERIFY','effective':'IN_PROGRESS','payload_sha':'PENDING','closing':'NOT_RUN','archive/live':'NOT_RUN'}.items():
 if fields.get(k)!=v:raise SystemExit(f'S19 changed: {k}={fields.get(k)!r}')
fields.update({'phase':'payload-ready','candidate':'VERIFY','effective':'VERIFY','local':'PASS(11/11)','payload':'PENDING','payload_sha':'PENDING','payload_CI':'PENDING','closing':'PENDING','closing_sha':'PENDING','closing_CI':'PENDING','archive/live':'PENDING'})
for k in ('local','payload','payload_sha','payload_CI','closing','closing_sha','closing_CI','archive/live'):
 if k not in order:order.append(k)
ids_list=ids.split(',')
if 'E429' in ids_list or any(x.startswith('| E429 |') for x in lines):raise SystemExit('E429 exists; preserve')
ids_list.append('E429');cells[7]=' VERIFY ';cells[9]=' '+';'.join([','.join(ids_list),*(f'{k}={fields[k]}' for k in order)])+' ';lines[i]='|'.join(cells)
e428=[j for j,x in enumerate(lines) if x.startswith('| E428 | T034 | task_revision=3;delivery='+DELIVERY)]
if len(e428)!=1:raise SystemExit('E428 source row missing')
ci_refs=[f'{ci_root}/{x}' for x in ('collector-summary.json','collection.json','payload-observation.archive.json','source-graph.json')]
push_refs=[f'{push_root}/{x}' for x in ('push-operation.json','destination-observation.json','command-lifecycle.json')]
refs=[local_ref,f'{SUPPORT_REF}/local-checks/payload-frozen/summary.json',f'{SUPPORT_REF}/local-checks/payload/attempt-2/summary.json',*ci_refs,*push_refs,'artifacts/acceptance/T034/runs/windows-20261019-payload-ee14e15/report.json']
arts=';'.join(f'{r}=sha256:{sha(r)}' for r in refs); now=datetime.now(timezone.utc).isoformat(timespec='microseconds').replace('+00:00','Z')
event=(f'| E429 | T034 | task_revision={REV};delivery={DELIVERY};phase=payload-checkpoint-proposed;code_payload_sha={CODE};code_payload_tree_sha={git("show","-s","--format=%T",CODE)};plan_sha256={PLAN};'
 f'code_payload_local=PASS(11/11);code_payload_CI=PASS(4/4:{RUN});collection_id={ci["collection_id"]};push_operation_id={push["push_operation_id"]};acceptance_matrix=PASS(69:52-PASS,17-PASS_LIMITED,0-FAIL);'
 f'candidate=VERIFY;effective=VERIFY;payload_sha=PENDING;payload_CI=PENDING;closing=PENDING;archive/live=PENDING '
 f'| Windows 11 x64; Go 1.27.2 windows/amd64; Python 3.12.10; GitHub Actions Ubuntu/Windows; repository ID 1421031011 '
 f'| Ghi nhận code payload sau ma trận acceptance độc lập và 11 lệnh local theo plan gốc; push confirmation là thao tác no-op vì SHA đã có trên main. '
 f'| PASS — {CODE} local frozen-plan 11/11; Actions {RUN} exact-SHA 4/4; ma trận 69 case: 52 PASS, 17 PASS_LIMITED, 0 FAIL; push confirmation exit 0, preflight/postflight main={CODE}. Checkpoint payload-ready mới, closing, archive/readback và live còn chờ. '
 f'| {arts} | {now} |')
lines.insert(e428[0]+1,event)
s22(lines,'last_verified_payload_sha','fb04688276b383467fe7233c1950cfd066a66817',CODE)
s22(lines,'observed_remote_sha','93bb13294973554f7cf5978fa57ae2f001f5c2e1',CODE)
s22(lines,'last_ci_collection_ref',f'{SUPPORT_REF}/ci/a5/collection.json',f'{ci_root}/collection.json')
s22(lines,'last_delivery_evidence_ref',f'{SUPPORT_REF}/ci/a5/allocation-observation.archive.json',f'{ci_root}/payload-observation.archive.json')
j=[k for k,x in enumerate(lines) if x.startswith('    last_ci_result: ')]
if len(j)!=1:raise SystemExit('S22 CI result is not unique')
lines[j[0]]='    last_ci_result: '+json.dumps(f'T034 r3 code payload {CODE}: frozen-plan local 11/11 PASS; Actions {RUN} exact-SHA 4/4 collection {ci["collection_id"]}; 69 acceptance cases 52 PASS, 17 PASS_LIMITED, 0 FAIL; no-op push confirmation {push["push_operation_id"]} observes main={CODE}. Payload-ready checkpoint/closing/archive/live pending.',ensure_ascii=False)
updated='\n'.join(lines)+'\n';sys.path.insert(0,str(ROOT));from tools.ci.delivery_policy import validate_commit_message
message=(f'docs(progress): [P0][T034] Ghi nhận payload trước đóng task\n\nMục đích: Ghi nhận code payload T034 sau ma trận acceptance và kiểm local theo plan gốc.\nThay đổi: Thêm E429, cập nhật S19/S22; payload-ready checkpoint, closing, archive và live còn chờ.\nKiểm tra: {CODE} local 11/11 PASS, Actions {RUN} 4/4; 69 case gồm 52 PASS, 17 PASS_LIMITED, 0 FAIL.')
errors=validate_commit_message(message,phase='payload',task_id=TASK,priority='P0')
if errors:raise SystemExit('payload checkpoint message invalid: '+'; '.join(errors))
b=updated.encode('utf-8');CANDIDATE.write_bytes(b);SPEC.write_bytes(b);(SUPPORT/'commit-message-payload-ready-T034.txt').write_text(message,encoding='utf-8',newline='\n')
print(json.dumps({'result':'PREPARED','evidence_id':'E429','code_payload_sha':CODE,'local':'PASS(11/11)','CI':f'PASS(4/4:{RUN})','cases':69,'limited':17,'candidate':CANDIDATE.as_posix()},ensure_ascii=False,sort_keys=True))