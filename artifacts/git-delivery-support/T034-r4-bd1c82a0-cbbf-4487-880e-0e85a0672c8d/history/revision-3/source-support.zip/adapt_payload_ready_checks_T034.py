from pathlib import Path
src=Path('artifacts/git-delivery-support/T035-r1-e01d3e3d-2d59-4be8-ad95-937d4436bb75/run_payload_ready_checks_T035.py').read_text(encoding='utf-8')
replacements={
 'T035-r1-e01d3e3d-2d59-4be8-ad95-937d4436bb75':'T034-r3-18271be3-f0ae-45bf-9d80-3d830ad21038',
 'PLAN_SHA = "4613709c969881e2d059b9ca372931b372dff37e7a6cc9ddeed800b5dbb9b615"':'PLAN_SHA = "b564d7b7d129051fc1f2fcea17c16d9ba60828db9d2913c33a917b0942d7a4aa"',
 'TASK = "T035"':'TASK = "T034"','REVISION = 1':'REVISION = 3',
 'DELIVERY = "e01d3e3d-2d59-4be8-ad95-937d4436bb75"':'DELIVERY = "18271be3-f0ae-45bf-9d80-3d830ad21038"',
 'BASE = "49da628828d2bc700c105ffd24454edd15fcebfe"':'BASE = "e32f7daa80835ef9bca5978b636909b47bd4d4e6"',
 'EXPECTED_HEAD = "b398d4f"':'EXPECTED_HEAD = "42104732e3fd917d0671cc2bd17f1060a88e0572"',
 'EXPECTED_PARENT = "8548570c0c3d56f8900b09f53c45f302d6776f3f"':'EXPECTED_PARENT = "ee14e15f0169a0a0ec8c4eafd648dbdbc6a2fa95"',
}
for a,b in replacements.items():
 if a not in src: raise SystemExit(f'missing runner template: {a}')
 src=src.replace(a,b)
Path('artifacts/git-delivery-support/T034-r3-18271be3-f0ae-45bf-9d80-3d830ad21038/run_payload_ready_checks_T034.py').write_text(src,encoding='utf-8',newline='\n')