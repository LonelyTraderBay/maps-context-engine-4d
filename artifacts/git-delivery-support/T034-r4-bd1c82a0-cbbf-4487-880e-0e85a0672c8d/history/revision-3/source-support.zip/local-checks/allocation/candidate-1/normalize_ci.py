from pathlib import Path
import hashlib, json, sys
sys.path.insert(0,str(Path.cwd()))
from tools.spec_check.github_observer import _canonical_json
base=Path('artifacts/git-delivery-support/T034-r3-18271be3-f0ae-45bf-9d80-3d830ad21038/ci/a5')
project_prefix='artifacts/git-delivery-support/T034-r3-18271be3-f0ae-45bf-9d80-3d830ad21038/ci/a5'
D='18271be3-f0ae-45bf-9d80-3d830ad21038'; SHA='b24ce65a31bf98cd25e4fb72bb1acd09225fcad5'; PLAN='b564d7b7d129051fc1f2fcea17c16d9ba60828db9d2913c33a917b0942d7a4aa'

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def rewrite(v, mapping):
 if isinstance(v,str): return mapping.get(v,v)
 if isinstance(v,list): return [rewrite(x,mapping) for x in v]
 if isinstance(v,dict): return {k:rewrite(x,mapping) for k,x in v.items()}
 return v

files=[p for p in base.rglob('*') if p.is_file()]
pathmap={p.relative_to(base).as_posix():f'{project_prefix}/{p.relative_to(base).as_posix()}' for p in files}
pathmap['closing-observation.json']=f'{project_prefix}/allocation-observation.archive.json'
# Preserve observer output and publish the typed allocation observation under its stable phase name.
obs=read(base/'closing-observation.json')
obs=rewrite(obs,pathmap)
(base/'allocation-observation.archive.json').write_bytes(_canonical_json(obs))
collection=read(base/'collection.json'); collection=rewrite(collection,pathmap)
(base/'collection.json').write_bytes(_canonical_json(collection))
objects={f'{project_prefix}/collection.json':'GitCICollectionEvidence',f'{project_prefix}/allocation-observation.archive.json':'GitDeliveryObservation'}
for p in sorted((base/'checks').rglob('*.json')):
 obj=read(p); obj=rewrite(obj,pathmap); p.write_bytes(_canonical_json(obj))
 rel=p.relative_to(base).as_posix(); full=f'{project_prefix}/{rel}'
 objects[full]='GitCheckSourceEvidence' if p.name=='source.json' else 'GitCheckExecutionEvidence'
raw=[f'{project_prefix}/{p.relative_to(base).as_posix()}' for p in sorted((base/'pages').glob('*.json'))]
source_graph={'format_version':1,'kind':'ci_source_graph','objects':dict(sorted(objects.items())),'raw_members':raw}
(base/'source-graph.json').write_bytes(_canonical_json(source_graph))
contexts=[x for x in obs['checks']]
assert obs['result']=='PASS' and obs['binding_verified'] and obs['required_set_verified']
assert obs['subject_sha']==SHA and obs['delivery_id']==D and obs['parent_sha']=='e32f7daa80835ef9bca5978b636909b47bd4d4e6'
assert obs['check_plan_sha256']==PLAN and len(contexts)==4
assert all(x['status']=='completed' and x['conclusion']=='success' and x['reported_head_sha']==SHA and x['tested_checkout_sha']==SHA and x['event']=='push' for x in contexts)
ids=sorted({x['run_id'] for x in contexts})
summary={'format_version':1,'kind':'ci_collection_summary','task_id':'T034','task_revision':3,'delivery_id':D,'phase':'allocation-verification','subject_sha':SHA,'check_plan_sha256':PLAN,'collection_id':collection['collection_id'],'result':'PASS','check_count':len(contexts),'passed_count':sum(1 for x in contexts if x['conclusion']=='success'),'local_checks_passed':11,'local_checks_failed':0,'run_ids':ids,'source_graph_ref':f'{project_prefix}/source-graph.json'}
(base/'collector-summary.json').write_bytes(_canonical_json(summary))
print(json.dumps({'result':'PASS','collection_id':summary['collection_id'],'run_ids':ids,'check_count':len(contexts),'objects':len(objects),'raw_members':len(raw),'collection_sha256':digest(base/'collection.json'),'source_graph_sha256':digest(base/'source-graph.json'),'observation_sha256':digest(base/'allocation-observation.archive.json'),'summary_sha256':digest(base/'collector-summary.json')},ensure_ascii=False))
