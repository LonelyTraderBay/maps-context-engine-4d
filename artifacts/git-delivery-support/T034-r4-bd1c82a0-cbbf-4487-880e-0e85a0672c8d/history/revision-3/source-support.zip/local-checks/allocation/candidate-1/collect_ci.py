from pathlib import Path
from datetime import datetime, timezone
import json, sys
sys.path.insert(0, str(Path.cwd()))
from tools.spec_check.github_observer import GitHubApiClient, collect_ci_source_graph
root=Path.cwd(); support=Path('artifacts/git-delivery-support/T034-r3-18271be3-f0ae-45bf-9d80-3d830ad21038')
out=root/'artifacts/git-delivery-support/T034-r3-18271be3-f0ae-45bf-9d80-3d830ad21038/ci/a5'
out.mkdir(parents=True)
plan=json.loads((support/'check-plan.json').read_text(encoding='utf-8'))
identity={'delivery_id':'18271be3-f0ae-45bf-9d80-3d830ad21038','task_id':'T034','task_revision':3,'base_sha':'e32f7daa80835ef9bca5978b636909b47bd4d4e6','verified_payload_sha':'b24ce65a31bf98cd25e4fb72bb1acd09225fcad5'}
client=GitHubApiClient('github.com',out)
result=collect_ci_source_graph(client,plan=plan,subject_sha='b24ce65a31bf98cd25e4fb72bb1acd09225fcad5',identity=identity,phase='payload')
summary={'result':'PASS' if result['observation'].get('result')=='PASS' and result['observation'].get('required_set_verified') else 'FAIL','collection_id':result['collection'].get('collection_id'),'subject_sha':result['observation'].get('subject_sha'),'check_plan_sha256':result['observation'].get('check_plan_sha256'),'check_count':len(result['observation'].get('checks',[])),'passed_count':sum(1 for x in result['observation'].get('checks',[]) if x.get('conclusion')=='success'),'object_count':len(result['objects']),'raw_member_count':len(result['raw_members']),'output_root':str(out)}
(support/'local-checks/allocation/candidate-1/observer-capture-summary.json').write_text(json.dumps(summary,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n',encoding='utf-8',newline='\n')
print(json.dumps(summary,ensure_ascii=False))
if summary['result']!='PASS' or summary['check_count']!=4 or summary['passed_count']!=4: raise SystemExit(1)
