from __future__ import annotations
import hashlib, json, subprocess, time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path.cwd()
SUPPORT_REF = Path('artifacts/git-delivery-support/T034-r3-18271be3-f0ae-45bf-9d80-3d830ad21038')
SUPPORT = ROOT / SUPPORT_REF
PLAN = SUPPORT / 'check-plan.json'
PLAN_SHA = 'b564d7b7d129051fc1f2fcea17c16d9ba60828db9d2913c33a917b0942d7a4aa'
EXPECTED = 'ee14e15f0169a0a0ec8c4eafd648dbdbc6a2fa95'
OUT = SUPPORT / 'local-checks/payload/attempt-1'

def git(*args: str) -> str:
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True, encoding='utf-8').strip()

def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec='microseconds').replace('+00:00', 'Z')

if git('rev-parse', 'HEAD') != EXPECTED or git('branch', '--show-current') != 'main':
    raise SystemExit('payload checks require the exact T034 code payload SHA on main')
if git('status', '--porcelain', '--untracked-files=no') or git('write-tree') != git('rev-parse', 'HEAD^{tree}'):
    raise SystemExit('payload checks require a clean tracked worktree and index')
if hashlib.sha256(PLAN.read_bytes()).hexdigest() != PLAN_SHA:
    raise SystemExit('frozen T034 check plan SHA mismatch')
if OUT.exists():
    raise SystemExit('payload attempt-1 already exists; preserve and inspect')
OUT.mkdir(parents=True)
commands = [
    ('bootstrap_check', ['python', '-B', 'tools/ci/bootstrap_check.py']),
    ('test_bootstrap_check', ['python', '-B', 'tools/ci/test_bootstrap_check.py']),
    ('delivery_policy_plan', ['python', '-B', 'tools/ci/delivery_policy.py', 'check-plan', '--plan', str(PLAN), '--sha256', PLAN_SHA]),
    ('spec_check', ['python', '-B', 'tools/spec_check/check.py']),
    ('test_spec_check', ['python', '-B', 'tools/spec_check/test_spec_check.py']),
    ('test_delivery_policy', ['python', '-B', 'tools/ci/test_delivery_policy.py']),
    ('test_checkpoint_digest', ['python', '-B', 'tools/ci/test_checkpoint_digest.py']),
    ('go_format', ['python', '-B', 'tools/ci/check_gofmt.py']),
    ('go_test_all', ['go', 'test', './...']),
    ('go_vet_all', ['go', 'vet', './...']),
    ('go_build_all', ['go', 'build', './...']),
]
checks = []
for index, (name, argv) in enumerate(commands, 1):
    started = now()
    tick = time.perf_counter()
    try:
        result = subprocess.run(argv, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=1800, check=False)
        output, exit_code = result.stdout, result.returncode
    except subprocess.TimeoutExpired as exc:
        output, exit_code = exc.stdout or b'', 124
    except OSError as exc:
        output, exit_code = str(exc).encode('utf-8', 'replace'), 127
    completed = now()
    duration = round(time.perf_counter() - tick, 3)
    log = OUT / f'{name}.log'
    log.write_bytes(output)
    checks.append({'name': name, 'argv': argv, 'started_at_utc': started, 'completed_at_utc': completed,
                   'duration_seconds': duration, 'exit_code': exit_code,
                   'log': log.relative_to(SUPPORT).as_posix(), 'log_sha256': hashlib.sha256(output).hexdigest()})
    print(f'{"PASS" if exit_code == 0 else "FAIL"} {index}/{len(commands)} {name} ({duration}s)', flush=True)
    if exit_code:
        print(output.decode('utf-8', 'replace')[-6000:], flush=True)
        break
summary = {'format_version': 1, 'task_id': 'T034', 'task_revision': 3,
           'delivery_id': '18271be3-f0ae-45bf-9d80-3d830ad21038', 'phase': 'payload',
           'subject_sha': EXPECTED, 'parent_sha': git('rev-parse', 'HEAD^'),
           'tree_sha': git('rev-parse', 'HEAD^{tree}'), 'check_plan_sha256': PLAN_SHA,
           'started_at_utc': checks[0]['started_at_utc'] if checks else now(),
           'completed_at_utc': checks[-1]['completed_at_utc'] if checks else now(),
           'result': 'PASS' if len(checks) == len(commands) and all(x['exit_code'] == 0 for x in checks) else 'FAIL',
           'checks': checks}
(OUT / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
if summary['result'] != 'PASS':
    raise SystemExit('T034 payload local checks failed; retained attempt evidence')
