from pathlib import Path
import sys,re,json,hashlib,sqlite3,copy,platform,importlib.metadata,unicodedata
run=Path(__file__).resolve().parent
sys.path.insert(0,str(run/'verification-libs'))

from jsonschema import Draft202012Validator,FormatChecker
import yaml
p=Path(sys.argv[1]).resolve()
source_root=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else p.parent
b=p.read_bytes();s=b.decode('utf-8').replace('\r\n','\n');f=chr(96)*3
checks=[]
def ck(name,condition):
 if not condition:raise AssertionError(name)
 checks.append(name)
def dup(pairs):
 d={}
 for k,v in pairs:
  if k in d:raise ValueError('duplicate key '+k)
  d[k]=v
 return d
def rows(section,nextsection,tag):
 part=s.split('## '+section+' —',1)[1].split('## '+nextsection+' —',1)[0]
 return [re.split(r'(?<!\\)\|',l)[1:-1] for l in part.splitlines() if re.match(r'^\| '+tag+r' \|',l)]
sections=re.findall(r'^## (S\d{2}) —',s,re.M)
ck('54 ordered sections',sections==['S'+str(i).zfill(2) for i in range(54)])
reqs=rows('S01','S02',r'R\d{3}');tasks=rows('S19','S20',r'T\d{3}');cases=rows('S17','S18',r'C\d{3}')
ck('canonical counts 130/108/195',len(reqs)==130 and len(tasks)==108 and len(cases)==195)
rr={r[0].strip():r for r in reqs};tt={r[0].strip():r for r in tasks};cc={r[0].strip():r for r in cases}
ck('unique canonical IDs',len(rr)==130 and len(tt)==108 and len(cc)==195)
expectedT={'T'+str(i).zfill(3) for i in range(1,109)}
ck('task ID sequence',set(tt)==expectedT)
ck('108 TODO/no fake evidence',all(r[6].strip()=='TODO' and r[8].strip()=='NONE' for r in tasks))
edgesR={(id,t) for id,r in rr.items() for t in re.findall(r'T\d{3}',r[4])}
edgesT={(r,t) for t,row in tt.items() for r in re.findall(r'R\d{3}',row[4])}
ck('bidirectional requirement edges',edgesR==edgesT)
cards=[re.split(r'(?<!\\)\|',l)[1:-1] for l in s.split('## S47 —',1)[1].split('## S48 —',1)[0].splitlines() if re.match(r'^\| \d{3} \| T\d{3} \|',l)]
schedule=[r[1].strip() for r in cards];pos={t:i for i,t in enumerate(schedule)}
ck('schedule permutation',len(schedule)==108 and set(schedule)==expectedT)
ck('dependency-before-consumer',all(pos[d]<pos[t] for t,r in tt.items() for d in re.findall(r'T\d{3}',r[2])))
ck('card case parity',all(r[5].strip()==tt[r[1].strip()][5].strip() for r in cards))
ck('all task requirements/cases resolve',all(x in rr for r in tasks for x in re.findall(r'R\d{3}',r[4])) and all(x in cc for r in tasks for x in re.findall(r'C\d{3}',r[5])))
ck('T080 final after T104',pos['T104']<pos['T080'])
fm=yaml.safe_load(s.split('---',2)[1])
ys=re.findall(f+r'yaml\n(.*?)\n'+f,s,re.S)
parsed_y=[yaml.safe_load(x) for x in ys]
resume=next(v['resume'] for v in parsed_y if isinstance(v,dict) and 'resume' in v)
ck('frontmatter/resume1.6.11',fm['spec_version']==resume['spec_version']=='1.6.11')
ck('autonomy scope unchanged',fm['execution_scope']=='ALL_108_TASKS_R1_R2_R3_U0_U1_U2_U3' and resume['required_scope_tasks']==108 and resume['completed_scope_tasks']==0 and resume['intermediate_user_approval'] is False)
ck('product NOT_RUN/not-started',fm['implementation_status']=='NOT_STARTED' and all(resume[k]=='NOT_RUN' for k in ['product_build','product_tests','product_benchmark']))
ck('previous revision SHA',fm['previous_spec_sha256']==hashlib.sha256((run/'baseline.bin').read_bytes()).hexdigest())
markers=re.findall(r'<!-- BEGIN ([A-Z0-9_]+) -->',s)
ck('13 unique matching markers',len(markers)==len(set(markers))==13 and markers==re.findall(r'<!-- END ([A-Z0-9_]+) -->',s))
fences=[l for l in s.splitlines() if l.strip().startswith(f)]
ck('fences balanced',len(fences)%2==0)
blocks={}
for marker in markers:
 m=re.search(r'<!-- BEGIN '+marker+r' -->\n'+f+r'(\w+)\n(.*?)\n'+f,s,re.S)
 ck('marker block '+marker,m is not None)
 if m.group(1)=='json':blocks[marker]=json.loads(m.group(2),object_pairs_hook=dup)
ck('six JSON blocks',len(blocks)==6)
sc=blocks['MCE4D_CONTRACT_SCHEMA_V1'];D=sc['$defs']
ck('155 definitions',len(D)==155)
Draft202012Validator.check_schema(sc)
ck('full Draft2020-12 meta-schema',True)
for k,v in D.items():Draft202012Validator.check_schema(v)
ck('all 155 subschemas meta-valid',True)
refs=[]
def walk(v):
 if isinstance(v,dict):
  if '$ref' in v:refs.append(v['$ref'])
  for x in v.values():walk(x)
 elif isinstance(v,list):
  for x in v:walk(x)
walk(sc)
ck('local references resolved',all(x.startswith('#/$defs/') and x[len('#/$defs/'):] in D for x in refs))
registry=next(v for k,v in blocks.items() if 'REGISTRY' in k)
ck('31 registry mappings resolve',len(registry)==31 and all(len(v)==2 and all(k in D for k in v) for v in registry.values()))
opstr=json.dumps(registry)
ck('private models absent from operation registry',all(k not in opstr for k in ['VolumeAdmissionJournal','VolumeAdmissionEntry','AdmissionOwnedPath','StoredCaptureManifestRef']))
def val(name,x):
 v=Draft202012Validator({'$schema':sc['$schema'],'$ref':'#/$defs/'+name,'$defs':D},format_checker=FormatChecker())
 return v.is_valid(x)
defaults=blocks['MCE4D_RUNTIME_DEFAULTS_V1'];core=defaults['core']
ck('default config schema',val('RuntimeConfig',defaults))
ck('new default values',core['max_indexed_files']==1000000 and core['max_source_bytes_per_snapshot']==34359738368 and core['max_worktree_cache_bytes']==412316860416 and core['max_capture_manifest_bytes']==34359738368 and core['volume_reserve_bytes']==2147483648 and core['volume_warning_bytes']==4294967296 and core['process_tree_rss_budget_bytes']==8589934592 and core['resource_monitor_interval_ms']==250)
ck('shared/memory cross-field defaults',core['volume_warning_bytes']>=core['volume_reserve_bytes']>0 and 10<=core['resource_monitor_interval_ms']<=5000)
cfg=copy.deepcopy(defaults);cfg['core']['max_worktree_cache_bytes']=549755813888;cfg['core']['max_source_bytes_per_snapshot']=68719476736
ck('nondefault caps schema allowed',val('RuntimeConfig',cfg))
for field,value in [('max_indexed_files',1000001),('max_capture_manifest_bytes',34359738369),('volume_reserve_bytes',0),('process_tree_rss_budget_bytes',0),('resource_monitor_interval_ms',5001)]:
 bad=copy.deepcopy(defaults);bad['core'][field]=value
 ck('reject limit '+field,not val('RuntimeConfig',bad))
bad=copy.deepcopy(defaults);bad['core']['unknown_budget']=1
ck('reject unknown runtime key',not val('RuntimeConfig',bad))
UUID='11111111-1111-1111-1111-111111111111';H='1'*64
gp={'schema_version':1,'language':'go','goos':'windows','goarch':'amd64','build_tags':[],'cgo_enabled':False,'tests_enabled':True,'module_roots':['.'],'toolchain_digest':H,'provider_digest':H,'module_mode':'readonly','analysis_mode':'typed_when_available','dependency_roots':[]}
ck('Go profile positive',val('EffectiveProfile',gp))
for field in ['GOOS','GOARCH','budgets','generated_policy','dependency_allowlist','exclusions','trusted_rule_paths','worktree_id']:
 bad=copy.deepcopy(gp);bad[field]='extra'
 ck('old profile field rejected '+field,not val('EffectiveProfile',bad))
def sample(d):
 if '$ref' in d:return sample(D[d['$ref'].split('/')[-1]])
 if 'const' in d:return d['const']
 if 'enum' in d:return d['enum'][0]
 if 'oneOf' in d:return sample(d['oneOf'][0])
 if 'anyOf' in d:return sample(d['anyOf'][0])
 if d.get('type')=='object':return {k:sample(d['properties'][k]) for k in d.get('required',[])}
 if d.get('type')=='array':return [sample(d['items']) for _ in range(d.get('minItems',0))]
 if d.get('type')=='integer':return d.get('minimum',0)
 if d.get('type')=='boolean':return False
 if d.get('type')=='null':return None
 if d.get('type')=='string':
  if d.get('format')=='date-time':return '2026-10-14T00:00:00Z'
  if d.get('pattern','').startswith('^[0-9a-f]{8}'):return UUID
  if d.get('pattern')=='^[0-9a-f]{64}$':return H
  return 'x'*max(1,d.get('minLength',1))
 raise AssertionError(d)
mapping=sample(D['MappingProposeRequest']);ck('mapping positive shape',val('MappingProposeRequest',mapping))
for field in ['actor','revision','status','reason','source_refs','target_anchor_or_selector']:
 bad=copy.deepcopy(mapping);bad[field]='spoofed'
 ck('mapping extra rejected '+field,not val('MappingProposeRequest',bad))
entry={'operation_id':UUID,'scope_kind':'home','worktree_id':None,'owner_identity':'fixture-owner','ownership_ref':'operation-leases/'+UUID+'.lock','operation_kind':'catalog_write','allowed_paths':['catalog.sqlite'],'volume_reserved_remaining_bytes':1048576,'cache_reserved_remaining_bytes':0,'created_at':'2026-10-14T00:00:00Z'}
journal={'format_version':1,'volume_id':'fixture-volume','home_identity':'fixture-home','admission_config_digest':H,'entries':[entry]}
ck('home journal positive',val('VolumeAdmissionJournal',journal))
for label,field,value in [('home-cache','cache_reserved_remaining_bytes',1),('home-UUID','worktree_id',UUID),('home-index','operation_kind','index'),('negative-reserve','volume_reserved_remaining_bytes',-1)]:
 bad=copy.deepcopy(journal);bad['entries'][0][field]=value
 ck('journal rejected '+label,not val('VolumeAdmissionJournal',bad))
bad=copy.deepcopy(journal);bad['entries'][0]['unused']='x';ck('journal unknown reject',not val('VolumeAdmissionJournal',bad))
wt=copy.deepcopy(entry);wt.update(scope_kind='worktree',worktree_id=UUID,operation_kind='record_write',allowed_paths=['worktrees/'+UUID+'/records.sqlite'])
ck('durable worktree positive',val('VolumeAdmissionEntry',wt))
bad=copy.deepcopy(wt);bad['operation_kind']='config_write';ck('worktree-config kind rejected',not val('VolumeAdmissionEntry',bad))
bad=copy.deepcopy(wt);bad['worktree_id']=None;ck('worktree null reject',not val('VolumeAdmissionEntry',bad))
def E(v):
 if v is None:return b'n'
 if v is False:return b'f'
 if v is True:return b't'
 if isinstance(v,int):
  if abs(v)>9007199254740991:raise ValueError('unsafe int')
  return b'i'+str(v).encode()+b';'
 if isinstance(v,str):
  b=v.encode('utf-8');return b's'+str(len(b)).encode()+b':'+b
 if isinstance(v,list):return b'a'+str(len(v)).encode()+b':'+b''.join(E(x) for x in v)
 if isinstance(v,dict):return b'o'+str(len(v)).encode()+b':'+b''.join(E(k)+E(v[k]) for k in sorted(v,key=lambda k:k.encode('utf-8')))
 raise ValueError('unknown/fraction')
vectors=blocks['MCE4D_HASH_VECTORS_V1']['valid']
ck('20 distinct codec vectors',len(vectors)==len({v['case'] for v in vectors})==20)
for v in vectors:
 raw=b'MCE4D\x00C14N1\x00'+E(v['domain'])+E(v['value'])
 ck('codec '+v['case'],raw.hex()==v['encoding_hex'] and hashlib.sha256(raw).hexdigest()==v['digest'])
full=next(v for v in vectors if v['case']=='capture_manifest_full')
ck('full capture schema',val('CaptureManifest',{**full['value'],'snapshot_digest':full['digest']}))
ck('capture raw fixture hash',full['value']['files'][0]['content_hash']==hashlib.sha256(bytes.fromhex('7061636b61676520700d0a')).hexdigest())
for field in ['worktree_id','profile_id','policy_digest','provider_digest']:
 changed=next(v for v in vectors if v['case']=='capture_changed_'+field)
 ck('capture identity changes '+field,changed['digest']!=full['digest'] and val('CaptureManifest',{**changed['value'],'snapshot_digest':changed['digest']}))
 bad={**full['value'],'snapshot_digest':full['digest']};bad.pop(field)
 ck('capture missing rejected '+field,not val('CaptureManifest',bad))
try:json.loads('{"x":1,"x":2}',object_pairs_hook=dup);duplicate_rejected=False
except ValueError:duplicate_rejected=True
ck('duplicate parser counterexample',duplicate_rejected)
for value in [1.5,9007199254740992,'\ud800']:
 try:E(value);failed=False
 except (ValueError,UnicodeError):failed=True
 ck('invalid codec primitive '+repr(value),failed)

# New private manifest physical descriptor fixtures.
ref={'format_version':1,'kind':'external_capture_manifest','path':'manifests/'+full['digest']+'.json','byte_length':len(json.dumps({**full['value'],'snapshot_digest':full['digest']},ensure_ascii=False,separators=(',',':')).encode()),'artifact_sha256':H,'snapshot_digest':full['digest']}
ck('stored capture descriptor positive',val('StoredCaptureManifestRef',ref))
ck('stored descriptor fits4096 bytes',len(json.dumps(ref,separators=(',',':')).encode())<=4096)
for field,value in [('path','../source.go'),('byte_length',34359738369),('kind','inline'),('unknown_key',0)]:
 bad=copy.deepcopy(ref);bad[field]=value
 ck('stored descriptor reject '+field,not val('StoredCaptureManifestRef',bad))
def semantic_entry(x):
 if x['volume_reserved_remaining_bytes']<x['cache_reserved_remaining_bytes']:return False
 if x['ownership_ref']!='operation-leases/'+x['operation_id']+'.lock':return False
 if x['operation_kind'] in ['record_write','evidence_import','backup','log_write','catalog_write','config_write'] and x['cache_reserved_remaining_bytes']!=0:return False
 for path in x['allowed_paths']+[x['ownership_ref']]:
  if len(path.encode('utf-8'))>256 or path.startswith('/') or any(seg in ('','..','.') for seg in path.split('/')) or chr(92) in path or ':' in path or any(ord(c)<32 for c in path):return False
 if x['scope_kind']=='worktree':
  return all(path.startswith('worktrees/'+x['worktree_id']+'/') for path in x['allowed_paths'])
 return True
ck('reference durable entry semantic',semantic_entry(wt))
for field,value in [('cache_reserved_remaining_bytes',1),('allowed_paths',['catalog.sqlite']),('allowed_paths',['worktrees/'+UUID+'/../source.go']),('ownership_ref','operation-leases/other.lock'),('volume_reserved_remaining_bytes',-1)]:
 bad=copy.deepcopy(wt);bad[field]=value
 ck('reference owner/cache reject '+field+str(value),not semantic_entry(bad))
def semantic_limits(x):
 c=x['core']
 return c['volume_warning_bytes']>=c['volume_reserve_bytes']>0 and c['max_file_bytes']<=c['max_source_bytes_per_snapshot'] and c['full_reconcile_interval_ms']>=c['watch_poll_interval_ms']>0 and c['rename_result_max_bytes']<=c['rename_results_max_bytes']<=c['max_worktree_cache_bytes']
ck('reference effective limits defaults',semantic_limits(defaults))
for field,value in [('volume_warning_bytes',1),('max_file_bytes',core['max_source_bytes_per_snapshot']+1),('full_reconcile_interval_ms',1),('rename_results_max_bytes',core['rename_result_max_bytes']-1)]:
 bad=copy.deepcopy(defaults);bad['core'][field]=value
 ck('reference cross-field reject '+field,not semantic_limits(bad))
known=set(sections)|set(rr)|set(tt)|set(cc)
ck('all global S/R/T/C refs resolve',set(re.findall(r'\b(?:S\d{2}|[RTC]\d{3})\b',s))<=known)
ck('fence closing lines exact',all(line.strip()==f for line in fences[1::2]))

# Pure reference arithmetic, not OS/runtime product tests.
GiB=1<<30
def admit(cache,current_future,new_cache,cap,available,volume_future,new_volume,reserve):
 if min(cache,current_future,new_cache,cap,available,volume_future,new_volume,reserve)<0:return False
 return cache+current_future+new_cache<=cap and available>=volume_future+new_volume+reserve
ck('configured512 cap accepts400',admit(300*GiB,50*GiB,50*GiB,512*GiB,150*GiB,50*GiB,50*GiB,2*GiB))
ck('configured128 rejects200 despite384 default',not admit(100*GiB,50*GiB,50*GiB,128*GiB,150*GiB,50*GiB,50*GiB,2*GiB))
ck('durable consumes volume not cache',admit(380*GiB,0,0,384*GiB,100*GiB,16*GiB,8*GiB,2*GiB))
ck('aggregate reserve prevents overbook',not admit(0,0,0,384*GiB,20*GiB,16*GiB,3*GiB,2*GiB))
ck('future-vs-actual not double counted',100+20==108+12)
ck('multi-profile sizing counterexample',3*2+1==7 and 7*48==336)
# Entire schema-valid manifest entry worst-case bound using literal UTF-8/no padding.
maxentry={'path':'\U0001f600'*4096,'status':'metadata_only','content_hash':'f'*64,'byte_length':9007199254740991,'reason_code':'\x01'*192}
rowbytes=len(json.dumps(maxentry,ensure_ascii=False,separators=(',',':')).encode('utf-8'))
upper=rowbytes*1000000+1000000+67*1000000+4096
ck('manifest hard32GiB covers canonical schema max fields',upper<34359738368)
# SQL compatibility and preservation; all in-memory, no WAL patch claim.
sqls=re.findall(r'<!-- BEGIN ([A-Z0-9_]+) -->\n'+f+r'sql\n(.*?)\n'+f,s,re.S)
ck('seven DDL blocks',len(sqls)==7)
dbs={k:sqlite3.connect(':memory:') for k in ['CATALOG','INDEX','RECORDS']}
for con in dbs.values():con.execute('PRAGMA foreign_keys=ON')
for marker,sql in sqls:
 kind=next(k for k in dbs if k in marker)
 dbs[kind].executescript(sql)
for kind,con in dbs.items():
 ck('SQL integrity '+kind,con.execute('PRAGMA integrity_check').fetchall()==[('ok',)])
 ck('SQL FK '+kind,con.execute('PRAGMA foreign_key_check').fetchall()==[])
 con.close()
orig=(run/'baseline.bin').read_bytes().decode().replace('\r\n','\n')
oldsql=re.findall(r'<!-- BEGIN ([A-Z0-9_]+) -->\n'+f+r'sql\n(.*?)\n'+f,orig,re.S)
ck('SQL bytes unchanged',sqls==oldsql)
ck('CRLF no BOM/no stray LF',not b.startswith(b'\xef\xbb\xbf') and b.count(b'\n')==b.count(b'\r\n'))
source_hashes=json.loads((run/'source-hashes.json').read_text())
ck('three policies byte unchanged',all(hashlib.sha256((source_root/k).read_bytes()).hexdigest()==v for k,v in source_hashes.items()) and len(source_hashes)==3)
# Rendering structure: each contiguous table has header-width rows.
table_errors=[];width=None;in_fence=False
for lineno,l in enumerate(s.splitlines(),1):
 if l.strip().startswith(f):in_fence=not in_fence;continue
 if in_fence:continue
 if l.startswith('|'):
  if not l.endswith('|'):table_errors.append((lineno,'missing terminal pipe',l[:120]))
  n=len(re.split(r'(?<!\\)\|',l))-2
  if width is None:width=n
  elif n!=width:table_errors.append((lineno,width,n,l[:120]))
 else:width=None
ck('all GFM table row widths',not table_errors)
ck('no remaining current version conflict','Bản hiện tại1.6.0' not in s and 'Đặc tả v1.6.0 là' not in s and 'V1.6.0 construction routing' not in s)
ck('12 closures/discrepancies',len(re.findall(r'^\| N\d{2} ',s,re.M))==12 and all('| D'+str(i).zfill(3)+' |' in s for i in range(9,21)))
# Governance structural assertions and pure observer-policy counterexamples.
# These do not call GitHub or prove host/remote enforcement.
aw=s.split('### AW-08 —',1)[1]
ck('seven Git governance subclauses',re.findall(r'^#### (GIT-\d{2})',aw,re.M)==['GIT-'+str(i).zfill(2) for i in range(1,8)])
ck('AW08 generic all-card requirement','Mọi hàng bắt buộc AW-08' in s and 'per-task Git delivery AW-08' in s)
ck('Git frontmatter/resume policy',fm['git_delivery_policy']=='REQUIRED_PER_TASK_S53_AW_08' and resume['git_delivery_policy']=='S53_AW_08')
ck('Git initialized unborn no remote and no CI claim',fm['git_repository_status']=='INITIALIZED_UNBORN_NO_REMOTE' and fm['github_verification_status']=='NOT_RUN' and resume['git_delivery']['repository_status']=='INITIALIZED_UNBORN_NO_REMOTE' and resume['git_delivery']['last_ci_result']=='NOT_RUN')
ck('108 assignment and single final acceptance kept',fm['owner_acceptance']=='ONCE_AFTER_FINAL_ENGINEERING_COMPLETION' and resume['final_user_acceptance']=='once_after_engineering_complete')
ck('bootstrap actual workflow paths', 'bootstrap CI thực' in tt['T001'][3] and '.github/workflows/' in cards[0][3] and 'real bootstrap checks' in cards[0][3] and 'T001 delivery đầu' in aw)
ck('T003 actual observer plan','observer boundary' in tt['T003'][3] and 'observer tooling' in aw)
ck('receipt proof task edges',('R129','T107') in edgesR and 'C189' in tt['T107'][5])
ck('receipt minimum metadata',all(x in s for x in ['verified_payload_sha','expected_check_plan_ref','observed_remote_sha','source_app','closing_commit_ref','protection inspection status']))
ck('Vietnamese syntax and real task IDs','[P1][T020] Chụp snapshot và kiểm tra manifest' in aw and 'subject/body tiếng Việt có dấu' in aw)
ck('dependency before priority','Dependencies quyết định trước' in aw and 'P0 → P1 → P2 → P3' in aw)
ck('no giant commit/no arbitrary fragments','MUST NOT gom nhiều task/phase/toàn dự án' in aw and 'Một task nhỏ có một mục đích được một payload commit' in aw)
ck('automatic repair and new SHA','new Vietnamese fix commit(s)' in aw and 'observe SHA mới' in aw)
ck('no bypass and identity fabrication',all(x in aw for x in ['--no-verify','HUSKY=0','continue-on-error','Không đổi global identity','không amend/rebase published']))
ck('PR merge/source binding and status sources',all(x in aw for x in ['check-runs VÀ commit statuses','head_sha/base_sha/tested_merge_sha','merge_group','đúng source app']))
ck('GitHub security workflow policy',all(x in aw for x in ['least-privilege','full commit SHA','untrusted fork']))
ck('closing observer has no self CI dependency','không wait own running CI' in aw and 'effective VERIFY' in aw and 'không commit thêm chỉ ghi ownSHA/own CI result' in aw)
ck('final latest remote checks condition','remote branch HEAD đúng final combined revision' in s and 'latest closing HEAD' in aw)
ck('K015 discovery synchronized','K015' in resume['discovery_gaps'] and '| K015 |' in s)
ck('ADR and dated changelog', '| A044 |' in s and '| 1.6.3 | 2026-10-15 |' in s)
ck('official policy sources four added',all('| REF'+str(i)+' |' in s for i in range(60,64)))
ck('old contradictory blanket push prohibition removed','Target repo source và MCE4D source đều không auto commit/push ngoài yêu cầu.' not in s)
def delivery_ok(payload,remote,expected,observed,closing_pending=False,policy_known=True):
  # Historical scalar micro-fixtures only; normative delivery oracle is delivery_core.effective_done.
 if closing_pending or not policy_known or payload!=remote or not expected:return False
 for name,app in expected:
  attempts=[x for x in observed if (x['name'],x['app'])==(name,app) and x['sha']==payload]
  if not attempts:return False
  result=max(attempts,key=lambda x:x['attempt'])
  if result['status']!='completed' or result['conclusion']!='success' or not result['tests_executed']:return False
 return True
P='a'*40;Q='b'*40
plan=[('contract','actions'),('lint','actions')]
obs=[{'name':n,'app':a,'sha':P,'attempt':1,'status':'completed','conclusion':'success','tests_executed':True} for n,a in plan]
ck('reference current expected checks accepted',delivery_ok(P,P,plan,obs))
ck('reference wrong remote SHA rejected',not delivery_ok(P,Q,plan,obs))
ck('reference empty check plan rejected',not delivery_ok(P,P,[],obs))
ck('reference missing check rejected',not delivery_ok(P,P,plan,obs[:1]))
ck('reference wrong source rejected',not delivery_ok(P,P,plan,[{**x,'app':'other'} for x in obs]))
ck('reference stale check SHA rejected',not delivery_ok(P,P,plan,[{**x,'sha':Q} for x in obs]))
for conclusion in ['failure','cancelled','timed_out','action_required','skipped','neutral']:
 ck('reference non-pass '+conclusion,not delivery_ok(P,P,plan,[{**obs[0],'conclusion':conclusion},obs[1]]))
for status in ['queued','in_progress','waiting']:
 ck('reference nonterminal '+status,not delivery_ok(P,P,plan,[{**obs[0],'status':status},obs[1]]))
ck('reference newer failed attempt dominates old green',not delivery_ok(P,P,plan,obs+[{**obs[0],'attempt':2,'conclusion':'failure'}]))
ck('reference non-executed steps rejected',not delivery_ok(P,P,plan,[{**obs[0],'tests_executed':False},obs[1]]))
ck('reference candidate closing still VERIFY',not delivery_ok(P,P,plan,obs,closing_pending=True))
ck('reference unknown required set rejected',not delivery_ok(P,P,plan,obs,policy_known=False))
origblocks={m:json.loads(body) for m,body in re.findall(r'<!-- BEGIN ([A-Z0-9_]+) -->\n'+f+r'json\n(.*?)\n'+f,orig,re.S)}
ck('runtime defaults and registry unchanged',all(blocks[m]==v for m,v in origblocks.items() if m not in ['MCE4D_CONTRACT_SCHEMA_V1','MCE4D_HASH_VECTORS_V1','MCE4D_GIT_GOVERNANCE_SCHEMA_V1']))
olddefs=origblocks['MCE4D_CONTRACT_SCHEMA_V1']['$defs']
ck('154 runtime definitions unchanged',all(D[k]==v for k,v in olddefs.items() if k not in ['RuntimeConfigData']))
ck('all 20 old vectors unchanged',blocks['MCE4D_HASH_VECTORS_V1']['valid']==origblocks['MCE4D_HASH_VECTORS_V1']['valid'])
exec(compile((run/'verify_findings.py').read_text(encoding='utf-8'),str(run/'verify_findings.py'),'exec'))

total_claim=len(checks)+1
expected_claim='PASS_'+str(total_claim)+'_DOCUMENT_REFERENCE_CHECKS_20_CODEC_2_RAW_NODE_5_PROCESS_EXIT_BOUNDARIES_1_6_11_PRODUCT_AND_GITHUB_NOT_RUN'
if fm['document_structural_validation']!=expected_claim or str(total_claim)+'/'+str(total_claim)+' Python assertions' not in s:raise AssertionError('current validation claim expected_total='+str(total_claim))
ck('M current validation claim synchronized',True)

semantic_hash=hashlib.sha256(json.dumps(sc,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
default_hash=hashlib.sha256(json.dumps(defaults,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
result={'spec_version':'1.6.11','sha256':hashlib.sha256(b).hexdigest(),'checks_passed':len(checks),'checks_failed':0,'counts':{'sections':54,'requirements':130,'tasks':108,'cases':195,'requirement_task_edges':len(edgesR),'definitions':len(D),'local_refs':len(refs),'vectors':len(vectors),'governance_definitions':len(G),'raw_manifest_vectors':len(rawvectors)},'schema_semantic_sha256':semantic_hash,'defaults_semantic_sha256':default_hash,'manifest_max_field_upper_bound_bytes':upper,'archive_io':archive_io_summary,'toolchain':{'python':platform.python_version(),'sqlite':sqlite3.sqlite_version,'jsonschema':importlib.metadata.version('jsonschema')},'checks':checks,'scope':'document/meta-schema/pure-governance/in-memory-SQL plus bounded Windows process-exit I/O; product/driver/browser/XL/full OS safety/GitHub NOT_RUN'}
(run/'validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='checks'},ensure_ascii=False,indent=2))
