"""Independent v169 review reproductions plus current boundary tests, synthetic only."""
def verify_review1610():
    before_count=len(checks)
    g=globals()
    def live_ob(x):return g['typed'](x['lf'],x['live']['closing_observation_ref'],'GitDeliveryObservation')
    def keep_live(x,o):
     x['lf'][x['live']['closing_observation_ref']]=g['C14'](o)
     x['live']['files']=g['manifest_for'](x['lf'])
    res=[]
    def probe(name,x,expect):
     actual=g['evaluate169'](x);res.append(dict(name=name,expected=expect,actual=actual));ck('W review '+name,actual==expect)
    x=g['prepared169']();probe('baseline',x,True)
    x=g['prepared169']()
    x['pl']['checks'][0]['eligible_events']=['push','pull_request']
    g['rebind166'](x)
    x['live'],x['lf'],x['ctx']=g['make_live_fixture'](x['at'],x['pl'],x['ob'],x['ar'],x['fs'])
    probe('two eligible events baseline push',x,True)
    o=live_ob(x)
    for v in o['checks']:
     v.update(event='pull_request',run_id='7300',job_id='8300')
     g['put_check_evidence'](x['lf'],v,g['C'],'live-pr-event',req=x['pl']['checks'][0])
    g['make_collection_fixture'](x['pl'],o,x['lf'],x['live']['started_at_utc'],x['live']['completed_at_utc'])
    keep_live(x,o)
    probe('live changes event without proven PR canary',x,False)
    v={**copy.deepcopy(x['po']['checks'][0]),'event':'pull_request','run_id':'999','job_id':'1999'}
    g['put_check_evidence'](x['fs'],v,g['P'],'payload-pr-canary',req=x['pl']['checks'][0]);x['po']['checks'].append(v)
    g['rebind166'](x);g['rehash_publication_fixture'](x['ar'],x['live'],x['ctx'])
    probe('live PR event with actual PR canary',x,True)
    # A historical PR success followed by a PR run with no jobs, then a valid
    # push run. The event-specific PR canary must stay blocked by its newer run.
    x=g['prepared169'](pr=True);g['historical_canary169'](x,False,False)
    can=g['typed'](x['fs'],'canary-evidence.json','GitCanaryEvidence')
    cp=g['typed'](x['fs'],can['check_plan_ref'],'GitCheckPlan')
    co=g['typed'](x['fs'],can['observation_ref'],'GitDeliveryObservation')
    cp['checks'][0]['eligible_events']=['push','pull_request']
    v={**copy.deepcopy(co['checks'][0]),'run_id':'8998','job_id':'9998','event':'pull_request'}
    g['put_check_evidence'](x['fs'],v,g['P'],'pr-canary-old',req=cp['checks'][0]);co['checks'].append(v)
    co['check_plan_sha256']=g['hashlib'].sha256(g['C14'](cp)).hexdigest()
    x['fs'][can['check_plan_ref']]=g['C14'](cp)
    coll=g['make_collection_fixture'](cp,co,x['fs'])
    x['fs'][can['observation_ref']]=g['C14'](co);g['retain169'](x)
    probe('historical real PR canary positive',x,True)
    for page in coll['pages']:
     if page['endpoint']=='workflow_runs' and page['requested_sha']==g['P']:
      raw=g['load_member'](x['fs'],page['raw_page_ref'])
      raw['items'].append({'run_id':'8999','run_attempt':1,'head_sha':g['P'],'workflow_path':cp['checks'][0]['workflow_path'],'event':'pull_request','created_at':g['now'],'status':'queued','conclusion':None,'job_source_refs':[]})
      x['fs'][page['raw_page_ref']]=g['C14'](raw)
    g['retain169'](x)
    probe('newer PR canary generation with no jobs',x,False)
    v={**copy.deepcopy(co['checks'][-1]),'run_id':'8999','job_id':'9999'}
    g['put_check_evidence'](x['fs'],v,g['P'],'pr-canary-new',req=cp['checks'][0]);co['checks'].append(v)
    g['make_collection_fixture'](cp,co,x['fs']);x['fs'][can['observation_ref']]=g['C14'](co);g['retain169'](x)
    probe('newer PR canary with real successful job',x,True)
    
    # No-op on a previously delivered closing HEAD: prior message/scope are history.
    x=g['prepared169'](pr=True);g['later_task169'](x)
    probe('T002 no-op ordinary existing payload',x,True)
    old=copy.deepcopy(g['typed'](x['fs'],x['ar']['closing_commit_ref'],'GitCommit'))
    old.update(sha=g['P'],subject=old['subject'].replace('[T002]','[T001]'),body=old['body'].replace(g['U'],g['U2']),scope_ref='scope/prior-closing',git_evidence_ref='prior-closing-snapshot.json')
    scope=copy.deepcopy(g['typed'](x['fs'],'scope/closing','GitCommitScopeEvidence'));scope['task_ids']=['T001']
    x['fs'][old['scope_ref']]=g['C14'](scope)
    parents=g['load_member'](x['fs'],x['ar']['git_evidence_ref']);parents[g['P']]=[g['Q']];parents[g['Q']]=[];x['fs'][x['ar']['git_evidence_ref']]=g['C14'](parents)
    x['fs'][old['git_evidence_ref']]=g['C14']({'kind':'git_commit_snapshot','sha':g['P'],'parents':[g['Q']],'subject':old['subject'],'body':old['body'],'changed_paths':scope['changed_paths']})
    prior_at={**x['at'],'task_id':'T001','delivery_id':g['U2'],'verified_payload_sha':g['Q']}
    a=g['commit_ok'](old,prior_at,parents,x['fs'],'closing');res.append(dict(name='prior closing is valid in its own delivery',expected=True,actual=a));ck('W review prior closing is valid in its own delivery',a)
    x['at']['ordered_commits']=[old];g['retain169'](x)
    probe('T002 no-op on previous closing HEAD',x,True)
    
    # The current operation's lifecycle/retry/ref must be compared on resume.
    x=g['prepared169']();op=g['typed'](x['fs'],x['ob']['destination_observation']['operation_evidence_ref'],'GitPushOperationEvidence')
    cmd=g['typed'](x['fs'],op['command_record_ref'],'GitCommandLifecycle')
    checkpoint={**g['valid_checkpoint'],'command_record_ref':op['command_record_ref'],'operation_id':op['push_operation_id'],'command_state':'SUCCEEDED'}
    actual={**g['actual_checkpoint'],'operation_id':op['push_operation_id'],'command_state':'SUCCEEDED','command_record_ref':op['command_record_ref'],'lifecycle_id':op['lifecycle_id'],'retry_index':op['retry_index']}
    actual=g['checkpoint_actual_fixture'](actual,op['command_record_ref'],x['fs'],x['ob']['destination_observation']['operation_evidence_ref'])
    def cp_probe(name,expect,fs):
     a=g['checkpoint_ok'](checkpoint,x['sel'],actual,fs);res.append(dict(name=name,expected=expect,actual=a));ck('W review '+name,a==expect)
    cp_probe('checkpoint exact current lifecycle',True,x['fs'])
    for field,value in [('lifecycle_id',g['U2']),('retry_index',1)]:
     swapped={**cmd,field:value};fs={**x['fs'],op['command_record_ref']:g['C14'](swapped)}
     cp_probe('checkpoint wrong '+field,False,fs)
     ck('W mismatched checkpoint command also fails push '+field,not g['destination_ok'](x['pl'],x['ob']['destination_observation'],g['C'],fs))
    # Scoped task metadata must route to the task's actual gate, not always G0.
    x=g['prepared169'](pr=True);g['later_task169'](x)
    for key in ['at','ar','sel']:
     x[key]=json.loads(json.dumps(x[key]).replace('T002','T005'))
    x['fs']={k:v.replace(b'T002',b'T005') for k,v in x['fs'].items()}
    g['retain169'](x)
    x['live'],x['lf'],x['ctx']=g['make_live_fixture'](x['at'],x['pl'],x['ob'],x['ar'],x['fs'],x['current_pr']['closing'])
    probe('T005 G1 task baseline closure',x,True)
    for gate,expected in [('G1',True),('G0',False)]:
     changes=['S19/T005/Status','S20/'+gate+'/status']
     actual=g['effective_done'](x['at'],x['pl'],x['ob'],x['ar'],x['fs'],[x['ca']],changes,g['C'],sel=x['sel'],seal_record=g['seal_for'](x['ar']),published=True,live_verification=x['live'],live_files=x['lf'],live_context=x['ctx'])
     res.append(dict(name='T005 updates '+gate+' gate',expected=expected,actual=actual));ck('W review T005 updates '+gate+' gate',actual==expected)
    
    prior=json.loads((run/'regression-1.6.9.json').read_text(encoding='utf-8'))
    ck('W all16 prior probe names and expectations retained',[(v['name'],v['expected']) for v in res]==[(v['name'],v['expected']) for v in prior] and len(res)==16)
    cases=[]
    def test(name,actual,expected,group):
        ck('W '+name,actual==expected)
        cases.append(dict(group=group,name=name,actual=actual,expected=expected))
    # P1 live coverage: freeze explicit collector inputs before evaluation.
    def live_event_case(proven=False):
        z=prepared169();z['pl']['checks'][0]['eligible_events']=['push','pull_request']
        if proven:
            v={**copy.deepcopy(z['po']['checks'][0]),'event':'pull_request','run_id':'999','job_id':'1999'}
            put_check_evidence(z['fs'],v,P,'current-pr-canary',req=z['pl']['checks'][0]);z['po']['checks'].append(v)
        rebind166(z);z['live'],z['lf'],z['ctx']=make_live_fixture(z['at'],z['pl'],z['ob'],z['ar'],z['fs'])
        o=live_ob(z)
        for v in o['checks']:
            v.update(event='pull_request',run_id='7300',job_id='8300');put_check_evidence(z['lf'],v,C,'current-pr-event',req=z['pl']['checks'][0])
        make_collection_fixture(z['pl'],o,z['lf'],z['live']['started_at_utc'],z['live']['completed_at_utc']);keep_live(z,o)
        return z
    for proven in [False,True]:
        z=live_event_case(proven);frozen=copy.deepcopy(z)
        test('repeated live event coverage '+str(proven),evaluate169(z) and evaluate169(z),proven,'V169-01')
        test('live guard never mutates archive/inputs '+str(proven),z==frozen,True,'V169-01')
    z=live_event_case(True)
    # A new invocation reuses exact publication and sealed archive facts.
    before_archive=copy.deepcopy((z['ar'],z['fs']))
    z['live']['verification_id']=U2;z['ctx']['verification_id']=U2
    test('new invocation keeps proven events',evaluate169(z),True,'V169-01')
    test('new invocation archive immutable',(z['ar'],z['fs'])==before_archive,True,'V169-01')

    # P1 no-job generation variants; newest push must not cover newest PR.
    def generation_case(status='queued',conclusion=None,created=now):
        z=prepared169(pr=True);historical_canary169(z,False,False)
        can=typed(z['fs'],'canary-evidence.json','GitCanaryEvidence');cp=typed(z['fs'],can['check_plan_ref'],'GitCheckPlan');co=typed(z['fs'],can['observation_ref'],'GitDeliveryObservation')
        cp['checks'][0]['eligible_events']=['push','pull_request']
        v={**copy.deepcopy(co['checks'][0]),'run_id':'8998','job_id':'9998','event':'pull_request'}
        put_check_evidence(z['fs'],v,P,'generation-old-pr',req=cp['checks'][0]);co['checks'].append(v)
        co['check_plan_sha256']=hashlib.sha256(C14(cp)).hexdigest();z['fs'][can['check_plan_ref']]=C14(cp)
        collection=make_collection_fixture(cp,co,z['fs'])
        for page in collection['pages']:
            if page['endpoint']=='workflow_runs' and page['requested_sha']==P:
                raw=load_member(z['fs'],page['raw_page_ref']);raw['items'].append(dict(run_id='8999',run_attempt=1,head_sha=P,workflow_path=cp['checks'][0]['workflow_path'],event='pull_request',created_at=created,status=status,conclusion=conclusion,job_source_refs=[]));z['fs'][page['raw_page_ref']]=C14(raw)
        z['fs'][can['observation_ref']]=C14(co);retain169(z)
        return z,can,cp,co,collection
    for state,conclusion in [('queued',None),('in_progress',None),('waiting',None),('completed','success'),('completed','failure'),('completed','cancelled'),('completed','neutral'),('completed','skipped')]:
        z,can,cp,co,coll=generation_case(state,conclusion)
        test('per-event no required job '+state+'/'+str(conclusion),evaluate169(z),False,'V169-02')
        test('per-event missing job never proven '+state+'/'+str(conclusion),'pull_request' in canary_proven_events(cp,co,z['fs']),False,'V169-02')
    for created,expected in [(before,True),('2026-10-15T10:00:00+07:00',False),('2026-10-15T03:00:00.000Z',False),('2026-10-15T03:00:00.1Z',False)]:
        z,can,cp,co,coll=generation_case(created=created)
        test('per-event parsed generation '+created,evaluate169(z),expected,'V169-02')
    z,can,cp,co,coll=generation_case()
    # Missing terminal pagination still blocks before any per-event selection.
    page=coll['pages'][0];page['next_page_number']=2;z['fs'][co['collection_evidence_ref']]=C14(coll);retain169(z)
    test('per-event incomplete collection blocks',evaluate169(z),False,'V169-02')

    # P2 current command context is secured independently from the checkpoint.
    z=prepared169();d=z['ob']['destination_observation'];op=typed(z['fs'],d['operation_evidence_ref'],'GitPushOperationEvidence');cmd=typed(z['fs'],op['command_record_ref'],'GitCommandLifecycle')
    cp={**valid_checkpoint,'command_record_ref':op['command_record_ref'],'operation_id':op['push_operation_id'],'command_state':'SUCCEEDED'}
    actual=checkpoint_actual_fixture({**actual_checkpoint,'operation_id':op['push_operation_id'],'command_state':'SUCCEEDED'},op['command_record_ref'],z['fs'],d['operation_evidence_ref'])
    for state in ['NOT_STARTED','RUNNING','SETTLING','SUCCEEDED','FAILED','UNKNOWN']:
        checkpoint={**cp,'command_state':state};fs={**z['fs'],op['command_record_ref']:C14(command_fixture(checkpoint_like=checkpoint,op=op,destination=d,at=z['at']))}
        secured=checkpoint_actual_fixture({**actual,'command_state':state},op['command_record_ref'],fs,d['operation_evidence_ref'])
        test('current command state '+state,checkpoint_ok(checkpoint,z['sel'],secured,fs),True,'V169-03')
    for key,value in [('command_record_ref','missing.json'),('command_record_sha256','0'*64),('lifecycle_id',U2),('retry_index',1),('push_operation_ref','missing.json')]:
        test('current binding wrong '+key,checkpoint_ok(cp,z['sel'],{**actual,key:value},z['fs']),False,'V169-03')
        missing={k:v for k,v in actual.items() if k!=key}
        test('current binding missing '+key,checkpoint_ok(cp,z['sel'],missing,z['fs']),False,'V169-03')
    for key,value in [('lifecycle_id',U2),('retry_index',1),('command_record_ref','other.json'),('push_operation_id',U2)]:
        fs={**z['fs'],d['operation_evidence_ref']:C14({**op,key:value})}
        test('current push operation mismatch '+key,checkpoint_ok(cp,z['sel'],actual,fs),False,'V169-03')
    changed={**cmd,'retry_index':1};fs={**z['fs'],op['command_record_ref']:C14(changed)}
    rehashed={**actual,'command_record_sha256':hashlib.sha256(fs[op['command_record_ref']]).hexdigest()}
    test('matching digest cannot hide wrong current retry',checkpoint_ok(cp,z['sel'],rehashed,fs),False,'V169-03')
    rehashed['retry_index']=1
    test('matching command cannot hide wrong operation retry',checkpoint_ok(cp,z['sel'],rehashed,fs),False,'V169-03')
    no_command={**valid_checkpoint,'command_record_ref':None,'operation_id':None,'command_state':'NOT_STARTED'}
    unallocated=checkpoint_actual_fixture({**actual_checkpoint,'operation_id':None,'command_state':'NOT_STARTED'})
    test('truly unallocated current command',checkpoint_ok(no_command,z['sel'],unallocated,z['fs']),True,'V169-03')
    test('unallocated cannot retain stale lifecycle',checkpoint_ok(no_command,z['sel'],{**unallocated,'lifecycle_id':U},z['fs']),False,'V169-03')

    # P2 existing closing HEAD remains immutable history during a no-op.
    def noop_history_case():
        z=prepared169(pr=True);later_task169(z)
        record=copy.deepcopy(typed(z['fs'],z['ar']['closing_commit_ref'],'GitCommit'))
        record.update(sha=P,subject=record['subject'].replace('[T002]','[T001]'),body=record['body'].replace(U,U2),scope_ref='scope/history',git_evidence_ref='history-git.json')
        scope=copy.deepcopy(typed(z['fs'],'scope/closing','GitCommitScopeEvidence'));scope['task_ids']=['T001'];z['fs'][record['scope_ref']]=C14(scope)
        parents=load_member(z['fs'],z['ar']['git_evidence_ref']);parents[P]=[Q];parents[Q]=[];z['fs'][z['ar']['git_evidence_ref']]=C14(parents)
        raw=dict(kind='git_commit_snapshot',sha=P,parents=[Q],subject=record['subject'],body=record['body'],changed_paths=scope['changed_paths'])
        z['fs'][record['git_evidence_ref']]=C14(raw);z['at']['ordered_commits']=[record];retain169(z)
        return z,record,scope,parents,raw
    z,record,scope,parents,raw=noop_history_case();frozen=copy.deepcopy(z)
    test('original closing no-op idempotent',evaluate169(z) and evaluate169(z),True,'V169-04')
    test('original metadata and context never rewritten',z==frozen,True,'V169-04')
    test('normal payload cannot reuse closing scope/trailers',commit_ok(record,{**z['at'],'payload_mode':'changes'},parents,z['fs'],'payload'),False,'V169-04')
    for label,change in [('active UUID',lambda z,r,sc,p,raw:r.update(body=r['body'].replace(U2,U))),('duplicate trailer',lambda z,r,sc,p,raw:r.update(body=r['body']+'\nMCE4D-Delivery-ID: '+U2)),('wrong actual message',lambda z,r,sc,p,raw:raw.update(subject='docs(progress): [P1][T001] Nội dung khác')),('wrong original phase',lambda z,r,sc,p,raw:sc.update(phase='payload')),('wrong original task',lambda z,r,sc,p,raw:sc.update(task_ids=['T003'])),('missing parent',lambda z,r,sc,p,raw:p.update({P:[]})),('multiple parents',lambda z,r,sc,p,raw:p.update({P:[Q,C]})),('self parent',lambda z,r,sc,p,raw:p.update({P:[P]}))]:
        z,r,sc,parents,raw=noop_history_case();change(z,r,sc,parents,raw)
        z['fs'][r['scope_ref']]=C14(sc);z['fs'][r['git_evidence_ref']]=C14(raw);z['fs'][z['ar']['git_evidence_ref']]=C14(parents);retain169(z)
        test('invalid historical reuse '+label,evaluate169(z),False,'V169-04')

    # P2 every canonical task has exactly its own S20 gate metadata scope.
    seen_gates=set()
    for task,row in sorted(tt.items()):
        label=row[1].strip();gate={'R2':'G6','R3':'G7','U0':'GU0','U1':'GU1','U2':'GU2','U3':'GU3'}.get(label,label);seen_gates.add(gate)
        own=['S19/'+task+'/Status','S20/'+gate+'/status','S20/'+gate+'/evidence']
        wrong='G1' if gate=='G0' else 'G0'
        test('own gate leaf scope '+task,closing_diff_ok(own,task_id=task),True,'V169-05')
        test('wrong gate leaf scope '+task,closing_diff_ok(['S19/'+task+'/Status','S20/'+wrong+'/status'],task_id=task),False,'V169-05')
    test('all12 canonical gates exercised',seen_gates=={'G'+str(i) for i in range(8)}|{'GU'+str(i) for i in range(4)},True,'V169-05')
    for paths,task in [(['S20/G0/status'],'T999'),(['S19/T002/Status'],'T001'),(['S20/G0/schema'],'T001'),(['S20/G0/status','S43/schema'],'T001'),(['S20/GU0/status'],'T080'),(['S20/G0/status'],'T080')]:
        test('unknown or out-of-scope leaf '+task+str(paths),closing_diff_ok(paths,task_id=task),False,'V169-05')
    test('source byte delta blocks otherwise allowed leaves',closing_diff_ok(['S20/G0/status'],other_bytes_equal=False,task_id='T001'),False,'V169-05')
    test('metadata/current closure synchronized',fm['spec_version']==resume['spec_version']=='1.6.11' and resume['latest_review_baseline']=='1.6.10' and resume['latest_review_closure']=='S52_CLOSE_11' and all(v in s for v in ['A051','D059','D060','D061','D062','D063','CANARY-LIVE-01','CANARY-GENERATION-01','CHECKPOINT-CURRENT-01','NOOP-HISTORY-01','CLOSE-GATE-01']),True,'sync')
    result={'spec_version':'1.6.10','groups_closed':5,'prior_review_probes':res,'prior_mismatches':7,'current_mismatches':sum(v['actual']!=v['expected'] for v in res),'prior_controls_preserved':9,'new_assertions':len(checks)-before_count,'cases':cases,'scope':'Document/reference synthetic inputs only. Product/Git/CI/collector/OS NOT_RUN.'}
    (run/'review-1.6.10-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')

verify_review1610()
