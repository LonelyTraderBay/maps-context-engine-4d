# Document reference fixtures only. No Git calls, product implementation, or deletion.
G=blocks['MCE4D_GIT_GOVERNANCE_SCHEMA_V1']['$defs']
gsc=blocks['MCE4D_GIT_GOVERNANCE_SCHEMA_V1']
Draft202012Validator.check_schema(gsc)
ck('governance 9 closed definitions meta-valid',len(G)==9 and all(x.get('additionalProperties') is False for x in G.values()))
def gv(name,value):return Draft202012Validator({'$schema':gsc['$schema'],'$defs':G,'$ref':'#/$defs/'+name},format_checker=FormatChecker()).is_valid(value)
grefs=[]
def gw(v):
 if isinstance(v,dict):
  if '$ref' in v:grefs.append(v['$ref'])
  for x in v.values():gw(x)
 elif isinstance(v,list):
  for x in v:gw(x)
gw(gsc)
ck('governance refs resolve',all(x.startswith('#/$defs/') and x.split('/')[-1] in G for x in grefs))
ck('governance not runtime operation registry',not any(k in json.dumps(registry) for k in G))
def canonical(v):
 if v is None:return b'null'
 if v is False:return b'false'
 if v is True:return b'true'
 if isinstance(v,int):
  if abs(v)>9007199254740991:raise ValueError('unsafe integer')
  return str(v).encode('ascii')
 if isinstance(v,str):
  v.encode('utf-8')
  return json.dumps(v,ensure_ascii=False,separators=(',',':')).replace('\u2028','\\u2028').replace('\u2029','\\u2029').encode('utf-8')
 if isinstance(v,list):return b'['+b','.join(canonical(x) for x in v)+b']'
 if isinstance(v,dict):return b'{'+b','.join(canonical(k)+b':'+canonical(v[k]) for k in sorted(v,key=lambda x:x.encode('utf-8')))+b'}'
 raise ValueError('non-JSON/fraction')
rawvectors=blocks['MCE4D_HASH_VECTORS_V1']['manifest_serialization']
ck('two raw manifest goldens',len(rawvectors)==2)
def reverse_keys(v):
 if isinstance(v,dict):return {k:reverse_keys(x) for k,x in reversed(list(v.items()))}
 if isinstance(v,list):return [reverse_keys(x) for x in v]
 return v
for v in rawvectors:
 raw=canonical(v['value'])
 ck('canonical raw golden '+v['case'],raw.hex()==v['utf8_hex'] and len(raw)==v['byte_length'] and hashlib.sha256(raw).hexdigest()==v['artifact_sha256'])
 ck('canonical key reorder '+v['case'],canonical(reverse_keys(v['value']))==raw)
 ck('literal vs escaped Unicode '+v['case'],canonical(json.loads(json.dumps(v['value'],ensure_ascii=True)))==raw)
 value=copy.deepcopy(v['value']);sd=value.pop('snapshot_digest')
 ck('raw golden schema and logical digest '+v['case'],val('CaptureManifest',v['value']) and hashlib.sha256(b'MCE4D\0C14N1\0'+E('capture-v1')+E(value)).hexdigest()==sd)
 ck('raw artifact noncanonical rejected '+v['case'],json.dumps(reverse_keys(v['value']),ensure_ascii=False,separators=(',',':')).encode()!=raw)
esc={'x':'\x00\b\f\n\r\t/<> &\u2028\u2029😀'}
ck('exact control/slash/HTML/U2028 escapes',canonical(esc)==b'{"x":"\\u0000\\b\\f\\n\\r\\t/<> &\\u2028\\u2029'+chr(0x1f600).encode()+b'"}')
ck('UTF8 not UTF16 key sorting',canonical({'\U00010000':1,'\ue000':2}).startswith(b'{"'+chr(0xe000).encode()+b'":2,'))
for x in [1.5,9007199254740992,'\udfff']:
 try:canonical(x);bad=False
 except (ValueError,UnicodeError):bad=True
 ck('physical canonical invalid '+repr(x),bad)

# F04 hardcaps are fixed while repo/source defaults can grow.
for field,cap in [('rename_result_max_bytes',33554432),('rename_results_max_bytes',134217728),('query_result_cache_bytes',33554432),('max_retained_query_results',32)]:
 good=copy.deepcopy(defaults);good['core'][field]=cap
 ck('result cap boundary accepted '+field,val('RuntimeConfig',good))
 good['core'][field]=cap+1
 ck('result cap plus1 rejected '+field,not val('RuntimeConfig',good))
 good['core'][field]=max(1,cap//2)
 ck('result lower cap accepted '+field,val('RuntimeConfig',good))
ck('runtime defaults semantic unchanged v163',defaults==origblocks['MCE4D_RUNTIME_DEFAULTS_V1'])
def Hsource(x):return hashlib.sha256(b'MCE4D\0C14N1\0'+E('runtime-config-source-v1')+E(x)).hexdigest() if x is not None else None
minimal={'schema_version':1}
ck('minimal canonical source schema',val('RuntimeConfig',minimal))
src=Hsource(minimal)
cfgdata={'operation':'runtime_config','config':defaults,'config_digest':H,'restart_required':False,'source_kind':'canonical_home','source_digest':src,'effective_sources':['built_in','canonical_home']}
ck('RuntimeConfigData canonical positive',val('RuntimeConfigData',cfgdata))
absent={**cfgdata,'source_kind':'built_in','source_digest':None,'effective_sources':['built_in']}
ck('RuntimeConfigData absent positive',val('RuntimeConfigData',absent))
for label,patch in [('missing source',{k:v for k,v in cfgdata.items() if k!='source_digest'}),('home null',{**cfgdata,'source_digest':None}),('built-in hash',{**absent,'source_digest':src}),('unknown provenance',{**cfgdata,'effective_sources':['local']}),('duplicate sources',{**cfgdata,'effective_sources':['built_in','built_in']}),('unknown field',{**cfgdata,'source_path':'private'})]:
 ck('RuntimeConfigData reject '+label,not val('RuntimeConfigData',patch))
def provenance_ok(x,file_present):
 allowed=['built_in','canonical_home','approved_alternate','cli_process'];seq=x['effective_sources']
 return val('RuntimeConfigData',x) and seq[0]=='built_in' and seq==[k for k in allowed if k in seq] and ('canonical_home' in seq)==file_present and (x['source_kind']=='canonical_home')==file_present
ck('provenance semantic positive',provenance_ok(cfgdata,True) and provenance_ok(absent,False))
for seq in [['cli_process','built_in','canonical_home'],['built_in'],['canonical_home']]:
 ck('provenance wrong precedence/authority '+str(seq),not provenance_ok({**cfgdata,'effective_sources':seq},True))
ck('source absent distinct from minimal file',Hsource(None) is None and src is not None)
ck('source key order invariant',Hsource({'schema_version':1,'core':{'max_parse_workers':2}})==Hsource({'core':{'max_parse_workers':2},'schema_version':1}))
def cas(file,expected,replacement):return (True,replacement) if Hsource(file)==expected else (False,file)
one,new=cas(minimal,src,{'schema_version':1,'core':{'max_parse_workers':2}})
two,_=cas(new,src,{'schema_version':1,'core':{'max_parse_workers':3}})
ck('source CAS exactly one setter wins',one and not two)
ck('effective CPU/options do not change source CAS',cas(minimal,src,minimal)[0] and src!=hashlib.sha256(b'MCE4D\0C14N1\0'+E('runtime-config-v1')+E(defaults)).hexdigest())
ck('null CAS only absent',cas(None,None,minimal)[0] and not cas(minimal,None,minimal)[0])

# F01/F02/F06/F07 closed delivery fixtures. Synthetic SHA/IDs never actual run evidence.
P='a'*40;C='b'*40;Q='c'*40;U='11111111-1111-4111-8111-111111111111';now='2026-10-15T03:00:00Z'
repo={'host':'github.com','repository_id':123,'owner':'fixture','name':'mce4d-fixture','visibility':'private','publication_authority_ref':None,'remote_name':'origin','remote_url_sanitized':'https://github.com/fixture/mce4d-fixture.git','ref':'refs/heads/main'}
check={'id':'bootstrap-document','kind':'check_run','context':'bootstrap-document','source_app':'github-actions:15368','workflow_path':'.github/workflows/ci.yml','job_name':'bootstrap-document','matrix':{},'eligible_events':['push'],'checkout_binding':'head','reported_sha_binding':'subject','requirement_origins':['project','repository'],'command_refs':['local/bootstrap-document']}
plan={'format_version':1,'phase':'bootstrap','repository':repo,'credential_class':'local_user','required_set_status':'VERIFIED','canary_ref':'delivery:'+U+':payload','checks':[check],'local_check_refs':['local/bootstrap-document'],'closing_local_reuse_refs':[]}
ph=hashlib.sha256(canonical(plan)).hexdigest()
attempt={'format_version':1,'delivery_id':U,'task_id':'T001','assignment_ref':'fixture-assignment','priority':'P1','phase':'closing_proposed','base_sha':None,'ordered_commits':[{'sha':P,'subject':'ci(bootstrap): [P1][T001] Kiểm tra bản vẽ','scope_ref':'scope/t001'}],'verified_payload_sha':P,'check_plan_ref':'plan.json','check_plan_sha256':ph,'local_evidence_refs':['local.json'],'payload_observation_ref':'payload.json','closing_marker':'MCE4D-Delivery-ID: '+U,'closing_parent_sha':P}
observed={'check_id':check['id'],'kind':'check_run','context':check['context'],'source_app':check['source_app'],'workflow_path':check['workflow_path'],'job_name':check['job_name'],'matrix':{},'event':'push','run_id':'1001','run_created_at_utc':now,'job_id':'2001','attempt':1,'reported_head_sha':C,'tested_checkout_sha':C,'pr_head_sha':None,'pr_base_sha':None,'tested_merge_sha':None,'status':'completed','conclusion':'success','execution_verified':True,'url':'https://github.com/fixture/mce4d-fixture/actions/runs/1001','evidence_refs':['check.log']}
observation={'format_version':1,'delivery_id':U,'phase':'closing','subject_sha':C,'parent_sha':P,'check_plan_sha256':ph,'observed_remote_sha':C,'observed_at_utc':now,'binding_verified':True,'required_set_verified':True,'checks':[observed],'result':'PASS','blocker':None}
payload_obs={**observation,'phase':'payload','subject_sha':P,'parent_sha':None,'observed_remote_sha':P,'checks':[{**observed,'reported_head_sha':P,'tested_checkout_sha':P,'run_id':'1000','job_id':'2000'}]}
archive={'format_version':1,'delivery_id':U,'task_id':'T001','verified_payload_sha':P,'closing_sha':C,'check_plan_sha256':ph,'payload_observation_ref':'payload.json','closing_observation_ref':'closing.json','files':[],'retention_authority_ref':'fixture-until-acceptance','created_at_utc':now}
files={'plan.json':canonical(plan),'attempt.json':canonical(attempt),'payload.json':canonical(payload_obs),'closing.json':canonical(observation),'check.log':b'fixture command executed and success','local.json':b'{"fixture":true,"result":"PASS"}'}
def manifest_for(fs):return [{'path':k,'byte_length':len(v),'sha256':hashlib.sha256(v).hexdigest()} for k,v in fs.items()]
archive['files']=manifest_for(files)
for k,x in [('GitRepositoryIdentity',repo),('GitCheckSpec',check),('GitCheckPlan',plan),('GitDeliveryAttempt',attempt),('GitObservedCheck',observed),('GitDeliveryObservation',observation),('GitEvidenceArchive',archive)]:
 ck('governance positive '+k,gv(k,x))
 ck('governance rejects extra '+k,not gv(k,{**x,'unexpected':True}))
for field,value in [('verified_payload_sha',None),('closing_parent_sha',None),('payload_observation_ref',None),('ordered_commits',[])]:
 ck('closing proposal schema reject '+field,not gv('GitDeliveryAttempt',{**attempt,field:value}))
ck('pending payload schema admits unknown own SHA',gv('GitDeliveryAttempt',{**attempt,'phase':'payload_pending','verified_payload_sha':None,'closing_parent_sha':None,'payload_observation_ref':None,'ordered_commits':[]}))
def privacy_ok(r):return gv('GitRepositoryIdentity',r) and (r['visibility']!='public' or bool(r['publication_authority_ref']))
ck('private destination allowed',privacy_ok(repo))
ck('public destination without publication authority rejected',not privacy_ok({**repo,'visibility':'public'}))
ck('public explicit authority accepted',privacy_ok({**repo,'visibility':'public','publication_authority_ref':'user-explicit-fixture-publication'}))
ck('unknown repository visibility rejected',not gv('GitRepositoryIdentity',{**repo,'visibility':'unknown'}))
def safe_rel(x):return bool(x) and not x.startswith(('/', '\\')) and ':' not in x and '\\' not in x and all(y not in ('','.','..') for y in x.split('/'))
def archive_ok(a,fs):
 if not gv('GitEvidenceArchive',a):return False
 paths=[x['path'] for x in a['files']]
 if len(paths)!=len(set(paths)) or set(paths)!=set(fs) or 'manifest.json' in paths:return False
 if a['payload_observation_ref'] not in paths or a['closing_observation_ref'] not in paths:return False
 return all(safe_rel(x['path']) and x['byte_length']==len(fs[x['path']]) and x['sha256']==hashlib.sha256(fs[x['path']]).hexdigest() for x in a['files'])
ck('durable archive hash index valid',archive_ok(archive,files))
ck('tampered log archive rejected',not archive_ok(archive,{**files,'check.log':b'tampered'}))
ck('missing archive member rejected',not archive_ok(archive,{k:v for k,v in files.items() if k!='payload.json'}))
ck('archive cannot hash own manifest',not archive_ok({**archive,'files':archive['files']+[{'path':'manifest.json','byte_length':0,'sha256':'0'*64}]},{**files,'manifest.json':b''}))
ck('archive duplicate paths rejected',not archive_ok({**archive,'files':archive['files']+[archive['files'][0]]},files))
ck('unsafe member paths rejected',not archive_ok({**archive,'files':[{**x,'path':'../plan.json'} if i==0 else x for i,x in enumerate(archive['files'])]},files))

# Exact changed-leaf classifier, including the mixed metadata/runtime SPEC case.
allowed={'S19/T001/Status','S19/T001/Owner','S19/T001/Evidence','S19/progress','S20/G0/status','S20/G0/evidence','S21/task/T001/evidence','S21/task/T001/command','S21/task/T001/delivery','S22/derived/active','S22/derived/pending','S22/derived/progress','S22/derived/final'}
def closing_diff_ok(changes,other_bytes_equal=True):return bool(changes) and set(changes)<=allowed and other_bytes_equal
ck('closing leaf proposal positive',closing_diff_ok(['S19/T001/Status','S21/task/T001/delivery','S22/derived/pending']))
for leaf in ['S43/RuntimeConfig','S44/DDL','S21/ADR/A045','S21/schema','S21/task/T001/check-plan','S19/T002/Status','S22/authority','frontmatter/spec_version','S17/C189','source/main.go']:
 ck('closing classifier rejects '+leaf,not closing_diff_ok(['S19/T001/Status',leaf]))
ck('closing other tracked bytes delta rejected',not closing_diff_ok(['S19/T001/Status'],False))
candidate={'sha':C,'parents':[P],'marker':attempt['closing_marker'],'phase_trailer':'closing','approved_ancestry':True}
def resolve(at,candidates):
 if not gv('GitDeliveryAttempt',at) or at['phase']!='closing_proposed' or at['closing_parent_sha']!=at['verified_payload_sha'] or at['closing_marker']!='MCE4D-Delivery-ID: '+at['delivery_id']:return None
 matches=[x for x in candidates if x['parents']==[at['verified_payload_sha']] and x['marker']==at['closing_marker'] and x['phase_trailer']=='closing' and x['approved_ancestry']]
 return matches[0]['sha'] if len(matches)==1 else None
ck('unique closing marker-parent resolver',resolve(attempt,[candidate])==C)
ck('moving ref not historical identity',resolve(attempt,[candidate])==C and C!=Q)
ck('ambiguous duplicate closing rejected',resolve(attempt,[candidate,{**candidate,'sha':Q}]) is None)
for patch in [{'parents':[Q]},{'parents':[P,Q]},{'approved_ancestry':False},{'marker':'other'},{'phase_trailer':'payload'}]:
 ck('closing resolve negative '+str(patch),resolve(attempt,[{**candidate,**patch}]) is None)
def checks_ok(pl,obs,sha):
 if not gv('GitCheckPlan',pl) or pl['required_set_status']!='VERIFIED' or not pl['canary_ref'] or not privacy_ok(pl['repository']):return False
 if len({x['id'] for x in pl['checks']})!=len(pl['checks']):return False
 for req in pl['checks']:
  # Real observer additionally orders API observations/run generations; this fixture tests one run + latest rerun.
  relevant=[x for x in obs if x['check_id']==req['id']]
  if not relevant:return False
  latest=max(relevant,key=lambda x:(x['run_created_at_utc'],int(x['run_id']),x['attempt']))
  if not gv('GitObservedCheck',latest):return False
  if any(latest[k]!=req[k] for k in ['kind','context','source_app','workflow_path','job_name','matrix']):return False
  if latest['event'] not in req['eligible_events'] or latest['status']!='completed' or latest['conclusion']!='success' or not latest['execution_verified']:return False
  if latest['reported_head_sha']!=(sha if req['reported_sha_binding']=='subject' else latest['tested_checkout_sha']):return False
  if req['checkout_binding']=='head':
   if latest['tested_checkout_sha']!=sha:return False
  elif req['checkout_binding']=='pr_merge':
   if latest['pr_head_sha']!=sha or not latest['pr_base_sha'] or latest['tested_merge_sha']!=latest['tested_checkout_sha']:return False
  else:
   if latest['tested_checkout_sha']!=sha:return False
 return True
def effective_done(at,pl,ob,ar,fs,candidates,changes,live_remote,offline=False):
 resolved=resolve(at,candidates)
 if not resolved or not closing_diff_ok(changes) or not gv('GitDeliveryObservation',ob) or not archive_ok(ar,fs):return False
 if at['check_plan_sha256']!=hashlib.sha256(canonical(pl)).hexdigest() or ob['check_plan_sha256']!=at['check_plan_sha256'] or ar['check_plan_sha256']!=at['check_plan_sha256']:return False
 if not (ob['delivery_id']==ar['delivery_id']==at['delivery_id']):return False
 if ob['subject_sha']!=resolved or ob['parent_sha']!=at['verified_payload_sha'] or ob['observed_remote_sha']!=resolved or ob['result']!='PASS' or not ob['binding_verified'] or not ob['required_set_verified']:return False
 if ar['closing_sha']!=resolved or ar['verified_payload_sha']!=at['verified_payload_sha']:return False
 if fs.get('closing.json')!=canonical(ob) or fs.get('plan.json')!=canonical(pl) or fs.get('attempt.json')!=canonical(at):return False
 try:po=json.loads(fs[ar['payload_observation_ref']],object_pairs_hook=dup)
 except (ValueError,KeyError):return False
 if not gv('GitDeliveryObservation',po) or po['phase']!='payload' or po['result']!='PASS' or po['subject_sha']!=at['verified_payload_sha'] or po['observed_remote_sha']!=at['verified_payload_sha'] or po['delivery_id']!=at['delivery_id'] or po['check_plan_sha256']!=at['check_plan_sha256'] or not po['binding_verified'] or not po['required_set_verified'] or not checks_ok(pl,po['checks'],at['verified_payload_sha']):return False
 if not offline and live_remote!=resolved:return False
 return checks_ok(pl,ob['checks'],resolved)
args=(attempt,plan,observation,archive,files,[candidate],['S19/T001/Status'],C)
ck('closing proposal effective DONE after observer and archive',effective_done(*args))
ck('payload alone candidate remains VERIFY',not effective_done(attempt,plan,payload_obs,archive,files,[candidate],['S19/T001/Status'],P))
ck('offline sealed historical delivery retained after branch moves',effective_done(attempt,plan,observation,archive,files,[candidate],['S19/T001/Status'],Q,True))
ck('current final live remote mismatch rejected',not effective_done(attempt,plan,observation,archive,files,[candidate],['S19/T001/Status'],Q))
ck('missing durable archive keeps VERIFY',not effective_done(attempt,plan,observation,{**archive,'files':[]},files,[candidate],['S19/T001/Status'],C))
for label,patch in [('dispatch',{'event':'workflow_dispatch'}),('repository-dispatch',{'event':'repository_dispatch'}),('wrong-checkout',{'tested_checkout_sha':Q}),('wrong-app',{'source_app':'other'}),('wrong-context',{'context':'other'}),('not-executed',{'execution_verified':False}),('stale',{'reported_head_sha':Q}),('neutral',{'conclusion':'neutral'}),('skipped',{'conclusion':'skipped'}),('approval',{'status':'waiting','conclusion':'action_required'}),('failed',{'conclusion':'failure'})]:
 ck('eligible actual CI reject '+label,not checks_ok(plan,[{**observed,**patch}],C))
ck('new queued rerun invalidates old green',not checks_ok(plan,[observed,{**observed,'attempt':2,'status':'queued','conclusion':'unknown'}],C))
ck('new failed run invalidates old green',not checks_ok(plan,[observed,{**observed,'run_id':'1002','conclusion':'failure'}],C))
ck('no-check plan rejected',not checks_ok({**plan,'checks':[]},[observed],C))
ck('unknown required set rejected',not checks_ok({**plan,'required_set_status':'NOT_VERIFIED'},[observed],C))
ck('missing canary rejected',not checks_ok({**plan,'canary_ref':None},[observed],C))
ck('duplicate expected identity rejected',not checks_ok({**plan,'checks':[check,check]},[observed],C))
prcheck={**check,'eligible_events':['pull_request'],'checkout_binding':'pr_merge'}
prplan={**plan,'checks':[prcheck]}
prgood={**observed,'event':'pull_request','reported_head_sha':P,'pr_head_sha':P,'pr_base_sha':Q,'tested_merge_sha':C,'tested_checkout_sha':C}
ck('PR head-base-merge binding positive',checks_ok(prplan,[prgood],P))
ck('PR wrong head rejected',not checks_ok(prplan,[{**prgood,'pr_head_sha':Q}],P))
ck('PR wrong merge checkout rejected',not checks_ok(prplan,[{**prgood,'tested_checkout_sha':P}],P))
ck('actual bootstrap plan cannot be own-result prerequisite','delivery:<delivery_id>:payload' in s)
ck('all8 closures D021-D028',all('| D'+str(i).zfill(3)+' |' in s for i in range(21,29)) and len(re.findall(r'^\| F0[1-8] P[12] ',s,re.M))==8)
ck('version164 source memory snapshot',fm['latest_review_findings']==fm['latest_review_findings_integrated']==8 and resume['latest_review_baseline']=='1.6.3' and resume['latest_review_closure']=='S52_CLOSE_04')
ck('108 task IDs and dependencies byte-equivalent',all((rows('S19','S20',r'T\d{3}')[i][0:3])==re.split(r'(?<!\\)\|',l)[1:4] for i,l in enumerate([x for x in orig.split('## S19 —',1)[1].split('## S20 —',1)[0].splitlines() if re.match(r'^\| T\d{3} \|',x)])))

# F08 pure authority class; no actual deletion invoked.
cleanup={'new_in_current_run':True,'reconstructible':True,'contract_exact':True,'baseline_verified':True,'same_owner':True,'contained_no_links':True,'identity_verified':True,'writers_stopped':True,'evidence_retained':True,'authority_A045':True,'protected':False,'deliverable':False,'accumulated':False,'crash_leftover':False}
def teardown_ok(x):return all(x[k] for k in ['new_in_current_run','reconstructible','contract_exact','baseline_verified','same_owner','contained_no_links','identity_verified','writers_stopped','evidence_retained','authority_A045']) and not any(x[k] for k in ['protected','deliverable','accumulated','crash_leftover'])
ck('fresh reconstructible scratch teardown authorized',teardown_ok(cleanup))
for key in cleanup:
 ck('teardown rejects missing/unsafe '+key,not teardown_ok({**cleanup,key:not cleanup[key]}))
ck('cleanup scoped user exception sources unchanged','A045' in s and 'explicit user exception' in s and 'old/protected' in s and 'action-time approval POL-SRC-02' in s)

ck('PR reported tested SHA can be explicitly bound',checks_ok({**prplan,'checks':[{**prcheck,'reported_sha_binding':'tested'}]},[{**prgood,'reported_head_sha':C}],P))
ck('PR unplanned reported merge SHA rejected',not checks_ok(prplan,[{**prgood,'reported_head_sha':C}],P))
ck('PR actual tested binding cannot accept subject substitution',not checks_ok({**prplan,'checks':[{**prcheck,'reported_sha_binding':'tested'}]},[prgood],P))
ck('changed observation must match durable member bytes',not effective_done(attempt,plan,{**observation,'observed_at_utc':'2026-10-15T04:00:00Z'},archive,files,[candidate],['S19/T001/Status'],C))
ck('no inserted blank lines splitting updated tables',not re.search(r'^\|[^\n]*\|\n\n(?=\| (?:A045|D02[1-8]|1\.6\.4|REF6[45]) \|)',s,re.M))

badfs={**files,'payload.json':canonical({**payload_obs,'result':'FAIL'})}
ck('rehashed archive cannot bless failed payload',not effective_done(attempt,plan,observation,{**archive,'files':manifest_for(badfs)},badfs,[candidate],['S19/T001/Status'],C))
badfs={**files,'payload.json':canonical({**payload_obs,'checks':[]})}
ck('rehashed archive cannot bless empty payload checks',not effective_done(attempt,plan,observation,{**archive,'files':manifest_for(badfs)},badfs,[candidate],['S19/T001/Status'],C))
badfs={**files,'payload.json':canonical({**payload_obs,'delivery_id':'22222222-2222-4222-8222-222222222222'})}
ck('archive rejects payload from another delivery',not effective_done(attempt,plan,observation,{**archive,'files':manifest_for(badfs)},badfs,[candidate],['S19/T001/Status'],C))
