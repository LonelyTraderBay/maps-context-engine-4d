const fs = require('fs');
const crypto = require('crypto');
const specPath = process.argv[2];
const text = fs.readFileSync(specPath,'utf8').replace(/\r\n/g,'\n');
const fence = String.fromCharCode(96).repeat(3);
const marker='MCE4D_HASH_VECTORS_V1';
const start=text.indexOf('<!-- BEGIN '+marker+' -->');
const end=text.indexOf('<!-- END '+marker+' -->',start);
const part=text.slice(start,end);
const jStart=part.indexOf(fence+'json\n')+fence.length+5;
const jEnd=part.lastIndexOf('\n'+fence);
const vectors=JSON.parse(part.slice(jStart,jEnd)).valid;
const ascii = x=>Buffer.from(x,'ascii');
function E(v) {
 if(v===null)return ascii('n');
 if(v===false)return ascii('f');
 if(v===true)return ascii('t');
 if(typeof v==='number'){
  if(!Number.isSafeInteger(v))throw Error('unsafe/noninteger');
  return ascii('i'+String(Object.is(v,-0)?0:v)+';');
 }
 if(typeof v==='string'){
  for(let i=0;i<v.length;i++){
   const c=v.charCodeAt(i);
   if(c>=0xd800&&c<=0xdbff){
    if(i+1>=v.length||v.charCodeAt(++i)<0xdc00||v.charCodeAt(i)>0xdfff)throw Error('lone surrogate');
   }else if(c>=0xdc00&&c<=0xdfff)throw Error('lone surrogate');
  }
  const b=Buffer.from(v,'utf8');return Buffer.concat([ascii('s'+b.length+':'),b]);
 }
 if(Array.isArray(v))return Buffer.concat([ascii('a'+v.length+':'),...v.map(E)]);
 if(typeof v==='object'){
  const keys=Object.keys(v).sort((a,b)=>Buffer.compare(Buffer.from(a,'utf8'),Buffer.from(b,'utf8')));
  return Buffer.concat([ascii('o'+keys.length+':'),...keys.flatMap(k=>[E(k),E(v[k])])]);
 }
 throw Error('unknown');
}
const results=[];
for(const v of vectors){
 const b=Buffer.concat([Buffer.from('MCE4D\0C14N1\0','ascii'),E(v.domain),E(v.value)]);
 const ok=b.toString('hex')===v.encoding_hex&&crypto.createHash('sha256').update(b).digest('hex')===v.digest;
 if(!ok)throw Error('vector failed '+v.case);
 results.push(v.case);
}
for(const v of [1.5,Number.MAX_SAFE_INTEGER+1,'\ud800']){
 let rejected=false;try{E(v)}catch{rejected=true}
 if(!rejected)throw Error('bad primitive accepted');
}
console.log(JSON.stringify({node:process.version,vectors_passed:results.length,vectors_failed:0,primitive_rejections:3,spec_sha256:crypto.createHash('sha256').update(fs.readFileSync(specPath)).digest('hex'),scope:'positive codec/primitive reference; no product/transport/OS'},null,2));
