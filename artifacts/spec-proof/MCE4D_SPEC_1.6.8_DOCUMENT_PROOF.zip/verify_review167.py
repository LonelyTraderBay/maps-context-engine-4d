def verify_review167():
    """Independent L01-L06 regression inputs; calls normative evaluator with frozen evidence.
    No product, Git, network or background worker implementation.
    """
    
    def prepare167(change=None,pr=False):
        d=fixture166()
        if pr:pr166(d)
        if change:change(d)
        rebind166(d)
        current_pr=d['current_pr']['closing'] if d['current_pr'] else None
        d['live'],d['lf'],d['ctx']=make_live_fixture(d['at'],d['pl'],d['ob'],d['ar'],d['fs'],current_pr)
        return d
    
    
    def eval167(d,offline=False,live=True):
        kwargs=dict(sel=d['sel'],seal_record=seal_for(d['ar']),published=True)
        if live:kwargs.update(live_verification=d['live'],live_files=d['lf'],live_context=d['ctx'])
        return effective_done(d['at'],d['pl'],d['ob'],d['ar'],d['fs'],[d['ca']],['S19/T001/Status'],C,offline=offline,**kwargs)
    
    
    def live_ob167(d):return typed(d['lf'],d['live']['closing_observation_ref'],'GitDeliveryObservation')
    
    def save_live167(d,o,regenerate_collection=False):
        if regenerate_collection:make_collection_fixture(d['pl'],o,d['lf'],d['live']['started_at_utc'],d['live']['completed_at_utc'])
        d['lf'][d['live']['closing_observation_ref']]=C14(o)
        d['live']['collection_evidence_ref']=o['collection_evidence_ref']
        d['live']['files']=manifest_for(d['lf'])
    
    
    lreg=[]
    def regression167(id,label,value,expected):
        ck(id+' '+label,value==expected)
        lreg.append({'finding':id,'probe':label,'expected':expected,'actual':value,'result':'PASS' if value==expected else 'FAIL'})
    
    # P1 L01: one current PR is C after push; P is a retained historical observation.
    d=prepare167(pr=True)
    d['current_pr']={'closing':d['current_pr']['closing']} # No current payload query exists.
    regression167('L01','legitimate PR current C with retained P',eval167(d),True)
    ck('L01 offline archive keeps historical P C proof',eval167(d,offline=True,live=False))
    for key,value in [('head_sha',P),('base_sha','f'*40),('head_ref','refs/heads/other'),('base_ref','refs/heads/other'),('tested_merge_sha',P),('repository_id',987)]:
        x=copy.deepcopy(d);v=typed(x['lf'],x['live']['current_pr_ref'],'GitPullRequestBinding');v[key]=value;x['lf'][x['live']['current_pr_ref']]=C14(v);x['live']['files']=manifest_for(x['lf'])
        ck('L01 actual current closing mismatch '+key,not eval167(x))
    x=copy.deepcopy(d);prref=x['po']['pull_request_binding_ref'];binding=load_member(x['fs'],prref);binding['head_sha']=C;x['fs'][prref]=C14(binding);x['ar']['files']=manifest_for(x['fs'])
    ck('L01 malformed retained P still rejected',not eval167(x,offline=True,live=False))
    
    # P1 L02: all hashes/typed projections valid, but same native IDs cannot bind P and C.
    def duplicate_source167(d):
        v=d['po']['checks'][0];v.update(run_id=d['ob']['checks'][0]['run_id'],job_id=d['ob']['checks'][0]['job_id']);put_check_evidence(d['fs'],v,P,'payload',req=d['pl']['checks'][0])
    d=prepare167(duplicate_source167)
    ck('L02 counterexample source shapes remain valid',all(gv('GitCheckSourceEvidence',load_member(d['fs'],v['source_evidence_ref'])) for o in [d['po'],d['ob']] for v in o['checks']))
    ck('L02 immutable native ledger independently rejects',not native_ledger_ok([(d['po'],d['fs']),(d['ob'],d['fs'])]))
    regression167('L02','same native run job check IDs P and C',eval167(d),False)
    ck('L02 distinct actual source identities valid',eval167(prepare167()))
    for side,key,value in [('job','run_id','9999'),('job_query_scope','run_attempt',2),('job','head_sha',Q),('job','check_run_url','https://api.github.com/repos/other/repo/check-runs/1'),('workflow_run','check_suite_id','999'),('workflow_run','head_sha',Q),('record','check_suite',{'id':'999'})]:
        x=prepare167();v=x['ob']['checks'][0];sr=typed(x['fs'],v['source_evidence_ref'],'GitCheckSourceEvidence');raw=load_member(x['fs'],sr['raw_api_ref']);raw[side][key]=value;x['fs'][sr['raw_api_ref']]=C14(raw);x['ar']['files']=manifest_for(x['fs'])
        ck('L02 retained native edge tamper '+side+key,not eval167(x,offline=True,live=False))
    for field in ['run_id','job_id']:
        x=prepare167();a=copy.deepcopy(x['po']);b=copy.deepcopy(x['ob']);v=a['checks'][0]
        v[field]=b['checks'][0][field];put_check_evidence(x['fs'],v,P,'ledger-single-'+field)
        ck('L02 one reused native ID rejected '+field,not native_ledger_ok([(a,x['fs']),(b,x['fs'])]))
    
    # P1 L03: well-formed newest queued/failed native candidate cannot hide behind a logical ID.
    def extra_candidate167(d,status='queued',wrong_id=True):
        o=d['ob'];v={**copy.deepcopy(o['checks'][0]),'check_id':'unmapped-latest' if wrong_id else d['pl']['checks'][0]['id'],'run_id':'1002','job_id':'2002','run_created_at_utc':now,'status':status,'conclusion':'unknown' if status=='queued' else 'failure','execution_verified':False}
        put_check_evidence(d['fs'],v,C,'new-candidate',req=d['pl']['checks'][0]);o['checks'].append(v)
    d=prepare167(extra_candidate167)
    v=d['ob']['checks'][-1]
    ck('L03 queued source proof independently valid',check_evidence_ok(d['pl'],d['pl']['checks'][0],v,C,d['fs'],False))
    ck('L03 native mapping isolated before latest',not candidate_mapping_ok(d['pl']['checks'],d['ob']['checks']))
    regression167('L03','newer same native identity hidden by logical ID',eval167(d),False)
    for status in ['queued','completed']:
        for wrong in [False,True]:
            x=prepare167(lambda d:extra_candidate167(d,status,wrong))
            ck('L03 latest nonpass blocks '+status+str(wrong),not eval167(x))
    
    # P1 L04: no implicit live context/evidence from archived green, remote equality alone fails.
    d=prepare167()
    regression167('L04','old archive and remote C without live verification',eval167(d,live=False),False)
    ck('L04 historical offline remains valid without live',eval167(d,offline=True,live=False))
    ck('L04 explicit fresh invocation positive',eval167(d))
    archive_before167=(copy.deepcopy(d['ar']),copy.deepcopy(d['fs']),seal_for(d['ar']))
    for key,value in [('verification_id',U2),('started_at_utc','2026-10-15T03:00:01Z')]:
        x=copy.deepcopy(d);x['ctx'][key]=value;ck('L04 replay different invocation '+key,not eval167(x))
    for field,value in [('delivery_id',U2),('task_revision',2),('check_plan_sha256','0'*64),('observed_remote_sha',P),('subject_sha',P),('started_at_utc',before)]:
        x=copy.deepcopy(d);x['live'][field]=value;ck('L04 live binding mismatch '+field,not eval167(x))
    x=copy.deepcopy(d);x['ctx']=None;ck('L04 missing secured invocation rejected',not eval167(x))
    for state in ['queued','failure','success']:
        x=copy.deepcopy(d);x['live']['completed_at_utc']='2026-10-15T03:00:02Z';o=live_ob167(x);o['observed_at_utc']=x['live']['completed_at_utc'];v={**copy.deepcopy(o['checks'][0]),'run_id':'1002','job_id':'2002','run_created_at_utc':'2026-10-15T03:00:00.1Z','status':'queued' if state=='queued' else 'completed','conclusion':'unknown' if state=='queued' else state,'execution_verified':state=='success'}
        put_check_evidence(x['lf'],v,C,'fresh-'+state,req=x['pl']['checks'][0]);o['checks'].append(v);save_live167(x,o,True)
        ck('L04 current rerun '+state,eval167(x)==(state=='success'))
        ck('L04 refresh never changes sealed archive '+state,(x['ar'],x['fs'],seal_for(x['ar']))==archive_before167)
    # A real query page with a newer pending candidate, omitted by the normalizer, must reject.
    x=copy.deepcopy(d);o=live_ob167(x);v={**copy.deepcopy(o['checks'][0]),'run_id':'1002','job_id':'2002','run_created_at_utc':now,'status':'queued','conclusion':'unknown','execution_verified':False}
    put_check_evidence(x['lf'],v,C,'unmapped-page',req=x['pl']['checks'][0]);coll=typed(x['lf'],x['live']['collection_evidence_ref'],'GitCICollectionEvidence');page=next(p for p in coll['pages'] if p['endpoint']=='check_runs');raw=load_member(x['lf'],page['raw_page_ref']);raw['items'].append(source_snapshot(typed(x['lf'],v['source_evidence_ref'],'GitCheckSourceEvidence')));x['lf'][page['raw_page_ref']]=C14(raw);x['live']['files']=manifest_for(x['lf'])
    ck('L04 raw page newer source cannot be omitted from normalized list',not eval167(x))
    # New workflow run can exist before any job/check record.
    x=copy.deepcopy(d);x['live']['completed_at_utc']='2026-10-15T03:00:02Z';fresh=live_ob167(x);fresh['observed_at_utc']=x['live']['completed_at_utc'];save_live167(x,fresh,True);coll=typed(x['lf'],x['live']['collection_evidence_ref'],'GitCICollectionEvidence');page=next(p for p in coll['pages'] if p['endpoint']=='workflow_runs');raw=load_member(x['lf'],page['raw_page_ref']);raw['items'].append({**raw['items'][0],'run_id':'1002','created_at':'2026-10-15T03:00:00.1Z','job_source_refs':[]});x['lf'][page['raw_page_ref']]=C14(raw);x['live']['files']=manifest_for(x['lf'])
    ck('L04 newest workflow with no job blocks old green',not eval167(x))
    for mode in ['missing_next','wrong_number','wrong_query','filter_success','outside_interval','wrong_sha','missing_status_endpoint']:
        x=copy.deepcopy(d);ref=x['live']['collection_evidence_ref'];coll=typed(x['lf'],ref,'GitCICollectionEvidence');page=coll['pages'][0];raw=load_member(x['lf'],page['raw_page_ref'])
        if mode=='missing_next':page['next_page_number']=2;raw['next_page_number']=2
        elif mode=='wrong_number':page['page_number']=2;raw['page_number']=2
        elif mode=='wrong_query':raw['query_id']=U2
        elif mode=='filter_success':raw['state_filter']='success'
        elif mode=='outside_interval':raw['observed_at_utc']=before
        elif mode=='wrong_sha':page['requested_sha']=P;raw['requested_sha']=P
        else:coll['pages']=[p for p in coll['pages'] if p['endpoint']!='commit_statuses']
        x['lf'][page['raw_page_ref']]=C14(raw);x['lf'][ref]=C14(coll);x['live']['files']=manifest_for(x['lf'])
        ck('L04 query completeness rejects '+mode,not eval167(x))
    # Valid two-page response, terminal link, full candidates; collector does not need a fake one-page limit.
    x=copy.deepcopy(d);o=live_ob167(x);v={**copy.deepcopy(o['checks'][0]),'run_id':'990','job_id':'1990','run_created_at_utc':before,'execution_verified':False,'conclusion':'failure'};put_check_evidence(x['lf'],v,C,'older-page',req=x['pl']['checks'][0]);o['checks'].append(v);save_live167(x,o,True)
    ref=x['live']['collection_evidence_ref'];coll=typed(x['lf'],ref,'GitCICollectionEvidence');page=next(p for p in coll['pages'] if p['endpoint']=='check_runs');raw=load_member(x['lf'],page['raw_page_ref']);second={**copy.deepcopy(page),'page_number':2,'next_page_number':None,'raw_page_ref':page['raw_page_ref']+'.2'};page['next_page_number']=2;raw2={**raw,'page_number':2,'items':raw['items'][1:]};raw['items']=raw['items'][:1];raw['next_page_number']=2;x['lf'][page['raw_page_ref']]=C14(raw);x['lf'][second['raw_page_ref']]=C14(raw2);coll['pages'].append(second);x['lf'][ref]=C14(coll);x['live']['files']=manifest_for(x['lf'])
    ck('L04 complete two-page query positive',eval167(x))
    
    # Current C can have a repaired PR base/merge while archived P/C remain unchanged.
    x=prepare167(pr=True);original_archive=(copy.deepcopy(x['ar']),copy.deepcopy(x['fs']))
    x['live']['completed_at_utc']='2026-10-15T03:00:02Z';o=live_ob167(x);o['observed_at_utc']=x['live']['completed_at_utc']
    old=copy.deepcopy(o['checks'][0]);v=copy.deepcopy(old);v.update(run_id='1101',job_id='2101',run_created_at_utc='2026-10-15T03:00:00.1Z',pr_base_sha='f'*40,tested_merge_sha='9'*40,tested_checkout_sha='9'*40)
    put_check_evidence(x['lf'],v,C,'new-pr-base',req=x['pl']['checks'][0]);o['checks'].append(v)
    bnd=typed(x['lf'],x['live']['current_pr_ref'],'GitPullRequestBinding');bnd.update(base_sha='f'*40,tested_merge_sha='9'*40,observed_at_utc=x['live']['completed_at_utc'],api_evidence_ref='new-pr-base-api.json')
    o['pull_request_binding_ref']='new-pr-base.json';x['lf'][o['pull_request_binding_ref']]=C14(bnd);x['lf'][x['live']['current_pr_ref']]=C14(bnd)
    x['lf'][bnd['api_evidence_ref']]=C14({'kind':'pull_request_api_snapshot',**{k:v for k,v in bnd.items() if k not in ['format_version','kind','api_evidence_ref']}})
    parents=load_member(x['lf'],x['live']['git_evidence_ref']);parents['9'*40]=['f'*40,C];parents['f'*40]=[];x['lf'][x['live']['git_evidence_ref']]=C14(parents);save_live167(x,o,True)
    ck('L01 L04 fresh C merge after base repair positive',eval167(x))
    ck('L01 L04 repaired C does not rewrite historical P C',original_archive==(x['ar'],x['fs']))
    current_collection=typed(x['lf'],x['live']['collection_evidence_ref'],'GitCICollectionEvidence')
    ck('L04 refreshed query targets current C merge only',set(p['requested_sha'] for p in current_collection['pages'])=={C,'9'*40})

    # Every native source is decoded even if its logical ID claims to be unrelated.
    x=prepare167();o=live_ob167(x);v={**copy.deepcopy(o['checks'][0]),'check_id':'unrelated','run_id':'1002','job_id':'2002','run_created_at_utc':before,'execution_verified':False,'status':'completed','conclusion':'failure'}
    put_check_evidence(x['lf'],v,C,'native-alias',req=x['pl']['checks'][0]);v['context']='pretend-unrelated';o['checks'].append(v);save_live167(x,o,True)
    ck('L03 native observed mismatch cannot hide required failure',not eval167(x))
    x=prepare167();o=live_ob167(x);v={**copy.deepcopy(o['checks'][0]),'check_id':'unrelated','context':'other-context','workflow_path':'.github/workflows/other.yml','job_name':'other-job','run_id':'1002','job_id':'2002','run_created_at_utc':before,'execution_verified':False,'status':'completed','conclusion':'failure'}
    put_check_evidence(x['lf'],v,C,'native-unrelated',req=x['pl']['checks'][0]);o['checks'].append(v);save_live167(x,o,True)
    ck('L03 truly unrelated retained failure does not block required success',eval167(x))
    # Cross-query source creation cannot be in the future, and raw run generations agree.
    x=prepare167();o=live_ob167(x);v=copy.deepcopy(o['checks'][0]);v.update(run_id='1002',job_id='2002',run_created_at_utc='2026-10-15T03:00:01Z');put_check_evidence(x['lf'],v,C,'future-source',req=x['pl']['checks'][0]);o['checks'].append(v);save_live167(x,o,True)
    ck('L04 future-created source rejected before observed query',not eval167(x))
    for kind in ['boolean_attempt','conflicting_created']:
        x=prepare167();coll=typed(x['lf'],x['live']['collection_evidence_ref'],'GitCICollectionEvidence');page=next(p for p in coll['pages'] if p['endpoint']=='workflow_runs');raw=load_member(x['lf'],page['raw_page_ref'])
        if kind=='boolean_attempt':raw['items'][0]['run_attempt']=True
        else:raw['items'].append({**copy.deepcopy(raw['items'][0]),'run_attempt':2,'created_at':before,'job_source_refs':[]})
        x['lf'][page['raw_page_ref']]=C14(raw);x['live']['files']=manifest_for(x['lf']);ck('L04 malformed raw run generation '+kind,not eval167(x))

    # Reported-SHA=tested is a real supported PR mapping, independent of head checkout.
    def reported_tested167(d):
        d['pl']['checks'][0]['reported_sha_binding']='tested'
        for phase in [d['po'],d['ob']]:
            for value in phase['checks']:
                value['reported_head_sha']=value['tested_merge_sha'];put_check_evidence(d['fs'],value,phase['subject_sha'],'reported-tested-'+phase['phase'],req=d['pl']['checks'][0])
    ck('L01 L04 full PR reported tested SHA positive',eval167(prepare167(reported_tested167,pr=True)))
    x=prepare167();x['live']['completed_at_utc']='2026-10-15T03:00:02Z';o=live_ob167(x);o['observed_at_utc']=x['live']['completed_at_utc'];v=copy.deepcopy(o['checks'][0]);v.update(run_id='1002',job_id='2002',run_created_at_utc='2026-10-15T03:00:01Z');put_check_evidence(x['lf'],v,C,'page-in-future',req=x['pl']['checks'][0]);o['checks'].append(v);save_live167(x,o,True)
    coll=typed(x['lf'],x['live']['collection_evidence_ref'],'GitCICollectionEvidence');page=next(p for p in coll['pages'] if p['endpoint']=='check_runs');raw=load_member(x['lf'],page['raw_page_ref']);raw['observed_at_utc']=now;x['lf'][page['raw_page_ref']]=C14(raw);x['live']['files']=manifest_for(x['lf'])
    ck('L04 creation after individual page read rejected inside wider interval',not eval167(x))

    # P2 L05: binding conditions cannot manufacture another native job.
    def alias167(d):
        req={**copy.deepcopy(d['pl']['checks'][0]),'id':'same-job-second-id','reported_sha_binding':'tested'};d['pl']['checks'].append(req)
        for o in [d['po'],d['ob']]:
            v={**copy.deepcopy(o['checks'][0]),'check_id':req['id']};put_check_evidence(d['fs'],v,o['subject_sha'],o['phase'],req=req);o['checks'].append(v)
    d=prepare167(alias167)
    regression167('L05','same execution twice via subject tested alias',eval167(d),False)
    ck('L05 plan uniqueness independently rejects aliases',not plan_ok(d['pl']))
    for binding in ['head','pr_merge']:
        p=copy.deepcopy(plan);p['checks'].append({**copy.deepcopy(check),'id':'alias','checkout_binding':binding,'reported_sha_binding':'tested'});ck('L05 equivalent condition cannot create native slot '+binding,not plan_ok(p))
    p=copy.deepcopy(plan);p['checks'][0]['requirement_origins']=['project','repository'];ck('L05 multiple origins one actual slot positive',plan_ok(p))
    
    # P2 L06: allocated-but-not-started command must retain its real operation identity.
    cp={**copy.deepcopy(valid_checkpoint),'command_state':'NOT_STARTED','operation_id':None,'command_record_ref':None}
    ctx={**copy.deepcopy(actual_checkpoint),'command_state':'NOT_STARTED','operation_id':U2}
    regression167('L06','checkpoint forgets allocated NOT_STARTED operation',checkpoint_ok(cp,selection,ctx,checkpoint_fs),False)
    ck('L06 truly no allocated operation positive',checkpoint_ok(cp,selection,{**ctx,'operation_id':None},checkpoint_fs))
    cp.update(operation_id=U2,command_record_ref='allocated-command.json');cfs={**checkpoint_fs,'allocated-command.json':C14(command_fixture(checkpoint_like=cp))}
    ck('L06 allocated NOT_STARTED exact identity positive',checkpoint_ok(cp,selection,ctx,cfs))
    for patch in [{'operation_id':U},{'command_record_ref':None},{'command_record_ref':'missing.json'},{'command_state':'RUNNING'}]:
        ck('L06 allocated mismatch '+str(patch),not checkpoint_ok({**cp,**patch},selection,ctx,cfs))
    
    # Whole-document synchronization guards and honest remaining scope.
    ck('L counts and DAG retained',len(tt)==108 and all(r[6].strip()=='TODO' for r in tasks) and edgesR==edgesT)
    ck('L runtime schema defaults registry unchanged',all(blocks[k]==origblocks[k] for k in ['MCE4D_CONTRACT_SCHEMA_V1','MCE4D_RUNTIME_DEFAULTS_V1','MCE4D_OPERATION_REGISTRY_V1'] if k in origblocks))
    ck('L current metadata168 four closed',fm['spec_version']==resume['spec_version']=='1.6.8' and fm['latest_review_findings']==fm['latest_review_findings_integrated']==4 and resume['latest_review_closure']=='S52_CLOSE_08')
    ck('L 6 closures discrepancy links complete',all('| L'+str(i).zfill(2)+' P' in s for i in range(1,7)) and all('| D'+str(i).zfill(3)+' |' in s for i in range(44,50)))
    for kind in ['GitCICollectionEvidence','GitLiveVerification']:
        sample_value=typed(d['lf'],d['live']['collection_evidence_ref'],kind) if kind=='GitCICollectionEvidence' else d['live']
        ck('L new typed '+kind,gv(kind,sample_value));ck('L reject extra '+kind,not gv(kind,{**sample_value,'extra':1}))
    ck('L canonical tracked tables have exact column counts',all(len(row)==9 for row in tasks) and all(len(row)==5 for row in reqs) and all(len(row)==4 for row in cases))
    ck('L source references and approval current',all('| REF'+str(i)+' |' in s for i in range(70,73)) and '| A048 |' in s)
    ck('L six original regressions expected now',len(lreg)==6 and all(x['actual']==x['expected'] for x in lreg))
    (run/'review-1.6.7-validation.json').write_text(json.dumps({'spec_version':'1.6.7','regressions':lreg,'scope':'document reference synthetic inputs only; no product/GitHub','prior_counterexamples':6,'current_unresolved':0},ensure_ascii=False,indent=2),encoding='utf-8')
    

verify_review167()
