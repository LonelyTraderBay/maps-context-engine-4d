MCE4D SPEC 1.6.8 DOCUMENT REFERENCE PROOF
Authority: workspace Maps-Context-Engine-4D_SPEC.md. Input snapshots are immutable before/after evidence, not alternate current specs or trackers.

Entry: verify_spec.py FINAL_SPEC_PATH WORKSPACE_ROOT_WITH_DOCS
Dependencies: pinned verification-requirements.txt. Python 3.12.10 used; Node v24.19.0 used for verify_codec.cjs.
Inspect/reproduce argv templates in manifest.json. Run verify_manifest.py before and after replay. The three preserved docs under the supplied workspace root are required.

Load order: verify_spec -> verify_findings -> verify_delivery -> delivery_core; delivery_core explicitly loads delivery167 then fixture_support167 then delivery168 then fixture_support168. Final normative effective_done is defined in delivery167, calling global guards replaced by delivery168. New M cases call this normative function with explicitly constructed, frozen synthetic evidence. fixture_support files construct TEST INPUTS only; they are never called inside the normative evaluator to invent live evidence. Legacy compatibility tests explicitly use fixture_done, not a fake network collector.

Review reports J/L/M contain current replay results. regression-1.6.5/6/7 are historical review inputs, not assertions that those old results still apply. proof-migration.json retains all 671 previous labels (with listed current-version/count renames), states fixture schema migrations and maps the 14 v167 probes to current controls/counterexamples. Old minimal command envelope and invented workflow list attempt rows are not preserved as valid formats; positive controls are migrated to complete common lifecycle/native current row + explicit attempt detail.

Synthetic Git snapshots test wrapper/source/ancestry/message linkage only. No real Git commit parser/commands, push, GitHub API collector, hosted CI, protection enforcement, product, OS secure-handle race, power-loss durability, embedded Go SQLite runtime, browser or XL acceptance was executed. Local document proof never closes an implementation task. All 108 tasks remain TODO and final user acceptance remains pending.

Archive I/O tests use small isolated files/process exits under the extracted directory. Generated replay folders and optional verification-libs are outside the immutable flat manifest set. Manifest does not hash itself; ZIP hash is external. Hash integrity is not a digital signature/authenticity proof.
