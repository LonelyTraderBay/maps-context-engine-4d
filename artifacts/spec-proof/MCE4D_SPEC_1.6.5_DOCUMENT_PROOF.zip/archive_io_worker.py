# Small reference I/O only; deliberate child exits simulate interruption boundaries.
from pathlib import Path
import sys,json,hashlib,os
def write(path,data):
 with path.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
def emit(path,payload):write(path,json.dumps(payload,sort_keys=True,separators=(',',':')).encode())
root=Path(sys.argv[1]);phase=sys.argv[2];stage=root/'.staging-fixture';final=root/'fixture'
stage.mkdir()
if phase=='empty':os._exit(73)
write(stage/'payload.bin',b'bounded reference payload')
if phase=='member':os._exit(73)
manifest={'files':{'payload.bin':hashlib.sha256((stage/'payload.bin').read_bytes()).hexdigest()}}
emit(stage/'manifest.json',manifest)
if phase=='manifest':os._exit(73)
emit(stage/'seal.json',{'manifest_sha256':hashlib.sha256((stage/'manifest.json').read_bytes()).hexdigest()})
if phase=='seal':os._exit(73)
assert not final.exists();os.rename(stage,final)
if phase=='published':os._exit(73)
raise ValueError('unknown boundary')
