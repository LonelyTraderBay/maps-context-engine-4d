# Real bounded Windows temp-file I/O + process-exit probes, not a power-loss proof.
import tempfile,subprocess,os
io_root=Path(tempfile.mkdtemp(prefix='archive-reference-',dir=run))
def sealed_directory(d):
 try:
  if not d.is_dir() or d.is_symlink():return False
  m=json.loads((d/'manifest.json').read_bytes(),object_pairs_hook=dup)
  sealx=json.loads((d/'seal.json').read_bytes(),object_pairs_hook=dup)
  if hashlib.sha256((d/'manifest.json').read_bytes()).hexdigest()!=sealx['manifest_sha256']:return False
  return bool(m['files']) and all(safe_rel(k) and (d/k).is_file() and not (d/k).is_symlink() and hashlib.sha256((d/k).read_bytes()).hexdigest()==h for k,h in m['files'].items())
 except (OSError,ValueError,KeyError):return False
summary=[]
for phase in ['empty','member','manifest','seal','published']:
 case=io_root/phase;case.mkdir()
 process=subprocess.run([sys.executable,'-B',str(run/'archive_io_worker.py'),str(case),phase],capture_output=True,timeout=10)
 ck('archive child interruption '+phase,process.returncode==73)
 stage=case/'.staging-fixture';final=case/'fixture'
 ck('archive DONE only after final publication '+phase,sealed_directory(final)==(phase=='published'))
 if phase=='seal':
  ck('staging seal valid but not published',sealed_directory(stage) and not final.exists())
  os.rename(stage,final)
  ck('resume completes exact staged publication',sealed_directory(final))
 if phase=='published':
  ck('cold discovery without next-task pointer',sealed_directory(final) and not stage.exists())
  oldhash=hashlib.sha256((final/'manifest.json').read_bytes()).hexdigest()
  # Idempotent recovery validates rather than rewrites.
  ck('published idempotent readback',sealed_directory(final) and hashlib.sha256((final/'manifest.json').read_bytes()).hexdigest()==oldhash)
  (final/'payload.bin').write_bytes(b'tampered reference payload')
  ck('published member tamper rejected',not sealed_directory(final))
 summary.append({'boundary':phase,'child_exit':process.returncode,'initial_effective_done':phase=='published'})
archive_io_summary={'boundaries':5,'scope':'Windows small owned files/fsync/rename/process-exit; no power-loss/OS secure-handle/GitHub/product proof','cases':summary}
(run/'archive-io-validation.json').write_text(json.dumps(archive_io_summary,indent=2),encoding='utf-8')
