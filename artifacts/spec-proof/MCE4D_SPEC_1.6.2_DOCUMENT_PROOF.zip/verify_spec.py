from pathlib import Path
import sys,re,json,hashlib,sqlite3,copy,platform,importlib.metadata,unicodedata
run=Path(__file__).resolve().parent
sys.path.insert(0,str(run/'verification-libs'))
from jsonschema import Draft202012Validator,FormatChecker
import yaml
p=Path(sys.argv[1]).resolve()
source_root=Path(sys.argv[2]).resolve()
b=p.read_bytes();s=b.decode('utf-8').replace('\r\n','\n');f=chr(96)*3
checks=[]
def ck(name,condition):
 if not condition:raise AssertionError(name)
 checks.append(name)
def dup(pairs):
 d={}
 for k,v in pairs:
  if k in d:raise ValueError('duplicate key '+k)
  d[k]=v
 return d
def rows(section,nextsection,tag):
 part=s.split('## '+section+' —',1)[1].split('## '+nextsection+' —',1)[0]
 return [re.split(r'(?<!\\)\|',l)[1:-1] for l in part.splitlines() if re.match(r'^\| '+tag+r' \|',l)]
sections=re.findall(r'^## (S\d{2}) —',s,re.M)
ck('54 ordered sections',sections==['S'+str(i).zfill(2) for i in range(54)])
reqs=rows('S01','S02',r'R\d{3}');tasks=rows('S19','S20',r'T\d{3}');cases=rows('S17','S18',r'C\d{3}')
ck('canonical counts 130/108/195',len(reqs)==130 and len(tasks)==108 and len(cases)==195)
rr={r[0].strip():r for r in reqs};tt={r[0].strip():r for r in tasks};cc={r[0].strip():r for r in cases}
ck('unique canonical IDs',len(rr)==130 and len(tt)==108 and len(cc)==195)
expectedT={'T'+str(i).zfill(3) for i in range(1,109)}
ck('task ID sequence',set(tt)==expectedT)
ck('108 TODO/no fake evidence',all(r[6].strip()=='TODO' and r[8].strip()=='NONE' for r in tasks))
edgesR={(id,t) for id,r in rr.items() for t in re.findall(r'T\d{3}',r[4])}
edgesT={(r,t) for t,row in tt.items() for r in re.findall(r'R\d{3}',row[4])}
ck('bidirectional requirement edges',edgesR==edgesT)
cards=[re.split(r'(?<!\\)\|',l)[1:-1] for l in s.split('## S47 —',1)[1].split('## S48 —',1)[0].splitlines() if re.match(r'^\| \d{3} \| T\d{3} \|',l)]
schedule=[r[1].strip() for r in cards];pos={t:i for i,t in enumerate(schedule)}
ck('schedule permutation',len(schedule)==108 and set(schedule)==expectedT)
ck('dependency-before-consumer',all(pos[d]<pos[t] for t,r in tt.items() for d in re.findall(r'T\d{3}',r[2])))
ck('card case parity',all(r[5].strip()==tt[r[1].strip()][5].strip() for r in cards))
ck('all task requirements/cases resolve',all(x in rr for r in tasks for x in re.findall(r'R\d{3}',r[4])) and all(x in cc for r in tasks for x in re.findall(r'C\d{3}',r[5])))
ck('T080 final after T104',pos['T104']<pos['T080'])
fm=yaml.safe_load(s.split('---',2)[1])
ys=re.findall(f+r'yaml\n(.*?)\n'+f,s,re.S)
parsed_y=[yaml.safe_load(x) for x in ys]
resume=next(v['resume'] for v in parsed_y if isinstance(v,dict) and 'resume' in v)
ck('frontmatter/resume1.6.2',fm['spec_version']==resume['spec_version']=='1.6.2')
ck('autonomy scope unchanged',fm['execution_scope']=='ALL_108_TASKS_R1_R2_R3_U0_U1_U2_U3' and resume['required_scope_tasks']==108 and resume['completed_scope_tasks']==0 and resume['intermediate_user_approval'] is False)
ck('product NOT_RUN/not-started',fm['implementation_status']=='NOT_STARTED' and all(resume[k]=='NOT_RUN' for k in ['product_build','product_tests','product_benchmark']))
ck('previous revision SHA',fm['previous_spec_sha256']==hashlib.sha256((run/'baseline.bin').read_bytes()).hexdigest())
markers=re.findall(r'<!-- BEGIN ([A-Z0-9_]+) -->',s)
ck('11 unique matching markers',len(markers)==len(set(markers))==11 and markers==re.findall(r'<!-- END ([A-Z0-9_]+) -->',s))
fences=[l for l in s.splitlines() if l.strip().startswith(f)]
ck('fences balanced',len(fences)%2==0)
blocks={}
for marker in markers:
 m=re.search(r'<!-- BEGIN '+marker+r' -->\n'+f+r'(\w+)\n(.*?)\n'+f,s,re.S)
 ck('marker block '+marker,m is not None)
 if m.group(1)=='json':blocks[marker]=json.loads(m.group(2),object_pairs_hook=dup)
ck('four JSON blocks',len(blocks)==4)
sc=blocks['MCE4D_CONTRACT_SCHEMA_V1'];D=sc['$defs']
ck('155 definitions',len(D)==155)
Draft202012Validator.check_schema(sc)
ck('full Draft2020-12 meta-schema',True)
for k,v in D.items():Draft202012Validator.check_schema(v)
ck('all 155 subschemas meta-valid',True)
refs=[]
def walk(v):
 if isinstance(v,dict):
  if '$ref' in v:refs.append(v['$ref'])
  for x in v.values():walk(x)
 elif isinstance(v,list):
  for x in v:walk(x)
walk(sc)
ck('local references resolved',all(x.startswith('#/$defs/') and x[len('#/$defs/'):] in D for x in refs))
registry=next(v for k,v in blocks.items() if 'REGISTRY' in k)
ck('31 registry mappings resolve',len(registry)==31 and all(len(v)==2 and all(k in D for k in v) for v in registry.values()))
opstr=json.dumps(registry)
ck('private models absent from operation registry',all(k not in opstr for k in ['VolumeAdmissionJournal','VolumeAdmissionEntry','AdmissionOwnedPath','StoredCaptureManifestRef']))
def val(name,x):
 v=Draft202012Validator({'$schema':sc['$schema'],'$ref':'#/$defs/'+name,'$defs':D},format_checker=FormatChecker())
 return v.is_valid(x)
defaults=blocks['MCE4D_RUNTIME_DEFAULTS_V1'];core=defaults['core']
ck('default config schema',val('RuntimeConfig',defaults))
ck('new default values',core['max_indexed_files']==1000000 and core['max_source_bytes_per_snapshot']==34359738368 and core['max_worktree_cache_bytes']==412316860416 and core['max_capture_manifest_bytes']==34359738368 and core['volume_reserve_bytes']==2147483648 and core['volume_warning_bytes']==4294967296 and core['process_tree_rss_budget_bytes']==8589934592 and core['resource_monitor_interval_ms']==250)
ck('shared/memory cross-field defaults',core['volume_warning_bytes']>=core['volume_reserve_bytes']>0 and 10<=core['resource_monitor_interval_ms']<=5000)
cfg=copy.deepcopy(defaults);cfg['core']['max_worktree_cache_bytes']=549755813888;cfg['core']['max_source_bytes_per_snapshot']=68719476736
ck('nondefault caps schema allowed',val('RuntimeConfig',cfg))
for field,value in [('max_indexed_files',1000001),('max_capture_manifest_bytes',34359738369),('volume_reserve_bytes',0),('process_tree_rss_budget_bytes',0),('resource_monitor_interval_ms',5001)]:
 bad=copy.deepcopy(defaults);bad['core'][field]=value
 ck('reject limit '+field,not val('RuntimeConfig',bad))
bad=copy.deepcopy(defaults);bad['core']['unknown_budget']=1
ck('reject unknown runtime key',not val('RuntimeConfig',bad))
UUID='11111111-1111-1111-1111-111111111111';H='1'*64
gp={'schema_version':1,'language':'go','goos':'windows','goarch':'amd64','build_tags':[],'cgo_enabled':False,'tests_enabled':True,'module_roots':['.'],'toolchain_digest':H,'provider_digest':H,'module_mode':'readonly','analysis_mode':'typed_when_available','dependency_roots':[]}
ck('Go profile positive',val('EffectiveProfile',gp))
for field in ['GOOS','GOARCH','budgets','generated_policy','dependency_allowlist','exclusions','trusted_rule_paths','worktree_id']:
 bad=copy.deepcopy(gp);bad[field]='extra'
 ck('old profile field rejected '+field,not val('EffectiveProfile',bad))
def sample(d):
 if '$ref' in d:return sample(D[d['$ref'].split('/')[-1]])
 if 'const' in d:return d['const']
 if 'enum' in d:return d['enum'][0]
 if 'oneOf' in d:return sample(d['oneOf'][0])
 if 'anyOf' in d:return sample(d['anyOf'][0])
 if d.get('type')=='object':return {k:sample(d['properties'][k]) for k in d.get('required',[])}
 if d.get('type')=='array':return [sample(d['items']) for _ in range(d.get('minItems',0))]
 if d.get('type')=='integer':return d.get('minimum',0)
 if d.get('type')=='boolean':return False
 if d.get('type')=='null':return None
 if d.get('type')=='string':
  if d.get('format')=='date-time':return '2026-10-14T00:00:00Z'
  if d.get('pattern','').startswith('^[0-9a-f]{8}'):return UUID
  if d.get('pattern')=='^[0-9a-f]{64}$':return H
  return 'x'*max(1,d.get('minLength',1))
 raise AssertionError(d)
mapping=sample(D['MappingProposeRequest']);ck('mapping positive shape',val('MappingProposeRequest',mapping))
for field in ['actor','revision','status','reason','source_refs','target_anchor_or_selector']:
 bad=copy.deepcopy(mapping);bad[field]='spoofed'
 ck('mapping extra rejected '+field,not val('MappingProposeRequest',bad))
entry={'operation_id':UUID,'scope_kind':'home','worktree_id':None,'owner_identity':'fixture-owner','ownership_ref':'operation-leases/'+UUID+'.lock','operation_kind':'catalog_write','allowed_paths':['catalog.sqlite'],'volume_reserved_remaining_bytes':1048576,'cache_reserved_remaining_bytes':0,'created_at':'2026-10-14T00:00:00Z'}
journal={'format_version':1,'volume_id':'fixture-volume','home_identity':'fixture-home','admission_config_digest':H,'entries':[entry]}
ck('home journal positive',val('VolumeAdmissionJournal',journal))
for label,field,value in [('home-cache','cache_reserved_remaining_bytes',1),('home-UUID','worktree_id',UUID),('home-index','operation_kind','index'),('negative-reserve','volume_reserved_remaining_bytes',-1)]:
 bad=copy.deepcopy(journal);bad['entries'][0][field]=value
 ck('journal rejected '+label,not val('VolumeAdmissionJournal',bad))
bad=copy.deepcopy(journal);bad['entries'][0]['unused']='x';ck('journal unknown reject',not val('VolumeAdmissionJournal',bad))
wt=copy.deepcopy(entry);wt.update(scope_kind='worktree',worktree_id=UUID,operation_kind='record_write',allowed_paths=['worktrees/'+UUID+'/records.sqlite'])
ck('durable worktree positive',val('VolumeAdmissionEntry',wt))
bad=copy.deepcopy(wt);bad['operation_kind']='config_write';ck('worktree-config kind rejected',not val('VolumeAdmissionEntry',bad))
bad=copy.deepcopy(wt);bad['worktree_id']=None;ck('worktree null reject',not val('VolumeAdmissionEntry',bad))
def E(v):
 if v is None:return b'n'
 if v is False:return b'f'
 if v is True:return b't'
 if isinstance(v,int):
  if abs(v)>9007199254740991:raise ValueError('unsafe int')
  return b'i'+str(v).encode()+b';'
 if isinstance(v,str):
  b=v.encode('utf-8');return b's'+str(len(b)).encode()+b':'+b
 if isinstance(v,list):return b'a'+str(len(v)).encode()+b':'+b''.join(E(x) for x in v)
 if isinstance(v,dict):return b'o'+str(len(v)).encode()+b':'+b''.join(E(k)+E(v[k]) for k in sorted(v,key=lambda k:k.encode('utf-8')))
 raise ValueError('unknown/fraction')
vectors=blocks['MCE4D_HASH_VECTORS_V1']['valid']
ck('18 distinct codec vectors',len(vectors)==len({v['case'] for v in vectors})==18)
for v in vectors:
 raw=b'MCE4D\x00C14N1\x00'+E(v['domain'])+E(v['value'])
 ck('codec '+v['case'],raw.hex()==v['encoding_hex'] and hashlib.sha256(raw).hexdigest()==v['digest'])
full=next(v for v in vectors if v['case']=='capture_manifest_full')
ck('full capture schema',val('CaptureManifest',{**full['value'],'snapshot_digest':full['digest']}))
ck('capture raw fixture hash',full['value']['files'][0]['content_hash']==hashlib.sha256(bytes.fromhex('7061636b61676520700d0a')).hexdigest())
for field in ['worktree_id','profile_id','policy_digest','provider_digest']:
 changed=next(v for v in vectors if v['case']=='capture_changed_'+field)
 ck('capture identity changes '+field,changed['digest']!=full['digest'] and val('CaptureManifest',{**changed['value'],'snapshot_digest':changed['digest']}))
 bad={**full['value'],'snapshot_digest':full['digest']};bad.pop(field)
 ck('capture missing rejected '+field,not val('CaptureManifest',bad))
try:json.loads('{"x":1,"x":2}',object_pairs_hook=dup);duplicate_rejected=False
except ValueError:duplicate_rejected=True
ck('duplicate parser counterexample',duplicate_rejected)
for value in [1.5,9007199254740992,'\ud800']:
 try:E(value);failed=False
 except (ValueError,UnicodeError):failed=True
 ck('invalid codec primitive '+repr(value),failed)

# New private manifest physical descriptor fixtures.
ref={'format_version':1,'kind':'external_capture_manifest','path':'manifests/'+full['digest']+'.json','byte_length':len(json.dumps({**full['value'],'snapshot_digest':full['digest']},ensure_ascii=False,separators=(',',':')).encode()),'artifact_sha256':H,'snapshot_digest':full['digest']}
ck('stored capture descriptor positive',val('StoredCaptureManifestRef',ref))
ck('stored descriptor fits4096 bytes',len(json.dumps(ref,separators=(',',':')).encode())<=4096)
for field,value in [('path','../source.go'),('byte_length',34359738369),('kind','inline'),('unknown_key',0)]:
 bad=copy.deepcopy(ref);bad[field]=value
 ck('stored descriptor reject '+field,not val('StoredCaptureManifestRef',bad))
def semantic_entry(x):
 if x['volume_reserved_remaining_bytes']<x['cache_reserved_remaining_bytes']:return False
 if x['ownership_ref']!='operation-leases/'+x['operation_id']+'.lock':return False
 if x['operation_kind'] in ['record_write','evidence_import','backup','log_write','catalog_write','config_write'] and x['cache_reserved_remaining_bytes']!=0:return False
 for path in x['allowed_paths']+[x['ownership_ref']]:
  if len(path.encode('utf-8'))>256 or path.startswith('/') or any(seg in ('','..','.') for seg in path.split('/')) or chr(92) in path or ':' in path or any(ord(c)<32 for c in path):return False
 if x['scope_kind']=='worktree':
  return all(path.startswith('worktrees/'+x['worktree_id']+'/') for path in x['allowed_paths'])
 return True
ck('reference durable entry semantic',semantic_entry(wt))
for field,value in [('cache_reserved_remaining_bytes',1),('allowed_paths',['catalog.sqlite']),('allowed_paths',['worktrees/'+UUID+'/../source.go']),('ownership_ref','operation-leases/other.lock'),('volume_reserved_remaining_bytes',-1)]:
 bad=copy.deepcopy(wt);bad[field]=value
 ck('reference owner/cache reject '+field+str(value),not semantic_entry(bad))
def semantic_limits(x):
 c=x['core']
 return c['volume_warning_bytes']>=c['volume_reserve_bytes']>0 and c['max_file_bytes']<=c['max_source_bytes_per_snapshot'] and c['full_reconcile_interval_ms']>=c['watch_poll_interval_ms']>0 and c['rename_result_max_bytes']<=c['rename_results_max_bytes']<=c['max_worktree_cache_bytes']
ck('reference effective limits defaults',semantic_limits(defaults))
for field,value in [('volume_warning_bytes',1),('max_file_bytes',core['max_source_bytes_per_snapshot']+1),('full_reconcile_interval_ms',1),('rename_results_max_bytes',core['rename_result_max_bytes']-1)]:
 bad=copy.deepcopy(defaults);bad['core'][field]=value
 ck('reference cross-field reject '+field,not semantic_limits(bad))
known=set(sections)|set(rr)|set(tt)|set(cc)
ck('all global S/R/T/C refs resolve',set(re.findall(r'\b(?:S\d{2}|[RTC]\d{3})\b',s))<=known)
ck('fence closing lines exact',all(line.strip()==f for line in fences[1::2]))

# Pure reference arithmetic, not OS/runtime product tests.
GiB=1<<30
def admit(cache,current_future,new_cache,cap,available,volume_future,new_volume,reserve):
 if min(cache,current_future,new_cache,cap,available,volume_future,new_volume,reserve)<0:return False
 return cache+current_future+new_cache<=cap and available>=volume_future+new_volume+reserve
ck('configured512 cap accepts400',admit(300*GiB,50*GiB,50*GiB,512*GiB,150*GiB,50*GiB,50*GiB,2*GiB))
ck('configured128 rejects200 despite384 default',not admit(100*GiB,50*GiB,50*GiB,128*GiB,150*GiB,50*GiB,50*GiB,2*GiB))
ck('durable consumes volume not cache',admit(380*GiB,0,0,384*GiB,100*GiB,16*GiB,8*GiB,2*GiB))
ck('aggregate reserve prevents overbook',not admit(0,0,0,384*GiB,20*GiB,16*GiB,3*GiB,2*GiB))
ck('future-vs-actual not double counted',100+20==108+12)
ck('multi-profile sizing counterexample',3*2+1==7 and 7*48==336)
# Entire schema-valid manifest entry worst-case bound using literal UTF-8/no padding.
maxentry={'path':'\U0001f600'*4096,'status':'metadata_only','content_hash':'f'*64,'byte_length':9007199254740991,'reason_code':'\x01'*192}
rowbytes=len(json.dumps(maxentry,ensure_ascii=False,separators=(',',':')).encode('utf-8'))
upper=rowbytes*1000000+1000000+67*1000000+4096
ck('manifest hard32GiB covers canonical schema max fields',upper<34359738368)
# SQL compatibility and preservation; all in-memory, no WAL patch claim.
sqls=re.findall(r'<!-- BEGIN ([A-Z0-9_]+) -->\n'+f+r'sql\n(.*?)\n'+f,s,re.S)
ck('seven DDL blocks',len(sqls)==7)
dbs={k:sqlite3.connect(':memory:') for k in ['CATALOG','INDEX','RECORDS']}
for con in dbs.values():con.execute('PRAGMA foreign_keys=ON')
for marker,sql in sqls:
 kind=next(k for k in dbs if k in marker)
 dbs[kind].executescript(sql)
for kind,con in dbs.items():
 ck('SQL integrity '+kind,con.execute('PRAGMA integrity_check').fetchall()==[('ok',)])
 ck('SQL FK '+kind,con.execute('PRAGMA foreign_key_check').fetchall()==[])
 con.close()
orig=(run/'baseline.bin').read_bytes().decode().replace('\r\n','\n')
oldsql=re.findall(r'<!-- BEGIN ([A-Z0-9_]+) -->\n'+f+r'sql\n(.*?)\n'+f,orig,re.S)
ck('SQL bytes unchanged',sqls==oldsql)
ck('CRLF no BOM/no stray LF',not b.startswith(b'\xef\xbb\xbf') and b.count(b'\n')==b.count(b'\r\n'))
source_hashes=json.loads((run/'source-hashes.json').read_text())
ck('three policies byte unchanged',all(hashlib.sha256((source_root/k).read_bytes()).hexdigest()==v for k,v in source_hashes.items()) and len(source_hashes)==3)
# Rendering structure: each contiguous table has header-width rows.
table_errors=[];width=None;in_fence=False
for lineno,l in enumerate(s.splitlines(),1):
 if l.strip().startswith(f):in_fence=not in_fence;continue
 if in_fence:continue
 if l.startswith('|'):
  n=len(re.split(r'(?<!\\)\|',l))-2
  if width is None:width=n
  elif n!=width:table_errors.append((lineno,width,n,l[:120]))
 else:width=None
ck('all GFM table row widths',not table_errors)
ck('no remaining current version conflict','Bản hiện tại1.6.0' not in s and 'Đặc tả v1.6.0 là' not in s and 'V1.6.0 construction routing' not in s)
ck('12 closures/discrepancies',len(re.findall(r'^\| N\d{2} ',s,re.M))==12 and all('| D'+str(i).zfill(3)+' |' in s for i in range(9,21)))
semantic_hash=hashlib.sha256(json.dumps(sc,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
default_hash=hashlib.sha256(json.dumps(defaults,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
result={'spec_version':'1.6.2','sha256':hashlib.sha256(b).hexdigest(),'checks_passed':len(checks),'checks_failed':0,'counts':{'sections':54,'requirements':130,'tasks':108,'cases':195,'requirement_task_edges':len(edgesR),'definitions':len(D),'local_refs':len(refs),'vectors':len(vectors)},'schema_semantic_sha256':semantic_hash,'defaults_semantic_sha256':default_hash,'manifest_max_field_upper_bound_bytes':upper,'toolchain':{'python':platform.python_version(),'sqlite':sqlite3.sqlite_version,'jsonschema':importlib.metadata.version('jsonschema')},'checks':checks,'scope':'document/meta-schema/shape-fixtures/pure-arithmetic/in-memory-SQL; product+OS+XL NOT_RUN'}
(run/'validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='checks'},ensure_ascii=False,indent=2))
