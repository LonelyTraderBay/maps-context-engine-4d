# Additional independent contract oracles for J01-J07. No product/GitHub calls.
def fixture166():
    return {k:copy.deepcopy(v) for k,v in dict(at=attempt,pl=plan,ob=observation,ar=archive,fs=files,sel=selection,ca=candidate,po=payload_obs,current_pr=None).items()}


def rebind166(d):
    at,pl,ob,ar,fs,sel,po=[d[k] for k in ['at','pl','ob','ar','fs','sel','po']]
    digest=hashlib.sha256(C14(pl)).hexdigest()
    for x in [at,ar,ob,po]:x['check_plan_sha256']=digest
    for o in [po,ob]:
        try:
            bind_command_fixture_identity(at,o,fs)
            make_collection_fixture(pl,o,fs)
        except (ValueError,KeyError,TypeError):pass # Deliberately malformed legacy negative; evaluator must reject it.
    install_commit_fixtures(at,ar,fs)
    fs[at['check_plan_ref']]=C14(pl);fs[ar['attempt_ref']]=C14(at);fs[ar['selection_ref']]=C14(sel)
    fs[ar['payload_observation_ref']]=C14(po);fs[ar['closing_observation_ref']]=C14(ob)
    ar['files']=manifest_for(fs)
    return d


def done166(d,offline=False):
    rebind166(d)
    return fixture_done(d['at'],d['pl'],d['ob'],d['ar'],d['fs'],[d['ca']],['S19/T001/Status'],C,offline=offline,sel=d['sel'],seal_record=seal_for(d['ar']),published=True,current_pr=d['current_pr'])


regressions166=[]
def rejects166(name,change):
    d=fixture166();change(d);accepted=done166(d)
    ck('J regression reject '+name,not accepted)
    regressions166.append({'probe':name,'expected':'REJECT_OR_UNKNOWN','accepted':accepted})


rejects166('missing_canary_locator',lambda d:d['pl'].update(canary_ref='missing/canary.json'))
def second_local166(d):
    d['pl']['local_check_refs'].append('local/security')
    for phase,sha in [('payload',P),('closing',C)]:
        ref='local-security-'+phase+'.json'
        value={**copy.deepcopy(local),'command_ref':'local/security','phase':phase,'revision':sha,'result':'FAIL' if phase=='payload' else 'PASS'}
        d['at']['local_evidence_refs'].append(ref);d['fs'][ref]=C14(value)
rejects166('required_second_local_check_failed',second_local166)
rejects166('check_evidence_points_to_plan_not_execution',lambda d:[v.update(evidence_refs=['plan.json']) for o in [d['po'],d['ob']] for v in o['checks']])
def duplicate166(d):
    d['pl']['checks'].append({**copy.deepcopy(check),'id':'same-job-second-id'})
    for o in [d['po'],d['ob']]:o['checks'].append({**copy.deepcopy(o['checks'][0]),'check_id':'same-job-second-id'})
rejects166('two_required_ids_same_job_execution',duplicate166)


def pr166(d):
    d['pl']['checks'][0].update(eligible_events=['pull_request'],checkout_binding='pr_merge')
    d['pl']['repository']['ref']='refs/heads/task-t001'
    d['pl']['pull_request_flow']={'head_repository_id':repo['repository_id'],'head_ref':'refs/heads/task-t001','base_ref':'refs/heads/main'}
    parents=load_member(d['fs'],d['ar']['git_evidence_ref']);parents[Q]=[]
    d['current_pr']={}
    for o in [d['po'],d['ob']]:
        o['destination_observation']['repository']=copy.deepcopy(d['pl']['repository'])
        put_push_evidence(d['fs'],o['destination_observation'])
        merge_sha='e'*40 if o['phase']=='payload' else M
        parents[merge_sha]=[Q,o['subject_sha']]
        for value in o['checks']:
            value.update(event='pull_request',pr_head_sha=o['subject_sha'],pr_base_sha=Q,tested_merge_sha=merge_sha,tested_checkout_sha=merge_sha)
            put_check_evidence(d['fs'],value,o['subject_sha'],o['phase'],req=d['pl']['checks'][0])
        ref='pr-'+o['phase']+'.json';raw='pr-api-'+o['phase']+'.json'
        binding={'format_version':1,'kind':'pull_request_binding','host':repo['host'],'repository_id':repo['repository_id'],'pull_request_number':1,'head_repository_id':repo['repository_id'],'head_ref':'refs/heads/task-t001','base_ref':'refs/heads/main','head_sha':o['subject_sha'],'base_sha':Q,'tested_merge_sha':merge_sha,'observed_at_utc':now,'api_evidence_ref':raw}
        d['fs'][ref]=C14(binding);d['fs'][raw]=C14({'kind':'pull_request_api_snapshot',**{k:v for k,v in binding.items() if k not in ['format_version','kind','api_evidence_ref']}})
        o['pull_request_binding_ref']=ref;d['current_pr'][o['phase']]=copy.deepcopy(binding)
    d['fs'][d['ar']['git_evidence_ref']]=C14(parents)


positive_pr166=fixture166();pr166(positive_pr166)
ck('J03 valid distinct P C PR merges with current parent proof',done166(positive_pr166))
def missing_parents166(d):
    pr166(d);parents=load_member(d['fs'],d['ar']['git_evidence_ref']);parents.pop(M);d['fs'][d['ar']['git_evidence_ref']]=C14(parents)
rejects166('pr_tested_merge_without_git_parent_proof',missing_parents166)
rejects166('stale_push_preflight_year_old',lambda d:[o['destination_observation'].update(observed_at_utc='2025-01-01T00:00:00Z') for o in [d['po'],d['ob']]])
def fractional166(d):
    for o in [d['po'],d['ob']]:
        value={**copy.deepcopy(o['checks'][0]),'run_id':'1002','run_created_at_utc':'2026-10-15T03:00:00.100Z','status':'queued','conclusion':'unknown','execution_verified':False}
        put_check_evidence(d['fs'],value,o['subject_sha'],o['phase']);o['checks'].append(value)
rejects166('new_pending_run_fractional_time_sorted_before_old',fractional166)
def relabel166(d):
    for x in [d['at'],d['ar'],d['sel']]:x['task_revision']=2
    for ref in d['at']['local_evidence_refs']:
        value=load_member(d['fs'],ref);value['task_revision']=2;d['fs'][ref]=C14(value)
rejects166('revision2_reuses_delivery_without_supersedes_or_invalidation',relabel166)
ck('eight reviewed counterexamples now rejected',len(regressions166)==8 and not any(x['accepted'] for x in regressions166))
(run/'review-1.6.6-validation.json').write_text(json.dumps({'original_incorrect_acceptances':8,'current_incorrect_acceptances':0,'regressions':regressions166},indent=2),encoding='utf-8')

# Isolate each new guard so rejection is not merely another schema/hash mismatch.
for ref in ['missing.json','plan.json']:
    d=fixture166();d['at']['local_evidence_refs'].append(ref)
    ck('J01 local missing or wrong kind '+ref,not local_evidence_ok(d['at'],d['pl'],d['fs'],C))
d=fixture166();second_local166(d)
ck('J01 full second local FAIL isolated',not local_evidence_ok(d['at'],d['pl'],d['fs'],C))
for ref in d['at']['local_evidence_refs']:
    value=load_member(d['fs'],ref);value['result']='PASS';d['fs'][ref]=C14(value)
ck('J01 all two local checks P C positive',done166(d))
for field,value in [('result','NOT_RUN'),('result','UNKNOWN'),('execution_verified',False),('revision',Q),('phase','closing'),('delivery_id',U2),('task_revision',2)]:
    d=fixture166();v=load_member(d['fs'],'local.json');v[field]=value;d['fs']['local.json']=C14(v)
    ck('J01 local rejects '+field+str(value),not local_evidence_ok(d['at'],d['pl'],d['fs'],C))
d=fixture166();v=load_member(d['fs'],'local-closing.json');v.update(revision=P,reused_from_ref='local.json',log_refs=copy.deepcopy(local['log_refs']));d['fs']['local-closing.json']=C14(v)
ck('J01 closing reuse requires frozen permission',not done166(d))
d['pl']['closing_local_reuse_refs']=[check['command_refs'][0]]
ck('J01 explicit closing local reuse with payload proof positive',done166(d))
d=fixture166();duplicate166(d);ck('J01 duplicate natural job isolated',not plan_ok(d['pl']))
for field in ['source_evidence_ref','execution_evidence_ref']:
    d=fixture166();d['ob']['checks'][0][field]='plan.json'
    ck('J01 check typed role rejects plan '+field,not done166(d))
d=fixture166();o=d['ob']['checks'][0];ex=typed(d['fs'],o['execution_evidence_ref'],'GitCheckExecutionEvidence');ex['command_results'][0]['result']='FAIL';d['fs'][o['execution_evidence_ref']]=C14(ex)
ck('J01 execution flags cannot override failed command',not done166(d))
for ref in ['plan.json','closing.json','../canary.json','delivery:'+U2+':payload']:
    d=fixture166();d['pl']['canary_ref']=ref;rebind166(d)
    ck('J01 canary wrong kind locator '+ref,not canary_ok(d['at'],d['pl'],d['po'],d['ob'],d['fs']))

# Exact instants, generation/attempt ordering, malformed/ambiguous candidates.
ck('J02 fractional new instant ordered after whole second',instant(now)<instant('2026-10-15T03:00:00.100Z'))
ck('J02 offsets represent equal instants',instant(now)==instant('2026-10-15T10:00:00+07:00'))
ck('J02 arbitrary fractional precision preserved',instant('2026-10-15T03:00:00.100000000000000000000000001Z')>instant('2026-10-15T03:00:00.1Z'))
for newer in [{'run_created_at_utc':'2026-10-15T03:00:00.100Z','run_id':'1002','status':'queued','conclusion':'unknown'}, {'run_created_at_utc':'2026-10-15T10:00:00+07:00','run_id':'1002','conclusion':'failure'}, {'attempt':2,'status':'waiting','conclusion':'unknown'}]:
    ck('J02 newer candidate blocks old green '+str(newer),not checks_ok(plan,[observed,{**observed,**newer}],C))
for patch in [{'run_created_at_utc':'no-time'},{'run_id':'not-numeric'},{'run_id':'1001','run_created_at_utc':'2026-10-15T03:00:01Z'},{'attempt':1,'conclusion':'failure'}]:
    ck('J02 malformed conflicting candidate unknown '+str(patch),not checks_ok(plan,[observed,{**observed,**patch}],C))
ck('J02 new generation beats larger old attempt',not checks_ok(plan,[{**observed,'attempt':5},{**observed,'run_id':'1002','attempt':1,'conclusion':'failure'}],C))

for phase in ['payload','closing']:
    for key,value in [('head_sha',Q),('base_sha',P),('head_ref','refs/heads/other'),('base_ref','refs/heads/other'),('repository_id',999),('tested_merge_sha',P)]:
        d=copy.deepcopy(positive_pr166)
        if phase=='payload':
            ref=d['po']['pull_request_binding_ref'];v=load_member(d['fs'],ref);v[key]=value;d['fs'][ref]=C14(v)
        else:d['current_pr'][phase][key]=value
        ck('J03 retained payload or live closing PR '+phase+key,not done166(d))
d=copy.deepcopy(positive_pr166);d['current_pr']=None
ck('J03 live PR cannot omit current snapshot',not done166(d))
ck('J03 historical PR offline retains parent snapshot proof',done166(d,offline=True))
d=copy.deepcopy(positive_pr166);parents=load_member(d['fs'],d['ar']['git_evidence_ref']);parents[M]=[C,Q];d['fs'][d['ar']['git_evidence_ref']]=C14(parents)
ck('J03 ordered merge parents cannot swap',not done166(d))

def revision166():
    d=fixture166();old=copy.deepcopy(d['sel']);d['fs']['previous-selection.json']=C14(old)
    for x in [d['at'],d['ar'],d['sel']]:x['task_revision']=2
    for x in [d['at'],d['ar'],d['po'],d['ob']]:x['delivery_id']=U2
    d['sel'].update(active_delivery_id=U2,supersedes_delivery_id=U,previous_selection_ref='previous-selection.json',invalidation_refs=['invalidation.json'])
    d['at'].update(closing_marker='MCE4D-Delivery-ID: '+U2,planned_archive_path='artifacts/git-delivery/'+U2,archive_staging_path='artifacts/git-delivery/.staging-'+U2)
    d['ca']['marker']=d['at']['closing_marker'];d['pl']['canary_ref']='delivery:'+U2+':payload'
    d['fs']['invalidation.json']=C14({'kind':'delivery_invalidation','task_id':'T001','assignment_ref':old['assignment_ref'],'old_revision':1,'new_revision':2,'old_delivery_id':U,'new_delivery_id':U2,'reason':'fixture contract regression repaired'})
    for ref in d['at']['local_evidence_refs']:
        v=load_member(d['fs'],ref);v.update(task_revision=2,delivery_id=U2);d['fs'][ref]=C14(v)
    return d
d=revision166();ck('J04 valid revision2 new UUID complete history',done166(d))
for patch in [{'previous_selection_ref':None},{'previous_selection_ref':'selection.json'},{'supersedes_delivery_id':U2},{'invalidation_refs':[]},{'task_revision':3}]:
    d=revision166();d['sel'].update(patch);rebind166(d)
    ck('J04 invalid selection chain '+str(patch),not selection_ok(d['sel'],d['at'],d['fs']))
d=revision166();d['fs']['invalidation.json']=C14({'kind':'not-an-invalidation'})
ck('J04 invalidation wrong typed identity',not selection_ok(d['sel'],d['at'],d['fs']))
actual_checkpoint={k:checkpoint[k] for k in ['assignment_ref','local_branch','head_sha','working_tree_digest','index_digest','command_state','operation_id']}
valid_checkpoint={**checkpoint,'command_record_ref':'checkpoint-command.json'}
checkpoint_fs={**files,'checkpoint-command.json':C14(command_fixture(checkpoint_like=valid_checkpoint))}
actual_checkpoint=checkpoint_actual_fixture(actual_checkpoint,'checkpoint-command.json',checkpoint_fs)
ck('J04 semantic checkpoint UNKNOWN preserves identity',checkpoint_ok(valid_checkpoint,selection,actual_checkpoint,checkpoint_fs))
for state in ['RUNNING','SETTLING','SUCCEEDED','FAILED','UNKNOWN']:
    v={**valid_checkpoint,'command_state':state};ctx={**actual_checkpoint,'command_state':state};fs={**checkpoint_fs,'checkpoint-command.json':C14(command_fixture(checkpoint_like=v))}
    ctx=checkpoint_actual_fixture(ctx,'checkpoint-command.json',fs)
    ck('J04 actual command state positive '+state,checkpoint_ok(v,selection,ctx,fs))
    ck('J04 missing command identities rejected '+state,not checkpoint_ok({**v,'command_record_ref':None,'operation_id':None},selection,ctx,fs))
for key,value in [('delivery_id',None),('task_revision',2),('head_sha',P),('working_tree_digest','0'*64),('index_digest','0'*64),('planned_archive_path',None),('command_state','SUCCEEDED')]:
    ck('J04 stale inconsistent checkpoint '+key,not checkpoint_ok({**valid_checkpoint,key:value},selection,actual_checkpoint,checkpoint_fs))

for change in ['wait','interruption','remote_config_change','other_push']:
    d=fixture166();dest=d['ob']['destination_observation'];op=typed(d['fs'],dest['operation_evidence_ref'],'GitPushOperationEvidence');op['intervening_events']=[change];d['fs'][dest['operation_evidence_ref']]=C14(op)
    ck('J05 intervening event requires fresh query '+change,not destination_ok(d['pl'],dest,C,d['fs']))
for side,key,value in [('preflight','lifecycle_id',U2),('preflight','retry_index',1),('postflight','observed_remote_sha',P),('postflight','repository',{**repo,'visibility':'public'}),('preflight','completed_at_utc','2025-01-01T00:00:00Z')]:
    d=fixture166();dest=d['ob']['destination_observation'];op=typed(d['fs'],dest['operation_evidence_ref'],'GitPushOperationEvidence');op[side][key]=value;d['fs'][dest['operation_evidence_ref']]=C14(op)
    ck('J05 source lifecycle/retry/postflight drift '+side+key,not destination_ok(d['pl'],dest,C,d['fs']))
ck('J05 valid exact push preflight postflight positive',destination_ok(plan,observation['destination_observation'],C,files))

source166=typed(files,observed['source_evidence_ref'],'GitCheckSourceEvidence')
for native_status,native_conclusion,want_status,want_conclusion in [('queued',None,'queued','unknown'),('in_progress',None,'in_progress','unknown'),('waiting',None,'waiting','unknown'),('pending',None,'waiting','unknown'),('requested',None,'waiting','unknown'),('completed','success','completed','success'),('completed','failure','completed','failure'),('completed','stale','completed','unknown'),('completed',None,'completed','unknown'),('future_state',None,'waiting','unknown'),('in_progress','success','waiting','unknown')]:
    n=normalized_native({**source166,'native_status':native_status,'native_conclusion':native_conclusion})
    ck('J06 native check mapping '+native_status+str(native_conclusion),(n['status'],n['conclusion'])==(want_status,want_conclusion))
for state,want in [('success',('completed','success')),('failure',('completed','failure')),('error',('completed','failure')),('pending',('waiting','unknown')),('future',('waiting','unknown'))]:
    raw={**source166,'source_kind':'commit_status','source_app':repo['host']+':creator:99','run_id':None,'attempt':None,'job_id':None,'workflow_path':None,'job_name':None,'native_status':state,'native_conclusion':None,**{k:None for k in ['check_suite_id','workflow_head_sha','job_head_sha','job_check_run_url']}}
    n=normalized_native(raw);ck('J06 native status mapping '+state,(n['status'],n['conclusion'])==want and n['run_id']==raw['record_id'] and n['attempt']==1)
raw={**source166,'source_kind':'external_check_run','run_id':None,'attempt':None,'job_id':None,'workflow_path':None,'job_name':None,'event':'external_app',**{k:None for k in ['check_suite_id','workflow_head_sha','job_head_sha','job_check_run_url']}}
n=normalized_native(raw);ck('J06 external App uses check ID not invented run',n['run_id']==raw['record_id'] and n['attempt']==1)
for kind in ['external_check_run','commit_status']:
    try:normalized_native({**source166,'source_kind':kind});rejected=False
    except ValueError:rejected=True
    ck('J06 reject invented workflow metadata '+kind,rejected)

def alternate_source166(d,source_kind):
    req=d['pl']['checks'][0];req.update(kind='commit_status' if source_kind=='commit_status' else 'check_run',workflow_path=None,job_name=None,eligible_events=['external_app'],source_app=repo['host']+(':creator:99' if source_kind=='commit_status' else ':app:456'))
    for o in [d['po'],d['ob']]:
        for v in o['checks']:
            v.update(kind=req['kind'],workflow_path=None,job_name=None,job_id=None,event='external_app',source_app=req['source_app'],attempt=1)
            put_check_evidence(d['fs'],v,o['subject_sha'],o['phase'],req=req,source_kind=source_kind)
for kind in ['external_check_run','commit_status']:
    d=fixture166();alternate_source166(d,kind);ck('J06 full valid delivery source '+kind,done166(d))
d=fixture166();alternate_source166(d,'commit_status');d['pl']['checks'][0]['context']=d['pl']['checks'][0]['context'].upper()
ck('J06 commit status context case insensitive',done166(d))

for schema,ref in [('GitLocalCheckEvidence','local.json'),('GitCheckSourceEvidence',observed['source_evidence_ref']),('GitCheckExecutionEvidence',observed['execution_evidence_ref']),('GitPushOperationEvidence',observation['destination_observation']['operation_evidence_ref'])]:
    value=load_member(files,ref);ck('J typed positive '+schema,gv(schema,value));ck('J typed unknown rejected '+schema,not gv(schema,{**value,'unknown':1}))
ck('J typed positive PR binding',gv('GitPullRequestBinding',load_member(positive_pr166['fs'],positive_pr166['ob']['pull_request_binding_ref'])))
canary_shape={'format_version':1,'kind':'canary','credential_class':'local_user','check_plan_ref':'plan.json','observation_ref':'payload.json','git_evidence_ref':'git.json'}
ck('J typed positive canary',gv('GitCanaryEvidence',canary_shape))

for value in [1,1234,5000,8000]:
    cfg={'schema_version':1,'core':{'sqlite_busy_timeout_ms':value}}
    ck('J07 nondefault busy timeout pure preview '+str(value),config_preview(cfg)['core']['sqlite_busy_timeout_ms']==value)
ck('J07 DB owner uses effective value no hardcode','busy_timeout=effective RuntimeConfig.core.sqlite_busy_timeout_ms (default5000ms)' in s and 'busy_timeout5000, FK1' not in s)
ck('J07 actual driver proof remains future task','T002/T106/T007 kiểm nondefault1234ms trên nhiều pooled connections' in s)

# A failed/queued older generation must not permanently block autonomous repair.
for old_state in ['failure','queued']:
    d=fixture166()
    for o in [d['po'],d['ob']]:
        v={**copy.deepcopy(o['checks'][0]),'run_id':'998' if o['phase']=='payload' else '999','job_id':'1998' if o['phase']=='payload' else '1999','run_created_at_utc':before,'conclusion':old_state if old_state=='failure' else 'unknown','status':'completed' if old_state=='failure' else 'queued','execution_verified':old_state=='failure'}
        put_check_evidence(d['fs'],v,o['subject_sha'],o['phase'])
        if old_state=='failure':
            ex=typed(d['fs'],v['execution_evidence_ref'],'GitCheckExecutionEvidence');ex['command_results'][0]['result']='FAIL';d['fs'][v['execution_evidence_ref']]=C14(ex)
        else:ck('J06 queued source has no fake execution '+o['phase'],v['execution_evidence_ref'] is None and not v['execution_verified'])
        o['checks'].append(v)
    ck('J repaired newest success after old '+old_state,done166(d))
d=copy.deepcopy(positive_pr166)
for o in [d['po'],d['ob']]:
    v={**copy.deepcopy(o['checks'][0]),'run_id':'996' if o['phase']=='payload' else '997','job_id':'1996' if o['phase']=='payload' else '1997','run_created_at_utc':before,'pr_base_sha':'f'*40,'tested_merge_sha':'9'*40,'tested_checkout_sha':'9'*40}
    put_check_evidence(d['fs'],v,o['subject_sha'],o['phase'],req=d['pl']['checks'][0]);o['checks'].append(v)
ck('J03 repaired current PR base preserves old candidate as history',done166(d))
d=fixture166();v=d['ob']['checks'][0];sr=typed(d['fs'],v['source_evidence_ref'],'GitCheckSourceEvidence');raw=load_member(d['fs'],sr['raw_api_ref']);raw['record']['app']['id']=999;d['fs'][sr['raw_api_ref']]=C14(raw)
ck('J06 native App ID drift cannot use claimed source_app',not done166(d))
idle={**valid_checkpoint,'task_id':None,'task_revision':None,'delivery_id':None,'planned_archive_path':None,'command_record_ref':None,'operation_id':None,'command_state':'NOT_STARTED'}
idle_actual=checkpoint_actual_fixture({**actual_checkpoint,'command_state':'NOT_STARTED','operation_id':None})
ck('J04 idle checkpoint positive',checkpoint_ok(idle,None,idle_actual,files))
ck('J04 idle cannot hide actual running command',not checkpoint_ok(idle,None,{**idle_actual,'command_state':'RUNNING','operation_id':UC},files))

# Historical canary has its own frozen plan/native observations/ancestry.
historical=fixture166();oldplan=copy.deepcopy(historical['pl']);oldpo=copy.deepcopy(historical['po'])
historical['fs']['historical-plan.json']=C14(oldplan);historical['fs']['historical-payload.json']=C14(oldpo);historical['fs']['historical-git.json']=historical['fs']['git.json']
historical['fs']['historical-canary.json']=C14({**canary_shape,'check_plan_ref':'historical-plan.json','observation_ref':'historical-payload.json','git_evidence_ref':'historical-git.json'})
historical['pl'].update(phase='foundation',canary_ref='historical-canary.json');historical['at'].update(task_id='T002',delivery_id=U2)
for i,o in enumerate([historical['po'],historical['ob']]):
    o['delivery_id']=U2;o['collection_evidence_ref']='new-canary-'+o['phase']+'.json'
    for v in o['checks']:
        v['run_id']=str(3000+i);v['job_id']=str(4000+i);put_check_evidence(historical['fs'],v,o['subject_sha'],o['phase'],req=historical['pl']['checks'][0])
    o['destination_observation']['push_operation_id']=str(uuid.uuid5(uuid.UUID(U2),o['phase']));put_push_evidence(historical['fs'],o['destination_observation'])
digest=hashlib.sha256(C14(historical['pl'])).hexdigest()
for o in [historical['po'],historical['ob']]:
    o['check_plan_sha256']=digest;make_collection_fixture(historical['pl'],o,historical['fs'])
ck('J01 compatible historical canary positive',canary_ok(historical['at'],historical['pl'],historical['po'],historical['ob'],historical['fs']))
bad=copy.deepcopy(historical);can=typed(bad['fs'],'historical-canary.json','GitCanaryEvidence');can['credential_class']='github_token';bad['fs']['historical-canary.json']=C14(can)
ck('J01 historical canary credential mismatch',not canary_ok(bad['at'],bad['pl'],bad['po'],bad['ob'],bad['fs']))

# Renaming every role must preserve typed reference resolution.
d=fixture166();rebind166(d);names={name:'renamed/'+str(i)+'.bin' for i,name in enumerate(d['fs'])}
def renamed166(v):
    if isinstance(v,str):return names.get(v,v)
    if isinstance(v,list):return [renamed166(x) for x in v]
    if isinstance(v,dict):return {k:renamed166(x) for k,x in v.items()}
    return v
nf={}
for name,data in d['fs'].items():
    try:value=json.loads(data,object_pairs_hook=dup);nf[names[name]]=C14(renamed166(value))
    except (ValueError,UnicodeError):nf[names[name]]=data
d.update(at=renamed166(d['at']),pl=renamed166(d['pl']),ob=renamed166(d['ob']),po=renamed166(d['po']),ar=renamed166(d['ar']),sel=renamed166(d['sel']),fs=nf)
ck('J all typed source execution push local roles renamed positive',done166(d))
ck('J runtime whole schema155 unchanged',sc==origblocks['MCE4D_CONTRACT_SCHEMA_V1'])
ck('J seven closures synchronized',all('| J'+str(i).zfill(2)+' P' in s for i in range(1,8)) and all('| D'+str(i).zfill(3)+' |' in s for i in range(37,44)))
