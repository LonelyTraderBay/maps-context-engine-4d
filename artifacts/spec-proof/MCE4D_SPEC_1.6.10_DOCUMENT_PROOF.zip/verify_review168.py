def verify_review168():
    """M01-M04 use frozen synthetic inputs and the normative composed evaluator."""
    start_count=len(checks);reg=[];snapshots={}
    def prepared(change=None,pr=False):
        x=fixture166()
        if pr:pr166(x)
        if change:change(x)
        rebind166(x)
        x['live'],x['lf'],x['ctx']=make_live_fixture(x['at'],x['pl'],x['ob'],x['ar'],x['fs'],x['current_pr']['closing'] if x['current_pr'] else None)
        return x
    def evaluate(x,offline=False):
        return effective_done(x['at'],x['pl'],x['ob'],x['ar'],x['fs'],[x['ca']],['S19/T001/Status'],C,offline=offline,sel=x['sel'],seal_record=seal_for(x['ar']),published=True,live_verification=x['live'],live_files=x['lf'],live_context=x['ctx'])
    def retain(x):
        x['fs'][x['ar']['attempt_ref']]=C14(x['at']);x['fs'][x['ar']['payload_observation_ref']]=C14(x['po']);x['fs'][x['ar']['closing_observation_ref']]=C14(x['ob']);x['ar']['files']=manifest_for(x['fs'])
        rehash_publication_fixture(x['ar'],x.get('live'),x.get('ctx'))
    def probe(name,actual,want,group):
        ck('M '+name,actual==want);reg.append({'group':group,'probe':name,'expected':want,'actual':actual})
    def collection_valid(x,live=False):
        o=typed(x['lf'],x['live']['closing_observation_ref'],'GitDeliveryObservation') if live else x['ob'];fs=x['lf'] if live else x['fs'];v=typed(fs,o['collection_evidence_ref'],'GitCICollectionEvidence')
        try:return collection_ok(x['pl'],o,v,fs,v['started_at_utc'],o['observed_at_utc'])
        except (ValueError,KeyError,TypeError):return False
    def edit_collection(x,change,live=False):
        fs=x['lf'] if live else x['fs'];o=typed(fs,x['live']['closing_observation_ref'],'GitDeliveryObservation') if live else x['ob'];coll=typed(fs,o['collection_evidence_ref'],'GitCICollectionEvidence');change(coll,fs);fs[o['collection_evidence_ref']]=C14(coll)
        if live:x['live']['files']=manifest_for(fs)
        else:retain(x)
    x=prepared();probe('control full baseline',evaluate(x),True,'control')
    # P1 M01: the exact push command ref is a valid resume/checkpoint ref.
    d=x['ob']['destination_observation'];op=typed(x['fs'],d['operation_evidence_ref'],'GitPushOperationEvidence');command=typed(x['fs'],op['command_record_ref'],'GitCommandLifecycle')
    cp={**valid_checkpoint,'command_record_ref':op['command_record_ref'],'operation_id':op['push_operation_id'],'command_state':'SUCCEEDED'};actual={**actual_checkpoint,'operation_id':cp['operation_id'],'command_state':'SUCCEEDED'}
    actual=checkpoint_actual_fixture(actual,op['command_record_ref'],x['fs'],d['operation_evidence_ref'])
    probe('checkpoint actual push record can resume',checkpoint_ok(cp,x['sel'],actual,x['fs']),True,'M01')
    probe('same unified lifecycle accepted by push',destination_ok(x['pl'],d,C,x['fs']),True,'M01')
    probe('common record full S51 contract retained',lifecycle_ok(command) and len(command['contract'])==31,True,'M01')
    snapshots['shared_lifecycle']={'checkpoint':cp,'actual':actual,'command':command,'operation':op}
    for state in ['NOT_STARTED','RUNNING','SETTLING','SUCCEEDED','FAILED','UNKNOWN']:
        v={**cp,'command_state':state};ctx={**actual,'command_state':state};fs={**x['fs'],op['command_record_ref']:C14(command_fixture(checkpoint_like=v,op=op,destination=d,at=x['at']))}
        ctx=checkpoint_actual_fixture(ctx,op['command_record_ref'],fs,d['operation_evidence_ref'])
        probe('shared lifecycle checkpoint state '+state,checkpoint_ok(v,x['sel'],ctx,fs),True,'M01')
        probe('only SUCCEEDED proves push '+state,destination_ok(x['pl'],d,C,fs),state=='SUCCEEDED','M01')
    for key,value in [('assignment_ref','other'),('task_id','T002'),('task_revision',2),('delivery_id',U2),('operation_id',U2),('command_state','RUNNING')]:
        cmd=copy.deepcopy(command);cmd[key]=value;fs={**x['fs'],op['command_record_ref']:C14(cmd)}
        probe('checkpoint envelope mismatch '+key,checkpoint_ok(cp,x['sel'],actual,fs),False,'M01')
    for patch in [{'lifecycle_id':U2},{'retry_index':1},{'result':{**command['result'],'command_exit_status':1}},{'result':{**command['result'],'cleanup_status':'FAILED'}},{'result':{**command['result'],'completed_at_utc':before}},{'contract':{**command['contract'],'deadline_at_utc':'2026-10-15T03:02:00Z'}}]:
        fs={**x['fs'],op['command_record_ref']:C14({**command,**patch})};probe('push lifecycle rejects '+str(list(patch))+str(patch)[:60],destination_ok(x['pl'],d,C,fs),False,'M01')
    for argv in [['git','push','--force','origin',C+':refs/heads/main'],['git','push','origin','+'+C+':refs/heads/main'],['git','push','other',C+':refs/heads/main'],['git','push','origin',C+':refs/heads/unrelated'],['git','push','--all','origin'],['git','push','origin',P+':refs/heads/main'],['git','push','origin',C+':refs/heads/main','--no-verify']]:
        cmd=copy.deepcopy(command);cmd['contract']['argv']=argv;fs={**x['fs'],op['command_record_ref']:C14(cmd)};probe('unapproved push argv '+str(argv),destination_ok(x['pl'],d,C,fs),False,'M01')
    for state,want in [('FAILED',True),('SUCCEEDED',False)]:
        cp_late={**cp,'command_state':state};cmd=command_fixture(checkpoint_like=cp_late,op=op,destination=d,at=x['at']);cmd['result']['completed_at_utc']='2026-10-15T03:01:01Z';fs={**x['fs'],op['command_record_ref']:C14(cmd)}
        probe('resume late finalization '+state,checkpoint_ok(cp_late,x['sel'],checkpoint_actual_fixture({**actual,'command_state':state},op['command_record_ref'],fs,d['operation_evidence_ref']),fs),want,'M01')
        probe('late finalization never proves push '+state,destination_ok(x['pl'],d,C,fs),False,'M01')
    minimal={'kind':'command_lifecycle',**{k:cp[k] for k in ['operation_id','task_id','task_revision','delivery_id','command_state']}};fs={**x['fs'],op['command_record_ref']:C14(minimal)}
    probe('minimal six fields not full S51 proof',checkpoint_ok(cp,x['sel'],actual,fs),False,'M01')
    y=prepared();dy=y['ob']['destination_observation'];opy=typed(y['fs'],dy['operation_evidence_ref'],'GitPushOperationEvidence');cmd=load_member(y['fs'],opy['command_record_ref']);cmd['task_id']='T002';y['fs'][opy['command_record_ref']]=C14(cmd);retain(y)
    probe('composed push must match active task',evaluate(y),False,'M01')
    # P1 M02: real check IDs differ from workflow IDs, two jobs, partial rerun.
    def two_jobs(x,partial=False,full=False):
        req=copy.deepcopy(x['pl']['checks'][0]);req.update(id='job-b',context='job-b',job_name='job-b');x['pl']['checks'].append(req)
        for oi,o in enumerate([x['po'],x['ob']]):
            a=o['checks'][0];base=6000+oi*100
            b={**copy.deepcopy(a),'check_id':'job-b','context':'job-b','job_name':'job-b','job_id':str(base+1)};o['checks'].append(b)
            if partial or full:
                b.update(conclusion='failure',execution_verified=False)
                o['checks'].append({**copy.deepcopy(b),'attempt':2,'job_id':str(base+2),'conclusion':'success','execution_verified':True})
                if full:o['checks'].append({**copy.deepcopy(a),'attempt':2,'job_id':str(base+3)})
            for j,v in enumerate(o['checks']):
                rq=x['pl']['checks'][0] if v['check_id']!='job-b' else req
                put_check_evidence(x['fs'],v,o['subject_sha'],o['phase'],req=rq)
                sr=typed(x['fs'],v['source_evidence_ref'],'GitCheckSourceEvidence');sr['record_id']=str(base+20+j);sr['job_check_run_url']='https://api.github.com/repos/fixture/mce4d-fixture/check-runs/'+sr['record_id'];x['fs'][v['source_evidence_ref']]=C14(sr);x['fs'][sr['raw_api_ref']]=C14(source_snapshot(sr))
    normal=prepared(two_jobs);partial=prepared(lambda d:two_jobs(d,partial=True));full=prepared(lambda d:two_jobs(d,full=True))
    probe('control two jobs one workflow',evaluate(normal),True,'control')
    probe('control latest per check accepts partial rerun',checks_ok(partial['pl'],partial['ob']['checks'],C),True,'control')
    probe('specific job rerun all required latest success',evaluate(partial),True,'M02')
    probe('native workflow latest attempt plus retained old jobs',collection_valid(partial),True,'M02')
    probe('full rerun native attempt details valid',evaluate(full),True,'M02')
    coll=typed(partial['fs'],partial['ob']['collection_evidence_ref'],'GitCICollectionEvidence');wr=next(p for p in coll['pages'] if p['endpoint']=='workflow_runs');detail=next(p for p in coll['pages'] if p['endpoint']=='workflow_run_attempt')
    probe('workflow list contains current row only',len(load_member(partial['fs'],wr['raw_page_ref'])['items'])==1 and load_member(partial['fs'],wr['raw_page_ref'])['items'][0]['run_attempt']==2,True,'M02')
    probe('older attempt separately scoped',detail['workflow_run_id']==partial['ob']['checks'][0]['run_id'] and detail['workflow_run_attempt']==1,True,'M02')
    snapshots['partial_rerun']={'plan':partial['pl'],'observation':partial['ob'],'collection':coll,'pages':{p['raw_page_ref']:load_member(partial['fs'],p['raw_page_ref']) for p in coll['pages']}}
    for label,change in [
        ('missing old attempt detail',lambda coll,fs:coll.update(pages=[p for p in coll['pages'] if p['endpoint']!='workflow_run_attempt'])),
        ('detail wrong selector',lambda coll,fs:next(p for p in coll['pages'] if p['endpoint']=='workflow_run_attempt').update(workflow_run_attempt=2)),
        ('list invented historical row',lambda coll,fs:fs.update({next(p for p in coll['pages'] if p['endpoint']=='workflow_runs')['raw_page_ref']:C14({**load_member(fs,next(p for p in coll['pages'] if p['endpoint']=='workflow_runs')['raw_page_ref']),'items':[load_member(fs,next(p for p in coll['pages'] if p['endpoint']=='workflow_runs')['raw_page_ref'])['items'][0],load_member(fs,next(p for p in coll['pages'] if p['endpoint']=='workflow_run_attempt')['raw_page_ref'])['items'][0]]})})),
    ]:
        z=copy.deepcopy(partial);edit_collection(z,change);probe(label,collection_valid(z),False,'M02');probe('composed '+label,evaluate(z),False,'M02')
    for status,conclusion in [('in_progress',None),('queued',None),('waiting',None),('completed',None)]:
        def change(coll,fs):
            page=next(p for p in coll['pages'] if p['endpoint']=='workflow_runs');raw=load_member(fs,page['raw_page_ref']);raw['items'][0].update(status=status,conclusion=conclusion);fs[page['raw_page_ref']]=C14(raw)
        z=copy.deepcopy(partial);edit_collection(z,change);probe('inherited job latest workflow '+status+str(conclusion),evaluate(z),False,'M02')
    for status,conclusion in [('queued','unknown'),('completed','failure')]:
        def bad_latest(z):
            two_jobs(z,partial=True)
            for o in [z['po'],z['ob']]:
                v=o['checks'][-1];v.update(status=status,conclusion=conclusion,execution_verified=False);put_check_evidence(z['fs'],v,o['subject_sha'],o['phase'],req=z['pl']['checks'][1])
        z=prepared(bad_latest);probe('latest B '+status+conclusion,evaluate(z),False,'M02')
    for key,value in [('head_sha',P),('workflow_path','.github/workflows/other.yml'),('event','pull_request'),('created_at',before),('run_attempt',3),('job_source_refs',[])]:
        def change(coll,fs):
            page=next(p for p in coll['pages'] if p['endpoint']=='workflow_run_attempt');raw=load_member(fs,page['raw_page_ref']);raw['items'][0][key]=value;fs[page['raw_page_ref']]=C14(raw)
        z=copy.deepcopy(partial);edit_collection(z,change);probe('old attempt metadata '+key,collection_valid(z),False,'M02')
    # P2 M03: self-consistency is insufficient if archived/live refs all name another flow.
    pr=prepared(pr=True);probe('control PR approved feature ref',evaluate(pr),True,'control')
    def change_pr(x,key,value):
        for o in [x['po'],x['ob']]:
            ref=o['pull_request_binding_ref'];v=typed(x['fs'],ref,'GitPullRequestBinding');v[key]=value;x['fs'][ref]=C14(v);x['fs'][v['api_evidence_ref']]=C14({'kind':'pull_request_api_snapshot',**{k:v for k,v in v.items() if k not in ['format_version','kind','api_evidence_ref']}})
        for fs,ref in [(x['lf'],x['live']['current_pr_ref']),(x['lf'],x['ob']['pull_request_binding_ref'])]:
            v=typed(fs,ref,'GitPullRequestBinding');v[key]=value;fs[ref]=C14(v);fs[v['api_evidence_ref']]=C14({'kind':'pull_request_api_snapshot',**{k:v for k,v in v.items() if k not in ['format_version','kind','api_evidence_ref']}})
        x['live']['files']=manifest_for(x['lf']);retain(x)
    for key,value in [('head_ref','refs/heads/unrelated'),('base_ref','refs/heads/unrelated'),('head_repository_id',999)]:
        z=copy.deepcopy(pr);change_pr(z,key,value);probe('PR all snapshots inconsistent approved flow '+key,evaluate(z),False,'M03')
    for patch in [{'pull_request_flow':None},{'pull_request_flow':{**pr['pl']['pull_request_flow'],'head_ref':'refs/heads/other'}},{'pull_request_flow':{**pr['pl']['pull_request_flow'],'head_repository_id':999}},{'pull_request_flow':{**pr['pl']['pull_request_flow'],'base_ref':'refs/heads/task-t001'}}]:
        probe('plan rejects unapproved PR flow '+str(patch),plan_ok({**pr['pl'],**patch}),False,'M03')
    probe('non PR plan cannot carry unrelated flow',plan_ok({**plan,'pull_request_flow':pr['pl']['pull_request_flow']}),False,'M03')
    # P2 M04: mutate wrapper AND retained Git source, isolate semantic metadata gate.
    def edit_commit(x,phase,field,value,raw_too=True):
        commit=x['at']['ordered_commits'][0] if phase=='payload' else typed(x['fs'],x['ar']['closing_commit_ref'],'GitCommit');commit[field]=value
        if raw_too:
            raw=load_member(x['fs'],commit['git_evidence_ref']);raw[field]=value;x['fs'][commit['git_evidence_ref']]=C14(raw)
        if phase=='closing':x['fs'][x['ar']['closing_commit_ref']]=C14(commit)
        retain(x)
    for phase in ['payload','closing']:
        baseline=prepared();record=baseline['at']['ordered_commits'][0] if phase=='payload' else typed(baseline['fs'],baseline['ar']['closing_commit_ref'],'GitCommit')
        probe('valid '+phase+' metadata',commit_ok(record,baseline['at'],git_parents,baseline['fs'],phase),True,'M04')
        for label,field,value in [('oops subject','subject','oops'),('wrong current task priority','subject','ci(bootstrap): [P3][T108] Kiểm tra bản vẽ'),('wrong current task','subject',record['subject'].replace('T001','T108')),('priority lacks rationale','subject',record['subject'].replace('[P1]','[P3]')),('body lacks headers','body','Nội dung tiếng Việt có dấu nhưng thiếu cấu trúc.'),('body header empty','body','Mục đích:\nThay đổi: Đã đồng bộ.\nKiểm tra: Đã kiểm.'),('English subject','subject',record['subject'].split('] ')[0]+'] Verify document contracts'),('English body','body','Purpose: Verify\nChanges: Update\nTests: Passed')]:
            z=prepared();edit_commit(z,phase,field,value);probe(phase+' '+label,evaluate(z),False,'M04')
        z=prepared();edit_commit(z,phase,'body',record['body']+'\nThay đổi bổ sung.',False);probe(phase+' wrapper source parity',evaluate(z),False,'M04')
        z=prepared();rec=z['at']['ordered_commits'][0] if phase=='payload' else typed(z['fs'],z['ar']['closing_commit_ref'],'GitCommit');z['fs'].pop(rec['git_evidence_ref']);retain(z);probe(phase+' missing actual Git source',evaluate(z),False,'M04')
        z=prepared();rec=z['at']['ordered_commits'][0] if phase=='payload' else typed(z['fs'],z['ar']['closing_commit_ref'],'GitCommit');scope=typed(z['fs'],rec['scope_ref'],'GitCommitScopeEvidence');scope['changed_paths']=['source/other.go'];z['fs'][rec['scope_ref']]=C14(scope);retain(z);probe(phase+' scope raw path mismatch',evaluate(z),False,'M04')
    z=prepared();closing=typed(z['fs'],z['ar']['closing_commit_ref'],'GitCommit');edit_commit(z,'closing','body',closing['body'].replace(U,U2));probe('closing actual UUID must match attempt',evaluate(z),False,'M04')
    z=prepared();closing=typed(z['fs'],z['ar']['closing_commit_ref'],'GitCommit');edit_commit(z,'closing','subject',closing['subject'].replace('docs(progress)','ci(progress)'));probe('closing type docs progress required',evaluate(z),False,'M04')
    z=prepared();closing=typed(z['fs'],z['ar']['closing_commit_ref'],'GitCommit');edit_commit(z,'closing','body',closing['body']+'\nMCE4D-Delivery-Phase: closing');probe('duplicate actual closing trailer',evaluate(z),False,'M04')
    z=prepared();rec=z['at']['ordered_commits'][0];scope=typed(z['fs'],rec['scope_ref'],'GitCommitScopeEvidence');scope.update(priority='P2',priority_reason_ref='priority-reason.json');z['fs'][rec['scope_ref']]=C14(scope);z['fs']['priority-reason.json']=C14({'kind':'priority_rationale','task_id':'T001','priority':'P2','reason':'Phân loại phần tài liệu trong task P1.'});edit_commit(z,'payload','subject',rec['subject'].replace('[P1]','[P2]'));probe('declared priority rationale permitted',evaluate(z),True,'M04')
    z=prepared();rec=z['at']['ordered_commits'][0];scope=typed(z['fs'],rec['scope_ref'],'GitCommitScopeEvidence');scope.update(task_ids=['T001','T002'],shared_invariant_ref='shared.json');z['fs'][rec['scope_ref']]=C14(scope);z['fs']['shared.json']=C14({'kind':'shared_invariant','task_ids':['T001','T002'],'reason':'Cùng một thay đổi hợp đồng không thể tách, không gộp delivery.'});edit_commit(z,'payload','subject',rec['subject'].replace('[T001]','[T001,T002]'));probe('declared indivisible shared invariant permitted',evaluate(z),True,'M04')
    z['fs'].pop('shared.json');retain(z);probe('multiple task IDs without retained invariant',evaluate(z),False,'M04')
    z=prepared();rec=z['at']['ordered_commits'][0];scope=typed(z['fs'],rec['scope_ref'],'GitCommitScopeEvidence');scope.update(breaking_decision_ref='breaking.json');z['fs'][rec['scope_ref']]=C14(scope);z['fs']['breaking.json']=C14({'kind':'breaking_decision','reason':'Quyết định đã cho phép đổi hợp đồng.'});edit_commit(z,'payload','subject',rec['subject'].replace(': [','!: ['));edit_commit(z,'payload','body',rec['body']+'\nBREAKING CHANGE: Đổi hợp đồng đã chấp thuận.');probe('breaking marker with declared decision',evaluate(z),True,'M04')
    z['fs'].pop('breaking.json');retain(z);probe('breaking marker without decision',evaluate(z),False,'M04')
    def noop(x):
        x['at'].update(payload_mode='verified_noop',base_sha=P,noop_reason_ref='no-op.json');x['fs']['no-op.json']=C14({'kind':'verified_noop_reason',**{k:x['at'][k] for k in ['assignment_ref','task_id','delivery_id','verified_payload_sha']},'reason':'Tái kiểm payload lịch sử còn đáp ứng, không có thay đổi nguồn.'})
    z=prepared(noop);probe('verified no-op full positive',evaluate(z),True,'M04')
    rec=z['at']['ordered_commits'][0];scope=typed(z['fs'],rec['scope_ref'],'GitCommitScopeEvidence');scope.update(task_ids=['T002'],priority='P3');z['fs'][rec['scope_ref']]=C14(scope);edit_commit(z,'payload','subject',rec['subject'].replace('[P1][T001]','[P3][T002]'));probe('no-op keeps original historical task metadata',evaluate(z),True,'M04')
    z['fs'].pop('no-op.json');retain(z);probe('no-op requires retained current reason',evaluate(z),False,'M04')
    for phase in ['payload','closing']:
        for what in ['task','priority']:
            z=prepared();rec=z['at']['ordered_commits'][0] if phase=='payload' else typed(z['fs'],z['ar']['closing_commit_ref'],'GitCommit');scope=typed(z['fs'],rec['scope_ref'],'GitCommitScopeEvidence')
            if what=='task':scope['task_ids']=['T108'];subject=rec['subject'].replace('[T001]','[T108]')
            else:scope['priority']='P3';subject=rec['subject'].replace('[P1]','[P3]')
            z['fs'][rec['scope_ref']]=C14(scope);edit_commit(z,phase,'subject',subject);probe(phase+' mutually consistent wrong active '+what,evaluate(z),False,'M04')
        z=prepared();rec=z['at']['ordered_commits'][0] if phase=='payload' else typed(z['fs'],z['ar']['closing_commit_ref'],'GitCommit');scope=typed(z['fs'],rec['scope_ref'],'GitCommitScopeEvidence');scope['phase']='closing' if phase=='payload' else 'payload';z['fs'][rec['scope_ref']]=C14(scope);retain(z);probe(phase+' scope wrong phase',evaluate(z),False,'M04')
        z=prepared();rec=z['at']['ordered_commits'][0] if phase=='payload' else typed(z['fs'],z['ar']['closing_commit_ref'],'GitCommit');raw=load_member(z['fs'],rec['git_evidence_ref']);raw['parents']=[Q];z['fs'][rec['git_evidence_ref']]=C14(raw);retain(z);probe(phase+' actual source parent mismatch',evaluate(z),False,'M04')
    z=prepared();rec=typed(z['fs'],z['ar']['closing_commit_ref'],'GitCommit');scope=typed(z['fs'],rec['scope_ref'],'GitCommitScopeEvidence');raw=load_member(z['fs'],rec['git_evidence_ref']);scope['changed_paths']=raw['changed_paths']=['source/other.go'];z['fs'][rec['scope_ref']]=C14(scope);z['fs'][rec['git_evidence_ref']]=C14(raw);retain(z);probe('closing consistent source path outside metadata',evaluate(z),False,'M04')
    z=prepared();rec=z['at']['ordered_commits'][0];edit_commit(z,'payload','body',rec['body']+'\nMCE4D-Delivery-ID: '+U);probe('payload cannot impersonate closing trailer',evaluate(z),False,'M04')
    z=prepared(noop);reason=load_member(z['fs'],'no-op.json');reason['task_id']='T108';z['fs']['no-op.json']=C14(reason);retain(z);probe('no-op reason wrong current task',evaluate(z),False,'M04')
    z=prepared();z['at']['noop_reason_ref']='unexpected.json';retain(z);probe('changes payload must not carry no-op reason',evaluate(z),False,'M04')
    for name in ['GitCommandLifecycle','GitCommitScopeEvidence']:
        value=command if name=='GitCommandLifecycle' else typed(files,attempt['ordered_commits'][0]['scope_ref'],name)
        probe('closed schema '+name,gv(name,value) and not gv(name,{**value,'extra':True}),True,'schema')
    probe('current five closures metadata',fm['latest_review_findings']==fm['latest_review_findings_integrated']==5 and resume['latest_review_closure']=='S52_CLOSE_10',True,'sync')
    probe('M references tasks cases and ADR synchronized',all(k in s for k in ['COMMAND-LIFECYCLE-01','JOB-ATTEMPT-01','PR-FLOW-01','COMMIT-GATE-01','A049','D050','D051','D052','D053','REF73','REF74']) and len(tasks)==108 and all(r[6].strip()=='TODO' for r in tasks),True,'sync')
    result={'spec_version':'1.6.8','groups':['M01 P1','M02 P1','M03 P2','M04 P2'],'new_assertions':len(checks)-start_count,'current_unresolved':0,'reviewed_counterexamples_corrected':7,'regressions':reg,'synthetic_input_snapshots':snapshots,'scope':'Document/reference only; no actual Git metadata extraction/command execution/product/collector/GitHub/CI evidence.'}
    (run/'review-1.6.8-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')

verify_review168()
