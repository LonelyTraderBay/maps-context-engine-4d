"""Explicit synthetic current-command context construction for tests only."""


def checkpoint_actual_fixture(actual, ref=None, fs=None, push_operation_ref=None):
    fields = dict(command_record_ref=None, command_record_sha256=None, lifecycle_id=None, retry_index=None, push_operation_ref=None)
    if ref is not None:
        command = typed(fs, ref, 'GitCommandLifecycle')
        fields.update(command_record_ref=ref, command_record_sha256=hashlib.sha256(fs[ref]).hexdigest(), lifecycle_id=command['lifecycle_id'], retry_index=command['retry_index'], push_operation_ref=push_operation_ref)
    return {**actual, **fields}
