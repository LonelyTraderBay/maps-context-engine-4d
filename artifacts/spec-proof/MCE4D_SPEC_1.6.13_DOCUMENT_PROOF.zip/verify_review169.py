def verify_review169():
    """V168-01..05: frozen synthetic semantic regressions, no product/network."""
    before_count=len(checks);review=[];cases=[]
    def test(name,actual,want,group):
        ck('V169 '+group+' '+name,actual==want)
        cases.append({'group':group,'probe':name,'expected':want,'actual':actual})
    def regression(name,x,want,group):
        actual=evaluate169(x);test(name,actual,want,group)
        review.append({'probe':name,'expected':want,'actual':actual})
    def live_ob(x):return typed(x['lf'],x['live']['closing_observation_ref'],'GitDeliveryObservation')
    def save_live(x,o,collect=False):
        if collect:make_collection_fixture(x['pl'],o,x['lf'],x['live']['started_at_utc'],x['live']['completed_at_utc'])
        x['lf'][x['live']['closing_observation_ref']]=C14(o);x['live']['files']=manifest_for(x['lf'])
    def ledger(observations):
        try:return native_ledger_ok(observations)
        except (ValueError,KeyError,TypeError,OverflowError):return False
    # All 16 independent prior probes are preserved by name/expected behavior.
    regression('control valid baseline',prepared169(),True,'control')
    for trailer in ['MCE4D-Delivery-ID: '+U2,'MCE4D-Delivery-Phase: payload']:
        x=prepared169();rec=typed(x['fs'],x['ar']['closing_commit_ref'],'GitCommit');change_commit169(x,'closing','body',rec['body']+'\n'+trailer)
        regression('conflicting actual closing trailer '+trailer,x,False,'V168-04')
    for phase in ['payload','closing']:
        x=prepared169();rec=x['at']['ordered_commits'][0] if phase=='payload' else typed(x['fs'],x['ar']['closing_commit_ref'],'GitCommit');change_commit169(x,phase,'subject',rec['subject']+' [skip ci]')
        regression('forbidden skip CI subject '+phase,x,False,'V168-05')
    regression('control PR before base change',prepared169(pr=True),True,'control')
    for reuse in [False,True]:
        x=prepared169(pr=True);current_base169(x,reuse)
        regression('new PR base '+('reuses same native execution' if reuse else 'new actual run job IDs'),x,not reuse,'V168-01')
    for phase in ['payload','closing']:
        x=prepared169();o=x['po'] if phase=='payload' else x['ob'];d=o['destination_observation'];op=typed(x['fs'],d['operation_evidence_ref'],'GitPushOperationEvidence');later='2026-10-15T03:00:30Z'
        op['push_completed_at_utc']=later;op['postflight']['started_at_utc']=op['postflight']['completed_at_utc']=later
        x['fs'][op['postflight']['raw_api_ref']]=C14({'kind':'destination_api_snapshot','push_operation_id':op['push_operation_id'],**op['postflight'],'raw_api_ref':None})
        cmd=typed(x['fs'],op['command_record_ref'],'GitCommandLifecycle');cmd['result']['completed_at_utc']=later;x['fs'][op['command_record_ref']]=C14(cmd);x['fs'][d['operation_evidence_ref']]=C14(op);retain169(x)
        for ref in [op['command_record_ref'],d['operation_evidence_ref'],op['postflight']['raw_api_ref']]:x['lf'][ref]=x['fs'][ref]
        x['live']['files']=manifest_for(x['lf'])
        regression('CI receipt and archive before '+phase+' push postflight completion',x,False,'V168-02')
    for later_task in [False,True]:
        for unrelated,validpr in [(False,False),(True,False),(False,True)]:
            x=prepared169(pr=True);historical_canary169(x,unrelated,validpr)
            if later_task:later_task169(x)
            regression(('T002 ' if later_task else '')+'historical canary '+('actual successful PR' if validpr else 'push plus unrelated pending PR' if unrelated else 'push only'),x,validpr,'V168-03')
    prior=json.loads((run/'regression-1.6.8.json').read_text(encoding='utf-8'))
    test('all prior probes names and expected preserved',[(v['probe'],v['expected']) for v in review]==[(v['probe'],v['expected']) for v in prior],True,'sync')
    test('nine incorrect acceptances corrected',sum(v['actual']!=v['expected'] for v in prior)==9 and all(v['actual']==v['expected'] for v in review),True,'sync')
    test('later task closing leaves correctly scoped',closing_diff_ok(['S19/T002/Status'],task_id='T002'),True,'V168-03')
    test('later task cannot change T001 status',closing_diff_ok(['S19/T001/Status'],task_id='T002'),False,'V168-03')
    # P1 V168-01: guard the execution inputs and command evidence, allow normal completion.
    x=prepared169();o=x['ob'];fs=x['fs'];v=o['checks'][0]
    test('identical terminal readback',ledger([(o,fs),(copy.deepcopy(o),copy.deepcopy(fs))]),True,'V168-01')
    for field in ['tested_checkout_sha','pr_head_sha','pr_base_sha','tested_merge_sha','matrix']:
        other=copy.deepcopy(o);other['checks'][0][field]={'os':'other'} if field=='matrix' else Q
        test('terminal immutable '+field,ledger([(o,fs),(other,copy.deepcopy(fs))]),False,'V168-01')
    for mode in ['revision','command','result','log','drop_command','add_command','drop_execution']:
        other=copy.deepcopy(o);of=copy.deepcopy(fs);val=other['checks'][0];e=typed(of,val['execution_evidence_ref'],'GitCheckExecutionEvidence')
        if mode=='revision':e['command_results'][0]['revision']=Q
        elif mode=='command':e['command_results'][0]['command_ref']='different-command'
        elif mode=='result':e['command_results'][0]['result']='FAIL'
        elif mode=='log':of[e['command_results'][0]['log_ref']]=b'different terminal command log'
        elif mode=='drop_command':e['command_results']=[]
        elif mode=='add_command':e['command_results'].append({**e['command_results'][0],'command_ref':'extra-command'})
        else:val['execution_evidence_ref']=None;val['execution_verified']=False
        if val['execution_evidence_ref'] is not None:of[val['execution_evidence_ref']]=C14(e)
        test('terminal evidence drift '+mode,ledger([(o,fs),(other,of)]),False,'V168-01')
    pending=copy.deepcopy(o);pf=copy.deepcopy(fs);val=pending['checks'][0];sr=typed(pf,val['source_evidence_ref'],'GitCheckSourceEvidence');sr.update(native_status='queued',native_conclusion=None);pf[val['source_evidence_ref']]=C14(sr);pf[sr['raw_api_ref']]=C14(source_snapshot(sr));val.update(status='queued',conclusion='unknown',execution_verified=False,execution_evidence_ref=None,evidence_refs=[val['source_evidence_ref'],sr['raw_api_ref']])
    test('pending native input valid',native_observed_ok(x['pl'],val,C,pf),True,'V168-01')
    test('pending then terminal same clock tick',ledger([(pending,pf),(o,fs)]),True,'V168-01')
    test('terminal cannot lose execution proof',ledger([(o,fs),(pending,pf)]),False,'V168-01')
    other=copy.deepcopy(o);of=copy.deepcopy(fs);val=other['checks'][0];e=typed(of,val['execution_evidence_ref'],'GitCheckExecutionEvidence');newlog='renamed/command.log';of[newlog]=of[e['command_results'][0]['log_ref']];e['command_results'][0]['log_ref']=newlog;of['renamed/execution.json']=C14(e);val['execution_evidence_ref']='renamed/execution.json'
    test('same content different retained refs',ledger([(o,fs),(other,of)]),True,'V168-01')
    # A source state/conclusion update is not itself an input mutation.
    other=copy.deepcopy(o);of=copy.deepcopy(fs);val=other['checks'][0];val['conclusion']='failure';sr=typed(of,val['source_evidence_ref'],'GitCheckSourceEvidence');sr['native_conclusion']='failure';of[val['source_evidence_ref']]=C14(sr);of[sr['raw_api_ref']]=C14(source_snapshot(sr))
    test('source conclusion mutable with same inputs',ledger([(o,fs),(other,of)]),True,'V168-01')
    # P1 V168-02: ordered publication and query; CI can overlap push/postflight.
    def ordered_case():
        z=prepared169();phase=z['ob'];d=phase['destination_observation'];op=typed(z['fs'],d['operation_evidence_ref'],'GitPushOperationEvidence')
        at=lambda f:'2026-10-15T03:00:00.'+str(f)+'Z'
        op.update(push_started_at_utc=at(1),push_completed_at_utc=at(2));d['push_started_at_utc']=at(1);op['postflight'].update(started_at_utc=at(2),completed_at_utc=at(3));cmd=typed(z['fs'],op['command_record_ref'],'GitCommandLifecycle');cmd['result']['completed_at_utc']=at(4)
        z['fs'][op['command_record_ref']]=C14(cmd);z['fs'][d['operation_evidence_ref']]=C14(op)
        for side in ['preflight','postflight']:z['fs'][op[side]['raw_api_ref']]=C14({'kind':'destination_api_snapshot','push_operation_id':op['push_operation_id'],**op[side],'raw_api_ref':None})
        phase['observed_at_utc']=at(5);make_collection_fixture(z['pl'],phase,z['fs'],at(15),at(5));z['fs'][z['ar']['closing_observation_ref']]=C14(phase);z['ar']['created_at_utc']=at(6);z['ar']['files']=manifest_for(z['fs']);z['seal']={**seal_for(z['ar']),'sealed_at_utc':at(7)}
        z['live'],z['lf'],z['ctx']=make_live_fixture(z['at'],z['pl'],z['ob'],z['ar'],z['fs'],start=at(95),end='2026-10-15T03:00:01.2Z')
        z['live']['archive_publication']=publication_fixture(z['at'],z['ar'],z['seal'],at(8),at(9))
        z['ctx']['archive_publication_sha256']=hashlib.sha256(C14(z['live']['archive_publication'])).hexdigest()
        return z
    timed=ordered_case();test('legal overlapping CI and ordered publication',evaluate169(timed),True,'V168-02')
    test('overlap really starts before push complete',instant(typed(timed['fs'],timed['ob']['collection_evidence_ref'],'GitCICollectionEvidence')['started_at_utc'])<instant('2026-10-15T03:00:00.2Z'),True,'V168-02')
    for mode in ['payload_after_C_start','archive_before_C_receipt','seal_before_archive','publication_before_seal','readback_before_publication','query_before_readback','manifest_hash','seal_hash','publication_path','missing_publication','unknown_publication_field']:
        z=copy.deepcopy(timed);pub=z['live']['archive_publication']
        if mode=='payload_after_C_start':
            z['po']['observed_at_utc']='2026-10-15T03:00:00.05Z';z['fs'][z['ar']['payload_observation_ref']]=C14(z['po']);z['ar']['files']=manifest_for(z['fs']);z['seal']['manifest_sha256']=hashlib.sha256(C14(z['ar'])).hexdigest();pub['archive_manifest_sha256']=z['seal']['manifest_sha256'];pub['archive_seal_sha256']=hashlib.sha256(C14(z['seal'])).hexdigest()
        elif mode=='archive_before_C_receipt':
            z['ar']['created_at_utc']='2026-10-15T03:00:00.4Z';z['seal']['manifest_sha256']=hashlib.sha256(C14(z['ar'])).hexdigest();pub['archive_manifest_sha256']=z['seal']['manifest_sha256'];pub['archive_seal_sha256']=hashlib.sha256(C14(z['seal'])).hexdigest()
        elif mode=='seal_before_archive':z['seal']['sealed_at_utc']='2026-10-15T03:00:00.5Z';pub['archive_seal_sha256']=hashlib.sha256(C14(z['seal'])).hexdigest()
        elif mode=='publication_before_seal':pub['published_at_utc']='2026-10-15T03:00:00.65Z'
        elif mode=='readback_before_publication':pub['readback_completed_at_utc']='2026-10-15T03:00:00.75Z'
        elif mode=='query_before_readback':z['live']['started_at_utc']=z['ctx']['started_at_utc']='2026-10-15T03:00:00.85Z'
        elif mode=='manifest_hash':pub['archive_manifest_sha256']='0'*64
        elif mode=='seal_hash':pub['archive_seal_sha256']='0'*64
        elif mode=='publication_path':pub['planned_archive_path']='artifacts/git-delivery/'+U2
        elif mode=='missing_publication':z['live'].pop('archive_publication')
        else:pub['extra']=True
        test('chronology rejects '+mode,evaluate169(z),False,'V168-02')
        if mode not in ['missing_publication','unknown_publication_field']:
            z['ctx']['archive_publication_sha256']=hashlib.sha256(C14(z['live']['archive_publication'])).hexdigest()
            test('chronology still rejects with matching secured publication '+mode,evaluate169(z),False,'V168-02')
    for change in ['missing','wrong','extra']:
        z=prepared169()
        if change=='missing':z['ctx'].pop('archive_publication_sha256')
        elif change=='wrong':z['ctx']['archive_publication_sha256']='0'*64
        else:z['ctx']['unexpected']=True
        test('secured publication context '+change,evaluate169(z),False,'V168-02')
    z=prepared169();test('offline remains historical without live descriptor',effective_done(z['at'],z['pl'],z['ob'],z['ar'],z['fs'],[z['ca']],['S19/T001/Status'],C,offline=True,sel=z['sel'],seal_record=seal_for(z['ar']),published=True),True,'V168-02')
    # P1 V168-03: unrelated current candidates are not fake canary prerequisites.
    z=prepared169();o=live_ob(z);val={**copy.deepcopy(o['checks'][0]),'check_id':'unrelated','context':'unrelated','workflow_path':'.github/workflows/other.yml','job_name':'other-job','event':'pull_request','run_id':'7777','job_id':'8888','status':'queued','conclusion':'unknown','execution_verified':False};put_check_evidence(z['lf'],val,C,'unrelated-event');o['checks'].append(val);save_live(z,o,True)
    test('unrelated current PR does not require PR canary',evaluate169(z),True,'V168-03')
    def dual_event_canary(latest):
        z=prepared169(pr=True);historical_canary169(z,False,False);can=typed(z['fs'],'canary-evidence.json','GitCanaryEvidence');cp=typed(z['fs'],can['check_plan_ref'],'GitCheckPlan');co=typed(z['fs'],can['observation_ref'],'GitDeliveryObservation');req=cp['checks'][0];req['eligible_events']=['push','pull_request']
        for rid,status in [('8998','success')]+([] if latest=='success' else [('8999',latest)]):
            v={**copy.deepcopy(co['checks'][0]),'run_id':rid,'job_id':str(int(rid)+1000),'event':'pull_request','status':'queued' if status=='queued' else 'completed','conclusion':'unknown' if status=='queued' else status,'execution_verified':status=='success'};put_check_evidence(z['fs'],v,P,'dual-canary-'+rid,req=req);co['checks'].append(v)
        co['check_plan_sha256']=hashlib.sha256(C14(cp)).hexdigest();z['fs'][can['check_plan_ref']]=C14(cp);make_collection_fixture(cp,co,z['fs']);z['fs'][can['observation_ref']]=C14(co);retain169(z)
        return z,cp,co
    for state in ['success','queued','failure','neutral','skipped']:
        z,cp,co=dual_event_canary(state)
        test('per-event newest canary '+state,evaluate169(z),state=='success','V168-03')
        test('per-event proof selection '+state,'pull_request' in canary_proven_events(cp,co,z['fs']),state=='success','V168-03')
    z,cp,co=dual_event_canary('success');can=typed(z['fs'],'canary-evidence.json','GitCanaryEvidence');co['observed_at_utc']='2026-10-15T03:00:00.1Z';make_collection_fixture(cp,co,z['fs']);z['fs'][can['observation_ref']]=C14(co);retain169(z)
    test('historical canary cannot be observed after current P receipt',evaluate169(z),False,'V168-03')
    # P2 V168-04: one parser for actual C messages, not count(expected line).
    z=prepared169();closing=typed(z['fs'],z['ar']['closing_commit_ref'],'GitCommit');body=closing['body'];idline='MCE4D-Delivery-ID: '+U;phaseline='MCE4D-Delivery-Phase: closing'
    parsed={'MCE4D-Delivery-ID':U,'MCE4D-Delivery-Phase':'closing'}
    for label,value in [('baseline',body),('CRLF',body.replace('\n','\r\n')),('optional signoff',body+'\nSigned-off-by: Người Kiểm <fixture@example.invalid>'),('trailing newline',body+'\n')]:
        z=prepared169();change_commit169(z,'closing','body',value);test('valid closing parser '+label,parse_delivery_trailers(value)==parsed and evaluate169(z),True,'V168-04')
    bad_bodies=[('duplicate same UUID',body+'\n'+idline),('duplicate same phase',body+'\n'+phaseline),('key casing',body.replace('MCE4D-Delivery-ID','mce4d-delivery-id')),('leading space',body.replace(idline,' '+idline)),('alternate separator',body.replace('MCE4D-Delivery-ID:','MCE4D-Delivery-ID=')),('folded value',body.replace(idline,'MCE4D-Delivery-ID:\n '+U)),('missing blank paragraph',body.replace('\n\nMCE4D','\nMCE4D')),('prose after trailers',body+'\n\nVăn bản ở sau trailer.'),('unknown reserved key',body+'\nMCE4D-Delivery-Other: value'),('patch divider',body.replace('\n\nMCE4D','\n---\n\nMCE4D')),('lone CR',body+'\r'),('NUL',body+'\x00')]
    for label,value in bad_bodies:
        z=prepared169();change_commit169(z,'closing','body',value);test('closing rejects '+label,parse_delivery_trailers(value) is None and not evaluate169(z),True,'V168-04')
    z=prepared169();change_commit169(z,'payload','body',z['at']['ordered_commits'][0]['body']+'\n\nmce4d-delivery-id: '+U);test('payload cannot carry reserved case alias',evaluate169(z),False,'V168-04')
    # P2 V168-05: actual subject/body, all official strings and trailer forms.
    for token in ['[skip ci]','[ci skip]','[no ci]','[skip actions]','[actions skip]']:
        for phase in ['payload','closing']:
            for field in ['subject','body']:
                z=prepared169();rec=z['at']['ordered_commits'][0] if phase=='payload' else typed(z['fs'],z['ar']['closing_commit_ref'],'GitCommit');value=rec[field]+' '+token if field=='subject' else rec[field].replace('Mục đích:','Mục đích: '+token,1);change_commit169(z,phase,field,value);test('skip reject '+phase+' '+field+' '+token,evaluate169(z),False,'V168-05')
    for line in ['skip-checks:true','skip-checks: true','SKIP-CHECKS: TRUE']:
        for phase in ['payload','closing']:
            z=prepared169();rec=z['at']['ordered_commits'][0] if phase=='payload' else typed(z['fs'],z['ar']['closing_commit_ref'],'GitCommit');change_commit169(z,phase,'body',rec['body']+'\n\n\n'+line);test('skip trailer reject '+phase+line,evaluate169(z),False,'V168-05')
    for phase in ['payload','closing']:
        z=prepared169();rec=z['at']['ordered_commits'][0] if phase=='payload' else typed(z['fs'],z['ar']['closing_commit_ref'],'GitCommit');change_commit169(z,phase,'body',rec['body']+'\nskip-checks: false');test('false skip flag is not directive '+phase,evaluate169(z),True,'V168-05')
    test('uppercase quoted skip still forbidden',has_skip_directive('Kiểm tra `[SKIP CI]`','Mục đích: Chỉ là fixture.'),True,'V168-05')
    test('normal Vietnamese CI prose allowed',has_skip_directive('Kiểm tra CI đầy đủ','Mục đích: Đọc kết quả CI và tiếp tục.'),False,'V168-05')
    for value in ['skip-checks:\n true','skip-checks= true','skip-checks: unknown','skip-checks: false\n true']:
        z=prepared169();change_commit169(z,'payload','body',z['at']['ordered_commits'][0]['body']+'\n\n'+value);test('unsupported skip intent '+value,evaluate169(z),False,'V168-05')
    test('five closures and source link synchronized',all(v in s for v in ['EXECUTION-PIN-01','DELIVERY-TIME-01','CANARY-EVENT-01','TRAILER-PARSE-01','NO-SKIP-01','A050','D054','D055','D056','D057','D058','REF75']) and fm['latest_review_findings']==5 and resume['latest_review_closure']=='S52_CLOSE_13',True,'sync')
    result={'spec_version':'1.6.9','prior_review_probes':review,'prior_incorrect_acceptances':9,'current_incorrect_acceptances':0,'groups_closed':5,'new_assertions':len(checks)-before_count,'cases':cases,'scope':'Synthetic document/reference only; no product or actual Git/GitHub/CI/publication enforcement.'}
    (run/'review-1.6.9-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')

verify_review169()
