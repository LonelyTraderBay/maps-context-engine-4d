"""Pure delivery/resume contract checks; no persisted tracker or I/O executor."""

DELIVERY_STAGES = tuple(blocks['MCE4D_DELIVERY_PROTOCOL_V1']['delivery_stages'])
RESUME_NEXT_STAGE = blocks['MCE4D_DELIVERY_PROTOCOL_V1']['resume_next_stage']


def full_delivery_order_ok(events):
    return isinstance(events, (list, tuple)) and tuple(events) == DELIVERY_STAGES


def delivery_resume_stage(boundary, pending, actual):
    """Choose only after separately secured current facts match the pending ID.

    A returned push-reconciliation action means inspect/settle the exact owned
    command, never blind re-execution. Facts here are supplied synthetic inputs;
    actual checkpoint, Git, process and source readers remain future adapters.
    """
    try:
        keys = {'boundary', 'delivery_id', 'task_revision', 'effective_done'}
        if boundary == 'suspended_external_blocker':
            keys |= {'suspension_ref', 'operation_settled'}
        if (not isinstance(actual, dict) or set(actual) != keys
                or type(actual['effective_done']) is not bool
                or actual['boundary'] != boundary or boundary not in RESUME_NEXT_STAGE):
            return None
        if boundary == 'no_pending':
            return (RESUME_NEXT_STAGE[boundary]
                    if pending is None and actual['delivery_id'] is None
                    and actual['task_revision'] is None and not actual['effective_done']
                    else None)
        if not isinstance(pending, dict) or set(pending) != {'delivery_id', 'task_revision'}:
            return None
        identity = pending['delivery_id']
        revision = pending['task_revision']
        if (not isinstance(identity, str)
                or re.fullmatch(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', identity) is None
                or type(revision) is not int or revision < 1
                or not isinstance(actual['delivery_id'], str)
                or type(actual['task_revision']) is not int
                or actual['delivery_id'] != identity or actual['task_revision'] != revision
                or actual['effective_done'] != (boundary == 'after_effective_done')):
            return None
        if boundary == 'suspended_external_blocker':
            if (actual['operation_settled'] is not True
                    or not isinstance(actual['suspension_ref'], str)
                    or not safe_rel(actual['suspension_ref'])):
                return None
        return RESUME_NEXT_STAGE[boundary]
    except (ValueError, KeyError, TypeError, OverflowError):
        return None
