"""Bounded subprocess regressions for mandatory hash checks and source binding.

Executed in verify_spec's globals. Fixtures live only in a newly owned directory
under the extracted proof. No child runs the product, Git or a network command.
"""
import os
import subprocess
import tempfile
import ast


def verify_harness1613():
    start=len(checks)
    cases=[]
    owned=Path(tempfile.mkdtemp(prefix='harness-reference-',dir=run)).resolve()
    if owned.parent != run.resolve():
        raise ValueError('unexpected harness fixture owner')
    fixture=owned/'flat'
    fixture.mkdir()
    source_names=sorted(path.name for path in run.glob('*.py'))
    for name in source_names:
        (fixture/name).write_bytes((run/name).read_bytes())
    (fixture/'final-spec.bin').write_bytes(b'owned synthetic SPEC fixture\r\n')
    (fixture/'README.txt').write_bytes(b'owned synthetic proof README\r\n')
    (fixture/'verify_spec.py').write_text("raise RuntimeError('AUDIT_ROOT_SOURCE_SELECTED')\n",encoding='utf-8')
    members=source_names+['README.txt','final-spec.bin']

    def manifest():
        value={'spec_version':'1.6.13','spec_sha256':hashlib.sha256((fixture/'final-spec.bin').read_bytes()).hexdigest(),
               'files':{name:{'bytes':len((fixture/name).read_bytes()),'sha256':hashlib.sha256((fixture/name).read_bytes()).hexdigest()} for name in members}}
        (fixture/'manifest.json').write_text(json.dumps(value,sort_keys=True),encoding='utf-8')

    def invoke(script,flags=(),optimize=None):
        env=os.environ.copy()
        env.pop('PYTHONOPTIMIZE',None)
        if optimize is not None:
            env['PYTHONOPTIMIZE']=optimize
        argv=[sys.executable,'-B',*flags,script]
        argv+=['.'] if script=='verify_manifest.py' else ['final-spec.bin',str(source_root)]
        return subprocess.run(argv,cwd=fixture,env=env,capture_output=True,text=True,encoding='utf-8',timeout=30)

    def test(name,condition):
        ck('V1612 harness '+name,condition)
        cases.append({'name':name,'passed':bool(condition)})

    modes=[('default',(),None),('flag-O',('-O',),None),('flag-OO',('-OO',),None),('env-1',(),'1'),('env-2',(),'2')]
    tree=ast.parse((run/'independent_audit.py').read_text(encoding='utf-8'))
    bound=next(ast.literal_eval(node.value) for node in tree.body if isinstance(node,ast.Assign) and any(isinstance(target,ast.Name) and target.id=='PROOF_SOURCE_MEMBERS' for target in node.targets))
    test('every packaged Python source is required before audit',len(bound)==len(set(bound)) and set(bound)==set(source_names))
    manifest()
    for label,flags,optimize in modes:
        result=invoke('verify_manifest.py',flags,optimize)
        try:
            value=json.loads(result.stdout)
        except (ValueError,TypeError):
            value={}
        test('intact manifest '+label,result.returncode==0 and value.get('result')=='PASS' and value.get('members_verified')==len(members))

    original=(fixture/'README.txt').read_bytes()
    (fixture/'README.txt').write_bytes(original+b'tampered')
    for label,flags,optimize in modes:
        result=invoke('verify_manifest.py',flags,optimize)
        test('tampered member rejects '+label,result.returncode!=0 and '"result": "PASS"' not in result.stdout and 'README.txt' in result.stderr)
    (fixture/'README.txt').write_bytes(original)

    (fixture/'README.txt').write_bytes(b'X'+original[1:])
    for label,flags,optimize in modes:
        result=invoke('verify_manifest.py',flags,optimize)
        test('same-size hash mismatch rejects '+label,result.returncode!=0 and 'member integrity mismatch: README.txt' in result.stderr)
    (fixture/'README.txt').write_bytes(original)

    value=json.loads((fixture/'manifest.json').read_text(encoding='utf-8'))
    value['files']['absent.txt']=value['files']['README.txt']
    (fixture/'manifest.json').write_text(json.dumps(value),encoding='utf-8')
    for label,flags,optimize in modes:
        result=invoke('verify_manifest.py',flags,optimize)
        test('missing member rejects '+label,result.returncode!=0 and 'missing or linked member: absent.txt' in result.stderr)

    # Hash-consistent manifest metadata must still bind final-spec.bin itself.
    manifest()
    value=json.loads((fixture/'manifest.json').read_text(encoding='utf-8'))
    value['spec_sha256']='0'*64
    (fixture/'manifest.json').write_text(json.dumps(value),encoding='utf-8')
    for label,flags,optimize in modes:
        result=invoke('verify_manifest.py',flags,optimize)
        test('wrong SPEC hash rejects '+label,result.returncode!=0 and 'SPEC integrity mismatch' in result.stderr)

    manifest()
    child=fixture/'proof'
    child.mkdir()
    (child/'verify_spec.py').write_text("raise RuntimeError('AUDIT_UNLISTED_SOURCE_SELECTED')\n",encoding='utf-8')
    root_hash=hashlib.sha256((fixture/'verify_spec.py').read_bytes()).hexdigest()
    for label,flags,optimize in modes:
        result=invoke('verify_manifest.py',flags,optimize)
        test('unlisted child does not alter declared manifest '+label,result.returncode==0)
        result=invoke('independent_audit.py',flags,optimize)
        test('only manifest-bound root selected '+label,result.returncode!=0 and 'AUDIT_ROOT_SOURCE_SELECTED' in result.stderr and 'AUDIT_UNLISTED_SOURCE_SELECTED' not in result.stderr)
    test('root source bytes preserved',hashlib.sha256((fixture/'verify_spec.py').read_bytes()).hexdigest()==root_hash)

    for omitted in ['verify_spec.py','delivery_core.py']:
        manifest()
        value=json.loads((fixture/'manifest.json').read_text(encoding='utf-8'))
        value['files'].pop(omitted)
        (fixture/'manifest.json').write_text(json.dumps(value),encoding='utf-8')
        for label,flags,optimize in modes:
            result=invoke('independent_audit.py',flags,optimize)
            test('unlisted required source rejects '+omitted+' '+label,result.returncode!=0 and 'unlisted required source members: '+omitted in result.stderr and 'AUDIT_ROOT_SOURCE_SELECTED' not in result.stderr)
    manifest()

    # A changed executable root member must fail preflight before runpy.
    (fixture/'verify_spec.py').write_text("raise RuntimeError('AUDIT_CHANGED_ROOT_EXECUTED')\n",encoding='utf-8')
    for label,flags,optimize in modes:
        result=invoke('independent_audit.py',flags,optimize)
        test('changed root rejects before execution '+label,result.returncode!=0 and 'member integrity mismatch: verify_spec.py' in result.stderr and 'AUDIT_CHANGED_ROOT_EXECUTED' not in result.stderr)

    original_five={
        'untampered default manifest control':'intact manifest default',
        'tampered default manifest rejects':'tampered member rejects default',
        'tampered manifest with PYTHONOPTIMIZE rejects':'tampered member rejects env-1',
        'manifest still passes with unlisted proof child':'unlisted child does not alter declared manifest default',
        'entrypoint must execute packaged root source':'only manifest-bound root selected default',
    }
    test('all five prior harness expectations retained',all(any(case['name']==name and case['passed'] for case in cases) for name in original_five.values()))
    result={'spec_version':'1.6.13','groups':['V1612-04','V1612-05'],'checks':len(checks)-start,'cases':cases,
            'prior_review_probes':5,'prior_review_probe_mapping':original_five,'prior_mismatches_corrected':2,
            'scope':'Owned small synthetic flat-package subprocesses; hash integrity/source selection only, no product or authenticity/signature claim.'}
    (run/'harness-1.6.13-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')


verify_harness1613()
