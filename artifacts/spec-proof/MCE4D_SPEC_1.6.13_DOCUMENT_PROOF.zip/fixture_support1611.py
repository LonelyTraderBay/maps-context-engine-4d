"""Explicit synthetic collector construction; never invoked by evaluator."""

_make_live1610_fixture = make_live_fixture


def make_live_fixture(at, pl, ob, ar, fs, current_pr=None, identity=None, start=None, end=None):
    verification, files, context = _make_live1610_fixture(at, pl, ob, ar, fs, current_pr, identity, start, end)
    if current_pr is not None:
        # A synthetic query acquires its PR state at its own read time, not at
        # the archive's acquisition time. Missing supplied PR state stays missing.
        observation = typed(files, verification['closing_observation_ref'], 'GitDeliveryObservation')
        binding = typed(files, observation['pull_request_binding_ref'], 'GitPullRequestBinding')
        binding['observed_at_utc'] = verification['completed_at_utc']
        files[observation['pull_request_binding_ref']] = C14(binding)
        snapshot = typed(files, verification['current_pr_ref'], 'GitPullRequestBinding')
        snapshot['observed_at_utc'] = verification['completed_at_utc']
        files[verification['current_pr_ref']] = C14(snapshot)
        for item in [binding, snapshot]:
            files[item['api_evidence_ref']] = C14({'kind':'pull_request_api_snapshot', **{k:v for k,v in item.items() if k not in ['format_version','api_evidence_ref','kind']}})
        verification['files'] = manifest_for(files)
    return verification, files, context
