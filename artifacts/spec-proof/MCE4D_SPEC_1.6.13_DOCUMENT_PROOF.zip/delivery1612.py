"""v1.6.12 shared pure source, identity and UTC-equality reference guards.

These helpers only inspect retained synthetic inputs. They neither collect
Git/API evidence nor construct, repair, or mutate fixtures during evaluation.
"""


def same_instant(left, right):
    """Compare RFC3339 instants without changing either retained raw value."""
    try:
        return instant(left) == instant(right)
    except (ValueError, KeyError, TypeError, OverflowError):
        return False


def exact_json_equal(left, right):
    """Type-preserving JSON parity: JSON booleans never equal JSON numbers."""
    try:
        return C14(left) == C14(right)
    except (ValueError, KeyError, TypeError, OverflowError):
        return False


def pr_source_ok(binding, fs):
    """Resolve this PR snapshot's own raw source and require exact projection.

    Every retained phase binding and the distinct fresh current-PR snapshot
    must pass independently; equality of their PR heads alone is insufficient.
    """
    try:
        if not gv('GitPullRequestBinding', binding):
            return False
        instant(binding['observed_at_utc'])
        expected = {key: value for key, value in binding.items()
                    if key not in ['format_version', 'api_evidence_ref', 'kind']}
        return exact_json_equal(load_member(fs, binding['api_evidence_ref']), {
            'kind': 'pull_request_api_snapshot', **expected})
    except (ValueError, KeyError, TypeError, OverflowError):
        return False


def phase_command_identity_ok(observation, command):
    """Bind a P/C receipt to its own delivery, including historical canaries.

    A historical canary keeps its historical UUID. This guard does not invent
    an assignment/task/revision identity absent from the retained observation.
    """
    try:
        return (gv('GitDeliveryObservation', observation)
                and observation['phase'] in ['payload', 'closing']
                and gv('GitCommandLifecycle', command)
                and command['delivery_id'] == observation['delivery_id'])
    except (ValueError, KeyError, TypeError, OverflowError):
        return False
