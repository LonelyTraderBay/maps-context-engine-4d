"""v1.6.8 pure document governance oracle; no Git/network/product implementation."""
import unicodedata


def lifecycle_ok(command):
    if not gv('GitCommandLifecycle',command):return False
    state=command['command_state'];c=command['contract'];r=command['result']
    if state!=r['final_status']:return False
    if c['storage_mode']=='budgeted' and (not c['volumes'] or not c['budget_refs']):return False
    if state=='NOT_STARTED':return r['started_at_utc'] is None and r['completed_at_utc'] is None and r['command_exit_status'] is None and r['termination_reason']=='not_started'
    if r['started_at_utc'] is not None and instant(r['started_at_utc'])>instant(c['deadline_at_utc']):return False
    if r['completed_at_utc'] is not None and (r['started_at_utc'] is None or not instant(r['started_at_utc'])<=instant(r['completed_at_utc'])):return False
    if state in ['RUNNING','SETTLING'] and (r['started_at_utc'] is None or r['completed_at_utc'] is not None):return False
    if state=='RUNNING' and r['command_exit_status'] is not None:return False
    if state=='SUCCEEDED':return r['started_at_utc'] is not None and r['completed_at_utc'] is not None and instant(r['completed_at_utc'])<=instant(c['deadline_at_utc']) and r['command_exit_status']==0 and r['termination_reason']=='completed' and r['cleanup_status'] in ['NOT_REQUIRED','SUCCEEDED']
    if state=='FAILED':return r['started_at_utc'] is not None and r['completed_at_utc'] is not None and (r['command_exit_status'] is not None and r['command_exit_status']!=0 or r['cleanup_status']=='FAILED' or r['termination_reason'] in ['cancelled','timeout'])
    if state=='UNKNOWN':return r['command_exit_status'] is None and r['termination_reason']=='unknown'
    return True


def push_lifecycle_ok(pl,d,subject,op,command):
    if not lifecycle_ok(command) or command['command_state']!='SUCCEEDED':return False
    if any(command[k]!=op[k] for k in ['lifecycle_id','retry_index']) or command['operation_id']!=op['push_operation_id']:return False
    c=command['contract'];r=command['result'];argv=c['argv']
    if not same_instant(c['deadline_at_utc'],op['deadline_at_utc']) or not same_instant(r['started_at_utc'],op['lifecycle_started_at_utc']) or instant(r['completed_at_utc'])<instant(op['postflight']['completed_at_utc']):return False
    if Path(c['executable']).name.lower() not in ['git','git.exe'] or len(argv)<4 or Path(argv[0]).name.lower() not in ['git','git.exe'] or argv[1]!='push':return False
    tail=list(argv[2:])
    while tail and tail[0] in ['--porcelain','--atomic']:tail.pop(0)
    if len(tail)!=2 or tail[0]!=pl['repository']['remote_name'] or tail[1] not in [pl['repository']['ref'],subject+':'+pl['repository']['ref']]:return False
    return c['side_effect_class']=='external_service' and bool(c['network_scope'])


_plan167=plan_ok

def plan_ok(pl):
    if not _plan167(pl):return False
    required=any(x['checkout_binding']=='pr_merge' for x in pl['checks'])
    flow=pl['pull_request_flow']
    return (flow is None) if not required else flow is not None and flow['head_repository_id']==pl['repository']['repository_id'] and flow['head_ref']==pl['repository']['ref'] and flow['head_ref']!=flow['base_ref']


_pr167=pr_ok

def pr_ok(pl,o,parents,fs,current,offline):
    if any(x['checkout_binding']=='pr_merge' for x in pl['checks']):
        binding=typed(fs,o['pull_request_binding_ref'],'GitPullRequestBinding');flow=pl['pull_request_flow']
        if flow is None or any(binding[k]!=flow[k] for k in ['head_repository_id','head_ref','base_ref']):return False
    return _pr167(pl,o,parents,fs,current,offline)


def collection_ok(pl,o,collection,fs,start,end):
    if not gv('GitCICollectionEvidence',collection) or any(collection[k]!=pl['repository'][k] for k in ['host','repository_id']) or collection['subject_sha']!=o['subject_sha'] or collection['check_plan_sha256']!=hashlib.sha256(C14(pl)).hexdigest():return False
    if not instant(start)<=instant(collection['started_at_utc'])<=instant(collection['completed_at_utc'])<=instant(o['observed_at_utc'])<=instant(end):return False
    sources={v['source_evidence_ref']:typed(fs,v['source_evidence_ref'],'GitCheckSourceEvidence') for v in o['checks']}
    if len(sources)!=len(o['checks']):return False
    shas={o['subject_sha']}
    if o['pull_request_binding_ref'] is not None:shas.add(typed(fs,o['pull_request_binding_ref'],'GitPullRequestBinding')['tested_merge_sha'])
    base={(e,sha,None,None) for sha in shas for e in ['check_runs','commit_statuses']}
    actions=any(req['workflow_path'] is not None for req in pl['checks'])
    if actions:base.update(('workflow_runs',sha,None,None) for sha in shas)
    grouped={}
    for p in collection['pages']:
        selector=(p['workflow_run_id'],p['workflow_run_attempt'])
        if p['endpoint']=='workflow_run_attempt':
            if None in selector or p['requested_sha'] not in shas:return False
        elif selector!=(None,None):return False
        grouped.setdefault((p['endpoint'],p['requested_sha'],*selector),[]).append(p)
    if not base<=set(grouped) or any(k not in base and k[0]!='workflow_run_attempt' for k in grouped):return False
    query_ids=set();latest={};history={}
    row_keys={'run_id','run_attempt','head_sha','workflow_path','event','created_at','status','conclusion','job_source_refs'}
    for key,pages in grouped.items():
        endpoint,sha,rid,attempt=key;pages=sorted(pages,key=lambda x:x['page_number']);qids={p['query_id'] for p in pages}
        if len(qids)!=1 or qids&query_ids:return False
        query_ids |=qids;items=[]
        if endpoint=='workflow_run_attempt' and len(pages)!=1:return False
        for number,p in enumerate(pages,1):
            nxt=number+1 if number<len(pages) else None
            if p['page_number']!=number or p['next_page_number']!=nxt:return False
            raw=object_member(fs,p['raw_page_ref'])
            expected={'kind':'ci_api_page',**p,'raw_page_ref':None,'state_filter':'all','observed_at_utc':raw.get('observed_at_utc'),'items':raw.get('items')};expected.pop('raw_page_ref')
            if not exact_json_equal(raw,expected) or not isinstance(raw['items'],list) or not all(isinstance(item,dict) for item in raw['items']) or not instant(collection['started_at_utc'])<=instant(raw['observed_at_utc'])<=instant(collection['completed_at_utc']):return False
            for item in raw['items']:
                created=item['created_at'] if endpoint in ['workflow_runs','workflow_run_attempt'] else item['workflow_run']['created_at'] if item['workflow_run'] is not None else item['record']['created_at']
                if instant(created)>instant(raw['observed_at_utc']):return False
            items.extend(raw['items'])
        if endpoint in ['check_runs','commit_statuses']:
            expected_items=[source_snapshot(x) for x in sources.values() if x['reported_head_sha']==sha and (x['source_kind']=='commit_status')==(endpoint=='commit_statuses')]
            if Counter(C14(x) for x in items)!=Counter(C14(x) for x in expected_items):return False
            identities=[(x['source_kind'],x['record']['id']) for x in items]
            if len(identities)!=len(set(identities)):return False
            continue
        if endpoint=='workflow_run_attempt' and (len(items)!=1 or (items[0]['run_id'],items[0]['run_attempt'])!=(rid,attempt)):return False
        for row in items:
            if set(row)!=row_keys or not re.fullmatch('[1-9][0-9]{0,19}',str(row['run_id'])) or type(row['run_attempt']) is not int or row['run_attempt']<1 or row['head_sha']!=sha or not isinstance(row['job_source_refs'],list):return False
            if row['status'] not in ['queued','in_progress','waiting','completed'] or (row['status']=='completed' and row['conclusion'] not in ['success','failure','cancelled','timed_out','action_required','skipped','neutral']) or (row['status']!='completed' and row['conclusion'] is not None):return False
            if endpoint=='workflow_runs':
                if row['run_id'] in latest:return False
                latest[row['run_id']]=row
            else:
                hkey=(row['run_id'],row['run_attempt'])
                if hkey in history:return False
                history[hkey]=row
    needed_history=set()
    for ref,source in sources.items():
        if source['source_kind']!='actions_check_run' or source['workflow_head_sha'] not in shas:continue
        current=latest.get(source['run_id'])
        if current is None or source['attempt']>current['run_attempt']:return False
        if source['attempt']<current['run_attempt']:needed_history.add((source['run_id'],source['attempt']))
    if set(history)!=needed_history:return False
    rows=list(latest.values())+list(history.values())
    for hkey,row in history.items():
        current=latest.get(row['run_id'])
        if current is None or row['run_attempt']>=current['run_attempt'] or any(row[k]!=current[k] for k in ['head_sha','workflow_path','event']) or instant(row['created_at'])!=instant(current['created_at']):return False
    all_refs=[]
    for row in rows:
        if len(row['job_source_refs'])!=len(set(row['job_source_refs'])):return False
        for ref in row['job_source_refs']:
            source=sources.get(ref)
            if source is None or source['source_kind']!='actions_check_run' or (source['run_id'],source['attempt'])!=(row['run_id'],row['run_attempt']) or source['workflow_head_sha']!=row['head_sha'] or source['workflow_path']!=row['workflow_path'] or source['event']!=row['event'] or instant(source['created_at_utc'])!=instant(row['created_at']):return False
            all_refs.append(ref)
    action_refs={ref for ref,x in sources.items() if x['source_kind']=='actions_check_run' and x['workflow_head_sha'] in shas}
    if len(all_refs)!=len(set(all_refs)) or set(all_refs)!=action_refs:return False
    for req in pl['checks']:
        if req['workflow_path'] is None:continue
        relevant=[row for row in latest.values() if row['workflow_path']==req['workflow_path'] and row['event'] in req['eligible_events']]
        if not relevant:return False
        current=max(relevant,key=lambda x:(instant(x['created_at']),int(x['run_id'])))
        values=[v for v in o['checks'] if v['check_id']==req['id'] and v['run_id']==current['run_id']]
        if not values:return False
        selected=max(values,key=lambda x:x['attempt'])
        if selected['attempt']<current['run_attempt'] and current['status']!='completed':return False
        if not current['job_source_refs']:return False
    return True


def vietnamese_marks(value):
    return any(c in '\u0300\u0301\u0303\u0309\u0323' for c in unicodedata.normalize('NFD',value)) or any(c in value for c in 'đĐ')


def commit_ok(record,at,parents,fs,phase):
    if not gv('GitCommit',record):return False
    scope=typed(fs,record['scope_ref'],'GitCommitScopeEvidence');raw=object_member(fs,record['git_evidence_ref'])
    expected={'kind':'git_commit_snapshot','sha':record['sha'],'parents':parents.get(record['sha']),'subject':record['subject'],'body':record['body'],'changed_paths':scope['changed_paths']}
    if not exact_json_equal(raw,expected) or expected['parents'] is None or scope['phase']!=phase or not all(safe_rel(x) for x in scope['changed_paths']):return False
    subject,body=record['subject'],record['body']
    match=re.fullmatch(r'(feat|fix|test|docs|refactor|build|ci|chore|perf|revert)(?:\(([A-Za-z0-9_.-]+)\))?(!)?: \[(P[0-3])\]\[(T\d{3}(?:,T\d{3})*)\] (.+)',subject)
    if not match or any(unicodedata.normalize('NFC',v)!=v or not vietnamese_marks(v) for v in [subject,body]):return False
    task_ids=match[5].split(',')
    if len(task_ids)!=len(set(task_ids)) or task_ids!=scope['task_ids'] or match[4]!=scope['priority']:return False
    current_required=phase=='closing' or at['payload_mode']=='changes'
    if current_required and at['task_id'] not in task_ids:return False
    if current_required and scope['priority']!=at['priority']:
        reason=object_member(fs,scope['priority_reason_ref'])
        if not reason_ok(reason,'priority_rationale',task_id=at['task_id'],priority=scope['priority']):return False
    if len(task_ids)>1:
        shared=object_member(fs,scope['shared_invariant_ref'])
        if not reason_ok(shared,'shared_invariant',task_ids=task_ids):return False
    for header in ['Mục đích:','Thay đổi:','Kiểm tra:']:
        if not re.search(re.escape(header)+r'[^\S\n]*\S[^\n]*',body):return False
    if match[3]:
        decision=object_member(fs,scope['breaking_decision_ref'])
        if 'BREAKING CHANGE:' not in body or not reason_ok(decision,'breaking_decision'):return False
    elif scope['breaking_decision_ref'] is not None or 'BREAKING CHANGE:' in body:return False
    if phase=='closing':
        if scope['changed_paths']!=['Maps-Context-Engine-4D_SPEC.md']:return False
        return match[1]=='docs' and match[2]=='progress' and task_ids==[at['task_id']] and body.splitlines().count('MCE4D-Delivery-ID: '+at['delivery_id'])==1 and body.splitlines().count('MCE4D-Delivery-Phase: closing')==1
    return 'MCE4D-Delivery-ID:' not in body and 'MCE4D-Delivery-Phase:' not in body


_archive167=archive_done

def archive_done(at,pl,ob,ar,fs,candidates,changes,live_remote,offline=False,sel=None,seal_record=None,published=False,current_pr=None):
    try:
        if not _archive167(at,pl,ob,ar,fs,candidates,changes,live_remote,offline,sel,seal_record,published,current_pr):return False
        if at['payload_mode']=='verified_noop':
            reason=object_member(fs,at['noop_reason_ref'])
            identity={k:at[k] for k in ['assignment_ref','task_id','delivery_id','verified_payload_sha']}
            if set(reason)!={'kind','reason',*identity} or not reason_ok(reason,'verified_noop_reason',**identity):return False
        elif at['noop_reason_ref'] is not None:return False
        parents=object_member(fs,ar['git_evidence_ref'])
        if not all(commit_ok(v,at,parents,fs,'payload') for v in at['ordered_commits']):return False
        closing=typed(fs,ar['closing_commit_ref'],'GitCommit')
        if closing['sha']!=ar['closing_sha'] or not commit_ok(closing,at,parents,fs,'closing'):return False
        for phase in ['payload','closing']:
            observation=typed(fs,ar[phase+'_observation_ref'],'GitDeliveryObservation');op=typed(fs,observation['destination_observation']['operation_evidence_ref'],'GitPushOperationEvidence');command=typed(fs,op['command_record_ref'],'GitCommandLifecycle')
            if any(command[k]!=at[k] for k in ['assignment_ref','task_id','task_revision','delivery_id']):return False
        return True
    except (ValueError,KeyError,TypeError,OverflowError):return False
