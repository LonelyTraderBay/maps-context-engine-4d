"""Verify immutable flat proof members. Integrity check, not signature/authenticity."""
from pathlib import Path
import hashlib,json,sys
def strict_object(pairs):
    result={}
    for key,value in pairs:
        if key in result:raise ValueError('duplicate manifest key')
        result[key]=value
    return result
def verify_manifest(root, required_members=()):
    """Mandatory validation must run even with -O/-OO or PYTHONOPTIMIZE."""
    root=Path(root).resolve()
    m=json.loads((root/'manifest.json').read_bytes(),object_pairs_hook=strict_object)
    if not isinstance(m,dict) or not isinstance(m.get('files'),dict) or not m['files']:
        raise ValueError('invalid manifest object')
    missing=set(required_members)-set(m['files'])
    if missing:
        raise ValueError('unlisted required source members: '+', '.join(sorted(missing)))
    verified=0
    for name,entry in m['files'].items():
        if Path(name).name!=name or '/' in name or '\\' in name or ':' in name or name in ['.', '..', 'manifest.json']:
            raise ValueError('unsafe member')
        if not isinstance(entry,dict) or type(entry.get('bytes')) is not int or entry['bytes']<0 or not isinstance(entry.get('sha256'),str):
            raise ValueError('invalid member entry: '+name)
        path=root/name
        if not path.is_file() or path.is_symlink():
            raise ValueError('missing or linked member: '+name)
        raw=path.read_bytes()
        if len(raw)!=entry['bytes'] or hashlib.sha256(raw).hexdigest()!=entry['sha256']:
            raise ValueError('member integrity mismatch: '+name)
        verified+=1
    if 'final-spec.bin' not in m['files'] or hashlib.sha256((root/'final-spec.bin').read_bytes()).hexdigest()!=m.get('spec_sha256'):
        raise ValueError('SPEC integrity mismatch')
    return {'spec_version':m['spec_version'],'members_verified':verified,'result':'PASS'}

if __name__=='__main__':
    root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent
    print(json.dumps(verify_manifest(root)))
