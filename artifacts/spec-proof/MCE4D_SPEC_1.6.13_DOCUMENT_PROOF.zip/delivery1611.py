"""v1.6.11 pure temporal reference guards. No actual Git/API/process I/O."""


def phase_receipt_time_ok(observation, fs):
    """Receipt is only complete after this phase's push and common command."""
    try:
        if not gv('GitDeliveryObservation', observation) or observation['phase'] not in ['payload', 'closing']:
            return False
        op = typed(fs, observation['destination_observation']['operation_evidence_ref'], 'GitPushOperationEvidence')
        command = typed(fs, op['command_record_ref'], 'GitCommandLifecycle')
        if not phase_command_identity_ok(observation, command):
            return False
        return instant(observation['observed_at_utc']) >= max(instant(op['postflight']['completed_at_utc']), instant(command['result']['completed_at_utc']))
    except (ValueError, KeyError, TypeError, OverflowError):
        return False


_pr1610 = pr_ok


def pr_ok(pl, observation, parents, fs, current, offline):
    if not _pr1610(pl, observation, parents, fs, current, offline):
        return False
    if observation['pull_request_binding_ref'] is not None:
        binding = typed(fs, observation['pull_request_binding_ref'], 'GitPullRequestBinding')
        return instant(binding['observed_at_utc']) <= instant(observation['observed_at_utc'])
    return True


_live1610 = live_verification_ok


def live_verification_ok(at, pl, co, po, verification, fs, context, live_remote, archived_fs):
    if not _live1610(at, pl, co, po, verification, fs, context, live_remote, archived_fs):
        return False
    observation = typed(fs, verification['closing_observation_ref'], 'GitDeliveryObservation')
    if observation['pull_request_binding_ref'] is not None:
        binding = typed(fs, observation['pull_request_binding_ref'], 'GitPullRequestBinding')
        return instant(verification['started_at_utc']) <= instant(binding['observed_at_utc']) <= instant(observation['observed_at_utc'])
    return True


def selection_claim_ok(selection):
    try:
        if not gv('GitTaskDeliverySelection', selection):
            return False
        allocated = selection['allocated_at_utc']
        updated = instant(selection['updated_at_utc'])
        if selection['active_delivery_id'] is None:
            return allocated is None
        return allocated is not None and instant(allocated) <= updated
    except (ValueError, KeyError, TypeError, OverflowError):
        return False


_selection1610 = selection_ok


def selection_ok(sel, at, fs):
    try:
        if not _selection1610(sel, at, fs):
            return False
        current = sel
        while True:
            if not selection_claim_ok(current):
                return False
            ref = current['previous_selection_ref']
            if ref is None:
                return True
            previous = typed(fs, ref, 'GitTaskDeliverySelection')
            if instant(previous['updated_at_utc']) > instant(current['allocated_at_utc']):
                return False
            current = previous
    except (ValueError, KeyError, TypeError, OverflowError):
        return False


def selection_archive_time_ok(sel, ar, fs):
    try:
        receipt = typed(fs, ar['payload_observation_ref'], 'GitDeliveryObservation')
        operation = typed(fs, receipt['destination_observation']['operation_evidence_ref'], 'GitPushOperationEvidence')
        if instant(sel['allocated_at_utc']) > instant(operation['lifecycle_started_at_utc']):
            return False
        current = sel
        seen = set()
        while True:
            identity = (current['task_revision'], current['active_delivery_id'])
            if identity in seen:
                return False
            seen.add(identity)
            if instant(current['updated_at_utc']) > instant(ar['created_at_utc']):
                return False
            ref = current['previous_selection_ref']
            if ref is None:
                return True
            current = typed(fs, ref, 'GitTaskDeliverySelection')
    except (ValueError, KeyError, TypeError, OverflowError):
        return False


_archive1610 = archive_done


def archive_done(at, pl, ob, ar, fs, candidates, changes, live_remote, offline=False, sel=None, seal_record=None, published=False, current_pr=None):
    return _archive1610(at, pl, ob, ar, fs, candidates, changes, live_remote, offline, sel, seal_record, published, current_pr) and selection_archive_time_ok(sel, ar, fs)


_checkpoint1610 = checkpoint_ok


def checkpoint_ok(value, selector, actual, fs):
    try:
        if selector is not None and not selection_claim_ok(selector):
            return False
        return _checkpoint1610(value, selector, actual, fs)
    except (ValueError, KeyError, TypeError, OverflowError):
        return False


DELIVERY_CLOSE_STAGES = tuple(blocks['MCE4D_DELIVERY_PROTOCOL_V1']['stages'])


def delivery_order_ok(events):
    """Pure contract order only; does not certify execution of these stages."""
    return isinstance(events, (list, tuple)) and tuple(events) == DELIVERY_CLOSE_STAGES
