"""Frozen v1.6.10 review counterexamples and extended source chronology tests."""
def verify_review1611():
    before_count=len(checks)
    g=globals()
    results=[]
    def probe(name,x,expected):
     actual=g['evaluate169'](x)
     results.append(dict(name=name,expected=expected,actual=actual));ck('X review '+name,actual==expected)
    def direct_probe(name,actual,expected):
     results.append(dict(name=name,expected=expected,actual=actual));ck('X review '+name,actual==expected)
    def canary_objects(x):
     c=g['typed'](x['fs'],'canary-evidence.json','GitCanaryEvidence')
     o=g['typed'](x['fs'],c['observation_ref'],'GitDeliveryObservation')
     return c,o
    def persist(x):g['retain169'](x)
    x=g['prepared169']();probe('current plain baseline',x,True)
    x=g['prepared169'](pr=True);probe('current PR baseline',x,True)
    x=g['prepared169'](pr=True);g['historical_canary169'](x,False,True)
    probe('historical PR canary baseline',x,True)
    can,o=canary_objects(x);d=o['destination_observation'];op=g['typed'](x['fs'],d['operation_evidence_ref'],'GitPushOperationEvidence')
    future='2026-10-15T03:00:00.5Z'
    d.update(observed_at_utc=future,push_started_at_utc=future)
    op.update(lifecycle_started_at_utc=future,push_started_at_utc=future,push_completed_at_utc=future)
    for read in [op['preflight'],op['postflight']]:
     read.update(started_at_utc=future,completed_at_utc=future)
     x['fs'][read['raw_api_ref']]=g['C14']({'kind':'destination_api_snapshot','push_operation_id':op['push_operation_id'],**read,'raw_api_ref':None})
    cmd=g['typed'](x['fs'],op['command_record_ref'],'GitCommandLifecycle');cmd['result'].update(started_at_utc=future,completed_at_utc=future)
    x['fs'][op['command_record_ref']]=g['C14'](cmd);x['fs'][d['operation_evidence_ref']]=g['C14'](op);x['fs'][can['observation_ref']]=g['C14'](o);persist(x)
    probe('canary push completes after current closure and canary receipt',x,False)
    
    # Archived PR binding must have been observed before the receipt that uses it.
    for phase in ['payload','closing']:
     x=g['prepared169'](pr=True);o=x['po'] if phase=='payload' else x['ob']
     binding=g['typed'](x['fs'],o['pull_request_binding_ref'],'GitPullRequestBinding')
     binding['observed_at_utc']='2026-10-15T03:00:30Z'
     x['fs'][o['pull_request_binding_ref']]=g['C14'](binding)
     x['fs'][binding['api_evidence_ref']]=g['C14']({'kind':'pull_request_api_snapshot',**{k:v for k,v in binding.items() if k not in ['format_version','api_evidence_ref','kind']}})
     persist(x)
     probe('archived '+phase+' PR snapshot observed after receipt/seal',x,False)
    
    x=g['prepared169']();x['sel']['updated_at_utc']='2026-10-15T03:00:30Z';x['fs'][x['ar']['selection_ref']]=g['C14'](x['sel']);persist(x)
    probe('selection snapshot updated after enclosing seal',x,False)
    
    # Publication chronology is an important control: the established guard must
    # still reject a late fact that it explicitly covers.
    x=g['prepared169']();x['live']['archive_publication']['published_at_utc']='2026-10-15T03:00:30Z';x['ctx']['archive_publication_sha256']=hashlib.sha256(g['C14'](x['live']['archive_publication'])).hexdigest()
    probe('control publication after live query rejected',x,False)
    
    # Resume controls use an explicitly frozen current context, then mutate only
    # the candidate. These must remain rejected under the current v1.6.10 fix.
    x=g['prepared169']();d=x['ob']['destination_observation'];op=g['typed'](x['fs'],d['operation_evidence_ref'],'GitPushOperationEvidence')
    cmd=g['typed'](x['fs'],op['command_record_ref'],'GitCommandLifecycle')
    checkpoint={**g['valid_checkpoint'],'command_record_ref':op['command_record_ref'],'operation_id':op['push_operation_id'],'command_state':'SUCCEEDED'}
    actual=g['checkpoint_actual_fixture']({**g['actual_checkpoint'],'operation_id':op['push_operation_id'],'command_state':'SUCCEEDED'},op['command_record_ref'],x['fs'],d['operation_evidence_ref'])
    direct_probe('control resume current identity accepted',g['checkpoint_ok'](checkpoint,x['sel'],actual,x['fs']),True)
    for field,value in [('lifecycle_id',g['U2']),('retry_index',1)]:
     fs={**x['fs'],op['command_record_ref']:g['C14']({**cmd,field:value})}
     direct_probe('control resume wrong '+field+' rejected',g['checkpoint_ok'](checkpoint,x['sel'],actual,fs),False)
    missing={k:v for k,v in actual.items() if k!='command_record_sha256'}
    direct_probe('control resume missing secured digest rejected',g['checkpoint_ok'](checkpoint,x['sel'],missing,x['fs']),False)
    
    
    prior=json.loads((run/'regression-1.6.10.json').read_text(encoding='utf-8'))
    ck('X all12 prior probe names and expectations preserved',len(results)==12 and [(v['name'],v['expected']) for v in results]==[(v['name'],v['expected']) for v in prior])
    cases=[]
    def test(name,actual,expected,group):
        ck('X '+name,actual==expected)
        cases.append(dict(name=name,actual=actual,expected=expected,group=group))
    # P1: phase receipt chronology is shared by payload/closing/canary.
    def historic_case():
        z=prepared169(pr=True);historical_canary169(z,False,True)
        can=typed(z['fs'],'canary-evidence.json','GitCanaryEvidence');obs=typed(z['fs'],can['observation_ref'],'GitDeliveryObservation');cp=typed(z['fs'],can['check_plan_ref'],'GitCheckPlan')
        return z,can,obs,cp
    for source in ['canary','payload','closing']:
        for field in ['postflight','command']:
            z,can,obs,cp=historic_case() if source=='canary' else (prepared169(),None,None,None)
            if source!='canary':obs=z['po'] if source=='payload' else z['ob'];cp=z['pl']
            d=obs['destination_observation'];operation=typed(z['fs'],d['operation_evidence_ref'],'GitPushOperationEvidence');command=typed(z['fs'],operation['command_record_ref'],'GitCommandLifecycle')
            later='2026-10-15T03:00:00.1Z'
            if field=='postflight':
                operation['postflight'].update(started_at_utc=later,completed_at_utc=later)
                z['fs'][operation['postflight']['raw_api_ref']]=C14({'kind':'destination_api_snapshot','push_operation_id':operation['push_operation_id'],**operation['postflight'],'raw_api_ref':None})
            command['result']['completed_at_utc']=later
            z['fs'][operation['command_record_ref']]=C14(command);z['fs'][d['operation_evidence_ref']]=C14(operation)
            if can:z['fs'][can['observation_ref']]=C14(obs)
            else:z['fs'][z['ar'][source+'_observation_ref']]=C14(obs)
            retain169(z)
            test('late '+source+' '+field+' internally valid destination',destination_ok(cp,d,obs['subject_sha'],z['fs']),True,'V1610-01')
            test('late '+source+' '+field+' shared receipt guard',phase_receipt_time_ok(obs,z['fs']),False,'V1610-01')
            test('late '+source+' '+field+' composed closure',evaluate169(z),False,'V1610-01')
    for completed,expected in [(now,True),('2026-10-15T10:00:00+07:00',True),('2026-10-15T03:00:00.000Z',True),('2026-10-15T03:00:00.000000000000000001Z',False)]:
        z,can,obs,cp=historic_case();op=typed(z['fs'],obs['destination_observation']['operation_evidence_ref'],'GitPushOperationEvidence');cmd=typed(z['fs'],op['command_record_ref'],'GitCommandLifecycle')
        cmd['result']['completed_at_utc']=completed;z['fs'][op['command_record_ref']]=C14(cmd);retain169(z)
        test('canary completion instant '+completed,evaluate169(z),expected,'V1610-01')
    z,can,obs,cp=historic_case();op=typed(z['fs'],obs['destination_observation']['operation_evidence_ref'],'GitPushOperationEvidence');cmd=typed(z['fs'],op['command_record_ref'],'GitCommandLifecycle');cmd['result']['completed_at_utc']=None;z['fs'][op['command_record_ref']]=C14(cmd);retain169(z)
    test('unknown canary completion never fabricated',evaluate169(z),False,'V1610-01')
    test('unknown canary completion direct guard',phase_receipt_time_ok(obs,z['fs']),False,'V1610-01')

    # P1: archived and live PR acquisition retain separate clock roles.
    def replace_binding_time(z,obs,fs,value):
        binding=typed(fs,obs['pull_request_binding_ref'],'GitPullRequestBinding');binding['observed_at_utc']=value;fs[obs['pull_request_binding_ref']]=C14(binding)
        fs[binding['api_evidence_ref']]=C14({'kind':'pull_request_api_snapshot',**{k:v for k,v in binding.items() if k not in ['format_version','api_evidence_ref','kind']}})
    for phase in ['payload','closing','canary']:
        for acquired,expected in [(before,True),(now,True),('2026-10-15T10:00:00+07:00',True),('2026-10-15T03:00:00.00000000001Z',False),('2026-10-15T03:00:30Z',False)]:
            z,can,obs,cp=historic_case() if phase=='canary' else (prepared169(pr=True),None,None,None)
            if phase!='canary':obs=z['po'] if phase=='payload' else z['ob'];cp=z['pl']
            replace_binding_time(z,obs,z['fs'],acquired);retain169(z)
            test('archived PR acquisition '+phase+' '+acquired,evaluate169(z),expected,'V1610-02')
    z=prepared169(pr=True);frozen=copy.deepcopy((z['ar'],z['fs']))
    z['live'],z['lf'],z['ctx']=make_live_fixture(z['at'],z['pl'],z['ob'],z['ar'],z['fs'],z['current_pr']['closing'],identity=U2,start='2026-10-15T03:00:01Z',end='2026-10-15T03:00:02Z')
    test('fresh later PR query positive',evaluate169(z),True,'V1610-02')
    test('fresh PR query preserves historical archive',(z['ar'],z['fs'])==frozen,True,'V1610-02')
    o=typed(z['lf'],z['live']['closing_observation_ref'],'GitDeliveryObservation')
    replace_binding_time(z,o,z['lf'],now);z['live']['files']=manifest_for(z['lf'])
    test('old binding cannot masquerade as fresh live acquisition',evaluate169(z),False,'V1610-02')
    for target in ['binding','current_pr']:
        z=prepared169(pr=True)
        if target=='binding':
            o=typed(z['lf'],z['live']['closing_observation_ref'],'GitDeliveryObservation');replace_binding_time(z,o,z['lf'],'2026-10-15T03:00:01Z')
        else:
            pr=typed(z['lf'],z['live']['current_pr_ref'],'GitPullRequestBinding');pr['observed_at_utc']='2026-10-15T03:00:01Z';z['lf'][z['live']['current_pr_ref']]=C14(pr)
        z['live']['files']=manifest_for(z['lf']);test('live acquisition after completion '+target,evaluate169(z),False,'V1610-02')

    # P2: allocation is an immutable claim fact, updated_at is a snapshot fact.
    z=prepared169();test('selection allocation field present and valid',gv('GitTaskDeliverySelection',z['sel']),True,'V1610-03')
    for name,patch in [('active null allocation',{'allocated_at_utc':None}),('unclaimed date allocation',{'active_delivery_id':None,'allocated_at_utc':before}),('malformed allocation',{'allocated_at_utc':'not-time'}),('unexpected field',{'claim_time':before})]:
        test('selection schema reject '+name,gv('GitTaskDeliverySelection',{**z['sel'],**patch}),False,'V1610-03')
    missing={k:v for k,v in z['sel'].items() if k!='allocated_at_utc'};test('selection allocation cannot be absent',gv('GitTaskDeliverySelection',missing),False,'V1610-03')
    pending={**z['sel'],'active_delivery_id':None,'allocated_at_utc':None};test('unclaimed nullable allocation shape',gv('GitTaskDeliverySelection',pending),True,'V1610-03')
    test('allocation calendar validated semantically',selection_claim_ok({**z['sel'],'allocated_at_utc':'2026-02-30T00:00:00Z'}),False,'V1610-03')
    test('active snapshot calendar validated semantically',selection_claim_ok({**z['sel'],'updated_at_utc':'2026-02-30T00:00:00Z'}),False,'V1610-03')
    test('pending snapshot calendar validated semantically',selection_claim_ok({**pending,'updated_at_utc':'2026-02-30T00:00:00Z'}),False,'V1610-03')
    cp={**valid_checkpoint,'command_record_ref':None,'operation_id':None,'delivery_id':None,'planned_archive_path':None,'command_state':'NOT_STARTED'}
    secured=checkpoint_actual_fixture({**actual_checkpoint,'operation_id':None,'command_state':'NOT_STARTED'})
    test('unclaimed pending checkpoint readable',checkpoint_ok(cp,pending,secured,z['fs']),True,'V1610-03')
    test('pending checkpoint cannot backfill claim',checkpoint_ok(cp,{**pending,'allocated_at_utc':before},secured,z['fs']),False,'V1610-03')
    for allocated,updated,expected,label in [(before,now,True,'metadata refresh after P start'),(before,'2026-10-15T10:00:00+07:00',True,'snapshot offset same archive tick'),(before,'2026-10-15T03:00:00.00000001Z',False,'snapshot after archive'),('2026-10-15T02:59:59.5Z',now,False,'allocation after P lifecycle start'),(now,before,False,'allocation after update')]:
        z=prepared169();z['sel'].update(allocated_at_utc=allocated,updated_at_utc=updated);z['fs'][z['ar']['selection_ref']]=C14(z['sel']);retain169(z)
        test('selection temporal '+label,evaluate169(z),expected,'V1610-03')
    z=revision166();rebind166(z);z['live'],z['lf'],z['ctx']=make_live_fixture(z['at'],z['pl'],z['ob'],z['ar'],z['fs'])
    test('selection revision history equal clock tick',evaluate169(z),True,'V1610-03')
    previous=typed(z['fs'],'previous-selection.json','GitTaskDeliverySelection');previous['updated_at_utc']='2026-10-15T02:59:59.5Z';z['fs']['previous-selection.json']=C14(previous);retain169(z)
    test('new claim before previous snapshot rejected',evaluate169(z),False,'V1610-03')

    # P2: explicit protocol stages define order, not only words in prose.
    protocol=blocks['MCE4D_DELIVERY_PROTOCOL_V1']
    expected=['validate_retained_receipts','archive_publish_or_reuse_readback','pin_publication_context','query_live_verification','retain_live_readback','effective_done']
    test('canonical protocol shape and exact stages',all(protocol.get(k)==v for k,v in dict(format_version=1,kind='delivery_close_protocol',stages=expected).items()),True,'V1610-04')
    test('first publication stage order',delivery_order_ok(expected),True,'V1610-04')
    test('resume reuses archive readback without duplicate stage',delivery_order_ok(tuple(expected)),True,'V1610-04')
    for i in range(len(expected)):
        test('protocol missing stage '+expected[i],delivery_order_ok(expected[:i]+expected[i+1:]),False,'V1610-04')
        test('protocol duplicate stage '+expected[i],delivery_order_ok(expected[:i]+[expected[i]]+expected[i:]),False,'V1610-04')
    for i in range(len(expected)-1):
        swapped=expected.copy();swapped[i],swapped[i+1]=swapped[i+1],swapped[i]
        test('protocol adjacent order swap '+str(i),delivery_order_ok(swapped),False,'V1610-04')
    test('old live-before-archive order rejected',delivery_order_ok([expected[0],expected[3],expected[1],expected[2],expected[4],expected[5]]),False,'V1610-04')
    test('unknown protocol stage rejected',delivery_order_ok(expected+['commit_own_result']),False,'V1610-04')
    done=next(line for line in s.split('\n') if line.startswith('`DONE-EVAL-01`:'))
    step=next(line for line in s.split('\n') if line.startswith('4. DELIVERY-ORDER-01:'))
    checklist=next(line for line in s.split('\n') if line.startswith('Checklist mỗi phiên:'))
    test('DONE-EVAL archive before publication pin before live before DONE',done.index('publish/readback archive')<done.index('pin publication projection')<done.index('lấy fresh GitLiveVerification')<done.index('effective DONE/auto-next'),True,'V1610-04')
    test('GIT06 same archive before live order',step.index('ARCHIVE-PUBLISH-01')<step.index('fresh LIVE-CI-01'),True,'V1610-04')
    test('resume checklist same archive before live order',checklist.index('archive publish/reuse/readback')<checklist.index('fresh live verification')<checklist.index('retain live/readback')<checklist.index('effective DONE'),True,'V1610-04')
    frozen=prepared169(pr=True);before_inputs=copy.deepcopy(frozen)
    test('composed order remains idempotent',evaluate169(frozen) and evaluate169(frozen),True,'V1610-04')
    test('normative guards never repair fixture facts',frozen==before_inputs,True,'V1610-04')
    test('current metadata and four closures',fm['spec_version']==resume['spec_version']=='1.6.13' and fm['latest_review_findings']==fm['latest_review_findings_integrated']==5 and resume['latest_review_closure']=='S52_CLOSE_13' and resume['latest_review_baseline']=='1.6.12' and all(value in s for value in ['A052','D064','D065','D066','D067','PHASE-RECEIPT-TIME-01','PR-ACQUISITION-TIME-01','SELECTION-TIME-01','DELIVERY-ORDER-01']),True,'sync')
    result={'spec_version':'1.6.11','groups_closed':4,'prior_review_probes':results,'prior_mismatches':4,'current_mismatches':sum(v['actual']!=v['expected'] for v in results),'prior_controls_preserved':8,'new_assertions':len(checks)-before_count,'cases':cases,'scope':'Document/reference synthetic source/time/allocation/protocol facts only. Actual Git/API/allocator/OS/product/CI NOT_RUN.'}
    (run/'review-1.6.11-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')

verify_review1611()
