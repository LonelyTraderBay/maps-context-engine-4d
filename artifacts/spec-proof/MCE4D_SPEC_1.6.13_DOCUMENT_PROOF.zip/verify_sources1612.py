"""Complementary v1.6.12 source/identity/time regressions; no automatic run.

Fixtures are explicitly constructed before each probe, then frozen. Mutations
only alter the selected retained test member and its synthetic manifest. The
evaluation path never invokes construction or repairs the supplied evidence.
"""


def verify_sources1612():
    from datetime import datetime, timedelta, timezone

    cases = []
    immutable = []

    def test(name, actual, expected, group):
        ck('Y source ' + name, actual == expected)
        cases.append(dict(group=group, name=name, actual=actual, expected=expected))

    def evaluate(value):
        frozen = copy.deepcopy(value)
        result = evaluate169(value)
        immutable.append(value == frozen)
        return result

    def source_projection(binding):
        return {'kind': 'pull_request_api_snapshot',
                **{key: value for key, value in binding.items()
                   if key not in ['format_version', 'kind', 'api_evidence_ref']}}

    def historic():
        value = prepared169(pr=True)
        historical_canary169(value, False, True)
        canary = typed(value['fs'], 'canary-evidence.json', 'GitCanaryEvidence')
        observation = typed(value['fs'], canary['observation_ref'], 'GitDeliveryObservation')
        plan = typed(value['fs'], canary['check_plan_ref'], 'GitCheckPlan')
        return value, observation, plan

    def role_fixture(role):
        if role == 'historical_canary':
            value, observation, plan = historic()
            fs = value['fs']
            binding_ref = observation['pull_request_binding_ref']
        else:
            value = prepared169(pr=True)
            fs = value['fs'] if role in ['payload', 'closing'] else value['lf']
            if role in ['payload', 'closing']:
                observation = value['po'] if role == 'payload' else value['ob']
                binding_ref = observation['pull_request_binding_ref']
            elif role == 'live_binding':
                observation = typed(fs, value['live']['closing_observation_ref'], 'GitDeliveryObservation')
                binding_ref = observation['pull_request_binding_ref']
            else:
                binding_ref = value['live']['current_pr_ref']
        binding = typed(fs, binding_ref, 'GitPullRequestBinding')
        # Deliberately distinct sources prevent a valid peer snapshot from
        # accidentally masking failure in this role's own API acquisition.
        binding['api_evidence_ref'] = 'isolated-' + role + '-api.json'
        fs[binding_ref] = C14(binding)
        fs[binding['api_evidence_ref']] = C14(source_projection(binding))
        if fs is value['fs']:
            retain169(value)
        else:
            value['live']['files'] = manifest_for(fs)
        return value, fs, binding_ref

    def keep(value, fs):
        if fs is value['fs']:
            retain169(value)
        else:
            value['live']['files'] = manifest_for(fs)

    # Each distinct role is exercised through the shared source guard and the
    # complete DONE evaluator, after construction has ended.
    mutations = ['valid', 'missing', 'kind', 'head', 'repository', 'head_repository',
                 'number', 'head_ref', 'base_ref', 'base', 'merge', 'acquisition',
                 'noncanonical', 'duplicate_json']
    for role in ['payload', 'closing', 'historical_canary', 'live_binding', 'current_pr']:
        for mutation in mutations:
            value, fs, binding_ref = role_fixture(role)
            binding = typed(fs, binding_ref, 'GitPullRequestBinding')
            ref = binding['api_evidence_ref']
            raw = load_member(fs, ref)
            if mutation == 'missing':
                del fs[ref]
            elif mutation == 'kind':
                raw['kind'] = 'unrelated_api_snapshot'
            elif mutation in ['head', 'base', 'merge']:
                raw[{'head': 'head_sha', 'base': 'base_sha', 'merge': 'tested_merge_sha'}[mutation]] = '7' * 40
            elif mutation in ['repository', 'head_repository', 'number']:
                field = {'repository': 'repository_id', 'head_repository': 'head_repository_id', 'number': 'pull_request_number'}[mutation]
                raw[field] = raw[field] + 1
            elif mutation in ['head_ref', 'base_ref']:
                raw[mutation] = 'refs/heads/unrelated'
            elif mutation == 'acquisition':
                raw['observed_at_utc'] = '2026-10-15T03:00:30Z'
            if mutation != 'missing':
                fs[ref] = C14(raw)
                if mutation == 'noncanonical':
                    fs[ref] = b' ' + fs[ref]
                elif mutation == 'duplicate_json':
                    fs[ref] = fs[ref][:-1] + b',"kind":"pull_request_api_snapshot"}'
            keep(value, fs)
            expected = mutation == 'valid'
            test(role + ' raw ' + mutation + ' shared guard', pr_source_ok(binding, fs), expected, 'V1611-01')
            test(role + ' raw ' + mutation + ' composed', evaluate(value), expected, 'V1611-01')

    # Invalid calendar dates must fail even if a date-time format checker in a
    # particular jsonschema installation does not enforce the calendar itself.
    for timestamp in ['not-time', '2026-02-30T03:00:00Z', '2026-10-15T25:00:00Z', '2026-10-15T03:00:00+24:00']:
        value, fs, ref = role_fixture('current_pr')
        binding = typed(fs, ref, 'GitPullRequestBinding')
        binding['observed_at_utc'] = timestamp
        fs[ref] = C14(binding)
        fs[binding['api_evidence_ref']] = C14(source_projection(binding))
        keep(value, fs)
        test('malformed PR acquisition ' + timestamp + ' helper', pr_source_ok(binding, fs), False, 'V1611-01')
        test('malformed PR acquisition ' + timestamp + ' composed', evaluate(value), False, 'V1611-01')

    # Receipt-to-command identity uses the historical delivery's UUID, never
    # the current task UUID. Positive destination controls isolate this link.
    for role in ['payload', 'closing', 'historical_canary']:
        if role == 'historical_canary':
            value, observation, plan = historic()
        else:
            value = prepared169()
            observation = value['po'] if role == 'payload' else value['ob']
            plan = value['pl']
        operation = typed(value['fs'], observation['destination_observation']['operation_evidence_ref'], 'GitPushOperationEvidence')
        command = typed(value['fs'], operation['command_record_ref'], 'GitCommandLifecycle')
        test(role + ' command own UUID positive', phase_command_identity_ok(observation, command), True, 'V1611-02')
        test(role + ' command own UUID composed', evaluate(value), True, 'V1611-02')
        if role == 'historical_canary':
            test('historical command UUID differs from active UUID', command['delivery_id'] != value['at']['delivery_id'], True, 'V1611-02')
        for name, uuid_value in [('null', None), ('foreign', '44444444-4444-4444-8444-444444444444')]:
            candidate = copy.deepcopy(value)
            changed = copy.deepcopy(command)
            changed['delivery_id'] = uuid_value
            candidate['fs'][operation['command_record_ref']] = C14(changed)
            retain169(candidate)
            test(role + ' command ' + name + ' destination shape control', destination_ok(plan, observation['destination_observation'], observation['subject_sha'], candidate['fs']), name != 'null', 'V1611-02')
            test(role + ' command ' + name + ' shared identity', phase_command_identity_ok(observation, changed), False, 'V1611-02')
            test(role + ' command ' + name + ' shared receipt', phase_receipt_time_ok(observation, candidate['fs']), False, 'V1611-02')
            test(role + ' command ' + name + ' composed', evaluate(candidate), False, 'V1611-02')

    # UTC equality allows encoding differences but rejects a genuine 1 ns
    # difference. Destination raw API snapshots are deliberately left unchanged.
    for role in ['payload', 'closing']:
        for field in ['started_at_utc', 'deadline_at_utc']:
            for encoding, expected in [('offset', True), ('fractional_zero', True), ('nanosecond_drift', False)]:
                value = prepared169()
                observation = value['po'] if role == 'payload' else value['ob']
                destination = observation['destination_observation']
                operation = typed(value['fs'], destination['operation_evidence_ref'], 'GitPushOperationEvidence')
                command = typed(value['fs'], operation['command_record_ref'], 'GitCommandLifecycle')
                container = command['result'] if field == 'started_at_utc' else command['contract']
                original = container[field]
                if encoding == 'offset':
                    container[field] = datetime.fromisoformat(original.replace('Z', '+00:00')).astimezone(timezone(timedelta(hours=7))).isoformat()
                else:
                    container[field] = original[:-1] + ('.000000000Z' if encoding == 'fractional_zero' else '.000000001Z')
                snapshots = {read['raw_api_ref']: value['fs'][read['raw_api_ref']] for read in [operation['preflight'], operation['postflight']]}
                value['fs'][operation['command_record_ref']] = C14(command)
                retain169(value)
                test(role + ' ' + field + ' ' + encoding + ' destination', destination_ok(value['pl'], destination, observation['subject_sha'], value['fs']), expected, 'V1611-03')
                test(role + ' ' + field + ' ' + encoding + ' composed', evaluate(value), expected, 'V1611-03')
                test(role + ' ' + field + ' ' + encoding + ' raw API preserved', all(value['fs'][ref] == data for ref, data in snapshots.items()), True, 'V1611-03')

    for left, right, expected in [
        ('2026-10-15T03:00:00Z', '2026-10-15T10:00:00+07:00', True),
        ('2026-10-15T03:00:00.123400000Z', '2026-10-15T10:00:00.1234+07:00', True),
        ('2026-10-15T03:00:00.000000001Z', '2026-10-15T03:00:00Z', False),
        ('2026-02-30T03:00:00Z', '2026-02-30T03:00:00Z', False),
        ('not-time', 'not-time', False),
        (None, None, False),
    ]:
        test('same instant ' + repr(left) + ' / ' + repr(right), same_instant(left, right), expected, 'V1611-03')

    # Python considers True == 1 and False == 0. Raw JSON parity must preserve
    # their different JSON types across every projection, not only PR sources.
    for left, right, expected in [
        ({'x': True}, {'x': 1}, False),
        ({'x': False}, {'x': 0}, False),
        ({'nested': [{'x': True}]}, {'nested': [{'x': 1}]}, False),
        ({'a': 1, 'b': False}, {'b': False, 'a': 1}, True),
        ({'x': 1.0}, {'x': 1}, False),
    ]:
        test('typed JSON parity ' + repr(left) + ' / ' + repr(right), exact_json_equal(left, right), expected, 'V1611-01')

    value, fs, ref = role_fixture('current_pr')
    binding = typed(fs, ref, 'GitPullRequestBinding')
    raw = load_member(fs, binding['api_evidence_ref'])
    test('PR integer one control', raw['pull_request_number'] == 1 and type(raw['pull_request_number']) is int, True, 'V1611-01')
    raw['pull_request_number'] = True
    fs[binding['api_evidence_ref']] = C14(raw)
    keep(value, fs)
    test('PR raw boolean cannot impersonate number shared', pr_source_ok(binding, fs), False, 'V1611-01')
    test('PR raw boolean cannot impersonate number composed', evaluate(value), False, 'V1611-01')

    for role in ['payload', 'closing']:
        value = prepared169()
        observation = value['po'] if role == 'payload' else value['ob']
        destination = observation['destination_observation']
        operation = typed(value['fs'], destination['operation_evidence_ref'], 'GitPushOperationEvidence')
        rawref = operation['preflight']['raw_api_ref']
        raw = load_member(value['fs'], rawref)
        test(role + ' destination integer zero control', type(raw['retry_index']) is int and raw['retry_index'] == 0, True, 'V1611-01')
        raw['retry_index'] = False
        value['fs'][rawref] = C14(raw)
        retain169(value)
        test(role + ' destination raw bool cannot impersonate retry index', destination_ok(value['pl'], destination, observation['subject_sha'], value['fs']), False, 'V1611-01')
        test(role + ' destination raw bool composed', evaluate(value), False, 'V1611-01')

    for role in ['payload', 'closing', 'live']:
        value = prepared169()
        fs = value['lf'] if role == 'live' else value['fs']
        observation = typed(fs, value['live']['closing_observation_ref'], 'GitDeliveryObservation') if role == 'live' else value['po'] if role == 'payload' else value['ob']
        collection = typed(fs, observation['collection_evidence_ref'], 'GitCICollectionEvidence')
        page = collection['pages'][0]
        raw = load_member(fs, page['raw_page_ref'])
        test(role + ' CI integer page one control', type(raw['page_number']) is int and raw['page_number'] == 1, True, 'V1611-01')
        raw['page_number'] = True
        fs[page['raw_page_ref']] = C14(raw)
        keep(value, fs)
        test(role + ' CI raw bool cannot impersonate page number', collection_ok(value['pl'], observation, collection, fs, collection['started_at_utc'], observation['observed_at_utc']), False, 'V1611-01')
        test(role + ' CI raw bool composed', evaluate(value), False, 'V1611-01')

    for field in ['check_id', 'app_id']:
        # Explicit valid synthetic native numeric IDs are set before freezing.
        value = prepared169()
        value['pl']['checks'][0]['source_app'] = 'github.com:app:1'
        for observation in [value['po'], value['ob']]:
            for check_value in observation['checks']:
                check_value['source_app'] = 'github.com:app:1'
                put_check_evidence(value['fs'], check_value, observation['subject_sha'], 'native-one-' + observation['phase'], req=value['pl']['checks'][0])
        check_value = value['po']['checks'][0]
        source = typed(value['fs'], check_value['source_evidence_ref'], 'GitCheckSourceEvidence')
        source['record_id'] = '1'
        source['job_check_run_url'] = source['job_check_run_url'].rsplit('/', 1)[0] + '/1'
        value['fs'][check_value['source_evidence_ref']] = C14(source)
        value['fs'][source['raw_api_ref']] = C14(source_snapshot(source))
        rebind166(value)
        value['live'], value['lf'], value['ctx'] = make_live_fixture(value['at'], value['pl'], value['ob'], value['ar'], value['fs'])
        test('native numeric ' + field + ' constructed positive composed', evaluate(value), True, 'V1611-01')
        test('native numeric ' + field + ' constructed positive source', native_observed_ok(value['pl'], check_value, value['po']['subject_sha'], value['fs']), True, 'V1611-01')
        raw = load_member(value['fs'], source['raw_api_ref'])
        if field == 'check_id':
            raw['record']['id'] = True
        else:
            raw['record']['app']['id'] = True
        value['fs'][source['raw_api_ref']] = C14(raw)
        retain169(value)
        test('native raw bool ' + field + ' shared parity', exact_json_equal(raw, source_snapshot(source)), False, 'V1611-01')
        test('native raw bool ' + field + ' direct source', native_observed_ok(value['pl'], check_value, value['po']['subject_sha'], value['fs']), False, 'V1611-01')
        test('native raw bool ' + field + ' direct execution', check_evidence_ok(value['pl'], value['pl']['checks'][0], check_value, value['po']['subject_sha'], value['fs']), False, 'V1611-01')
        test('native raw bool ' + field + ' composed', evaluate(value), False, 'V1611-01')

    test('all source evaluations preserve frozen inputs', bool(immutable) and all(immutable), True, 'V1611-01')
    return cases
