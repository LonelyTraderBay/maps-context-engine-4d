from pathlib import Path
import sys, runpy, contextlib, io, json, copy, hashlib
from datetime import datetime, timezone, timedelta

R=Path(__file__).resolve().parent
args=sys.argv[1:]
W=Path(args[1]) if len(args)>1 else Path(r'C:\Users\Joker-PC\Documents\Projects\maps-context-engine-4d')
S=Path(args[0]) if args else R/('spec.bin' if (R/'spec.bin').exists() else 'final-spec.bin')
# This portable package has one flat, manifest-bound source tree. Directory
# existence must never redirect execution to an unlisted child checkout.
PROOF_SOURCE_MEMBERS=(
    'archive_io_worker.py','delivery_core.py','delivery_protocol1612.py',
    'delivery1610.py','delivery1611.py','delivery1612.py','delivery167.py',
    'delivery168.py','delivery169.py','fixture_support1610.py',
    'fixture_support1611.py','fixture_support167.py','fixture_support168.py',
    'fixture_support169.py','independent_audit.py','review_fixtures169.py',
    'verify_archive_io.py','verify_delivery.py','verify_findings.py',
    'verify_harness1613.py','verify_manifest.py','verify_metadata1613.py',
    'verify_review1610.py','verify_review1611.py','verify_review1612.py',
    'verify_review1613.py','verify_review166.py','verify_review167.py',
    'verify_review168.py','verify_review169.py','verify_sources1612.py','verify_spec.py',
)
runpy.run_path(str(R/'verify_manifest.py'))['verify_manifest'](R,required_members=PROOF_SOURCE_MEMBERS)
sources=R
sys.argv=[str(sources/'verify_spec.py'),str(S),str(W)]
output=io.StringIO()
with contextlib.redirect_stdout(output):
    g=runpy.run_path(str(sources/'verify_spec.py'))
(R/'suite.json').write_text(output.getvalue(),encoding='utf-8')
results=[]
def ck(name,actual,expected=True):
    results.append({'name':name,'actual':actual,'expected':expected})
def new(pr=False):return g['prepared169'](pr=pr)
def ev(x):return g['evaluate169'](x)
def keep(x):g['retain169'](x)
def kl(x):x['live']['files']=g['manifest_for'](x['lf'])
def prsource(snapshot):return {'kind':'pull_request_api_snapshot',**{k:v for k,v in snapshot.items() if k not in ['format_version','api_evidence_ref','kind']}}
def live_ob(x):return g['typed'](x['lf'],x['live']['closing_observation_ref'],'GitDeliveryObservation')
def change_raw(x,target,mutator):
    ref=x['live']['current_pr_ref'] if target=='current_pr' else live_ob(x)['pull_request_binding_ref']
    value=g['typed'](x['lf'],ref,'GitPullRequestBinding')
    value['api_evidence_ref']='independent/'+target+'-api.json'
    raw=prsource(value)
    mutator(raw)
    x['lf'][ref]=g['C14'](value)
    x['lf'][value['api_evidence_ref']]=g['C14'](raw)
    kl(x)
    return value

ck('plain fixture positive',ev(new()))
ck('PR fixture positive',ev(new(True)))

# Every independent PR raw member is separately resolved and matched. Altering
# API projection bytes while preserving the typed snapshot cannot be hidden by
# a different valid closing binding or by recomputing the manifest.
mutations={
    'kind':lambda r:r.update(kind='other_api'),
    'host':lambda r:r.update(host='other.example'),
    'repository':lambda r:r.update(repository_id=987),
    'head repository':lambda r:r.update(head_repository_id=987),
    'PR number':lambda r:r.update(pull_request_number=987),
    'PR number boolean':lambda r:r.update(pull_request_number=True),
    'head ref':lambda r:r.update(head_ref='refs/heads/wrong'),
    'base ref':lambda r:r.update(base_ref='refs/heads/wrong'),
    'head SHA':lambda r:r.update(head_sha='7'*40),
    'base SHA':lambda r:r.update(base_sha='7'*40),
    'merge SHA':lambda r:r.update(tested_merge_sha='7'*40),
    'future acquisition':lambda r:r.update(observed_at_utc='2026-10-15T03:00:30Z'),
    'unknown field':lambda r:r.update(extra='not retained projection'),
    'missing field':lambda r:r.pop('head_sha'),
}
for target in ['current_pr','binding']:
    x=new(True);change_raw(x,target,lambda r:None);ck(target+' distinct raw positive',ev(x))
    for name,mutation in mutations.items():
        x=new(True);change_raw(x,target,mutation);frozen=copy.deepcopy(x)
        ck(target+' raw wrong '+name,ev(x),False)
        ck(target+' wrong '+name+' evaluator immutable',x==frozen)
    for body,name in [(None,'missing file'),(b'not JSON','malformed JSON'),(b'[]','wrong top-level')]:
        x=new(True);v=change_raw(x,target,lambda r:None)
        if body is None:del x['lf'][v['api_evidence_ref']]
        else:x['lf'][v['api_evidence_ref']]=body
        kl(x);ck(target+' raw '+name,ev(x),False)
    for stamp in ['2026-02-30T03:00:10Z','2026-10-15T03:00:10','2026-10-15T03:00:10+25:00']:
        x=new(True);ref=x['live']['current_pr_ref'] if target=='current_pr' else live_ob(x)['pull_request_binding_ref']
        v=g['typed'](x['lf'],ref,'GitPullRequestBinding');v['observed_at_utc']=stamp
        v['api_evidence_ref']='independent/invalid-time-'+target+'.json'
        x['lf'][ref]=g['C14'](v);x['lf'][v['api_evidence_ref']]=g['C14'](prsource(v));kl(x)
        ck(target+' invalid acquired instant '+stamp,ev(x),False)
    for mode in ['offset','fractional equal']:
        x=new(True);ref=x['live']['current_pr_ref'] if target=='current_pr' else live_ob(x)['pull_request_binding_ref']
        v=g['typed'](x['lf'],ref,'GitPullRequestBinding');stamp=v['observed_at_utc']
        v['observed_at_utc']=(datetime.fromisoformat(stamp.replace('Z','+00:00')).astimezone(timezone(timedelta(hours=7))).isoformat()
            if mode=='offset' else stamp.replace('Z','.000000000Z'))
        v['api_evidence_ref']='independent/equal-time-'+target+'.json'
        x['lf'][ref]=g['C14'](v);x['lf'][v['api_evidence_ref']]=g['C14'](prsource(v));kl(x)
        ck(target+' acquisition semantic '+mode,ev(x))

# Historical canary retains its own receipt UUID; it must not match the active
# delivery simply because that active delivery uses it as a prerequisite.
for pr in [False,True]:
    x=new(pr)
    if not pr:x['current_pr']={'closing':None}
    g['historical_canary169'](x,False,pr)
    can=g['typed'](x['fs'],'canary-evidence.json','GitCanaryEvidence')
    obs=g['typed'](x['fs'],can['observation_ref'],'GitDeliveryObservation')
    op=g['typed'](x['fs'],obs['destination_observation']['operation_evidence_ref'],'GitPushOperationEvidence')
    command=g['typed'](x['fs'],op['command_record_ref'],'GitCommandLifecycle')
    ck('canary own ID '+str(pr),command['delivery_id']==obs['delivery_id']!=x['at']['delivery_id'])
    ck('historical canary positive '+str(pr),ev(x))
    for wrong in [x['at']['delivery_id'],g['UC']]:
        y=copy.deepcopy(x);c=copy.deepcopy(command);c['delivery_id']=wrong
        y['fs'][op['command_record_ref']]=g['C14'](c);keep(y)
        ck('historical canary other UUID '+str(pr)+' '+wrong,ev(y),False)

# Temporal equivalence is semantic, while source bytes remain untouched except
# the explicit supplied command snapshot under test.
for phase in ['payload','closing']:
    for field in ['start','deadline']:
        for mode in ['offset','fractional equal','drift','no timezone','bad calendar']:
            x=new();obs=x['po'] if phase=='payload' else x['ob']
            op=g['typed'](x['fs'],obs['destination_observation']['operation_evidence_ref'],'GitPushOperationEvidence')
            command=g['typed'](x['fs'],op['command_record_ref'],'GitCommandLifecycle')
            obj=command['result'] if field=='start' else command['contract'];key='started_at_utc' if field=='start' else 'deadline_at_utc'
            stamp=obj[key]
            dt=datetime.fromisoformat(stamp.replace('Z','+00:00'))
            if mode=='offset':obj[key]=dt.astimezone(timezone(timedelta(hours=7))).isoformat()
            elif mode=='fractional equal':obj[key]=stamp.replace('Z','.000000000Z')
            elif mode=='drift':obj[key]=stamp.replace('Z','.000000001Z')
            elif mode=='no timezone':obj[key]=stamp.removesuffix('Z')
            elif mode=='bad calendar':obj[key]='2026-02-30T03:00:00Z'
            x['fs'][op['command_record_ref']]=g['C14'](command);keep(x)
            ck(phase+' '+field+' '+mode,ev(x),mode in ['offset','fractional equal'])

# Frozen archive and active identity remain stable across repeated current
# queries. Offline history is distinct from a new current HEAD claim.
x=new(True);frozen=copy.deepcopy(x)
ck('repeated live evaluation positive',ev(x) and ev(x))
ck('repeated evaluation does not allocate or mutate',x==frozen)
args=(x['at'],x['pl'],x['ob'],x['ar'],x['fs'],[x['ca']],['S19/T001/Status'],g['Q'])
ck('historical offline branch advanced',g['effective_done'](*args,offline=True,sel=x['sel'],seal_record=g['seal_for'](x['ar']),published=True))
ck('current online branch advanced',g['effective_done'](*args,sel=x['sel'],seal_record=g['seal_for'](x['ar']),published=True,live_verification=x['live'],live_files=x['lf'],live_context=x['ctx']),False)

# Exact JSON projection parity must distinguish false from integer zero and
# true from integer one. Python value equality alone collapses these types.
for phase in ['payload','closing']:
    for boundary in ['preflight','postflight']:
        x=new();obs=x['po'] if phase=='payload' else x['ob']
        op=g['typed'](x['fs'],obs['destination_observation']['operation_evidence_ref'],'GitPushOperationEvidence')
        raw=g['load_member'](x['fs'],op[boundary]['raw_api_ref']);raw['retry_index']=False
        x['fs'][op[boundary]['raw_api_ref']]=g['C14'](raw);keep(x)
        ck(phase+' destination '+boundary+' raw boolean retry',ev(x),False)
x=new();obs=live_ob(x);coll=g['typed'](x['lf'],obs['collection_evidence_ref'],'GitCICollectionEvidence')
page=next(p for p in coll['pages'] if p['page_number']==1)
raw=g['load_member'](x['lf'],page['raw_page_ref']);raw['page_number']=True
x['lf'][page['raw_page_ref']]=g['C14'](raw);kl(x)
ck('live collection raw boolean page number',ev(x),False)
x=new();obs=live_ob(x);source=g['typed'](x['lf'],obs['checks'][0]['source_evidence_ref'],'GitCheckSourceEvidence')
raw=g['load_member'](x['lf'],source['raw_api_ref']);raw['workflow_run']['run_attempt']=True
x['lf'][source['raw_api_ref']]=g['C14'](raw);kl(x)
ck('live native source raw boolean run attempt',ev(x),False)

# Independently read canonical protocol and exercise every declared boundary
# through separately supplied current facts, including safe AW-04 suspension.
protocol=g['blocks']['MCE4D_DELIVERY_PROTOCOL_V1']
order=protocol['delivery_stages']
ck('full delivery order positive',g['full_delivery_order_ok'](order))
ck('closing order retains suffix',order[-len(protocol['stages']):]==protocol['stages'])
for i,stage in enumerate(order):
    ck('full order missing '+stage,g['full_delivery_order_ok'](order[:i]+order[i+1:]),False)
    ck('full order duplicate '+stage,g['full_delivery_order_ok'](order[:i]+[stage]+order[i:]),False)
    if i+1<len(order):
        v=list(order);v[i],v[i+1]=v[i+1],v[i]
        ck('full order swap '+stage,g['full_delivery_order_ok'](v),False)
pending={'delivery_id':g['U'],'task_revision':1}
for boundary,expected in protocol['resume_next_stage'].items():
    p=None if boundary=='no_pending' else copy.deepcopy(pending)
    actual={'boundary':boundary,'delivery_id':None if p is None else p['delivery_id'],
            'task_revision':None if p is None else p['task_revision'],'effective_done':boundary=='after_effective_done'}
    if boundary=='suspended_external_blocker':actual.update(suspension_ref='suspensions/T001.json',operation_settled=True)
    ck('resume boundary '+boundary,g['delivery_resume_stage'](boundary,p,actual),expected)
    for field in actual:
        a=copy.deepcopy(actual);a.pop(field)
        ck('resume '+boundary+' missing '+field,g['delivery_resume_stage'](boundary,p,a),None)
    a=copy.deepcopy(actual);a['unknown']=True
    ck('resume '+boundary+' unknown fact',g['delivery_resume_stage'](boundary,p,a),None)
    a=copy.deepcopy(actual);a['effective_done']=not a['effective_done']
    ck('resume '+boundary+' wrong completion',g['delivery_resume_stage'](boundary,p,a),None)
    if p:
        for key,bad in [('delivery_id',g['UC']),('task_revision',2),('task_revision',True),('task_revision',1.0)]:
            a=copy.deepcopy(actual);a[key]=bad
            ck('resume '+boundary+' wrong actual '+key+' '+repr(bad),g['delivery_resume_stage'](boundary,p,a),None)
        q=copy.deepcopy(p);q['delivery_id']=g['UC']
        ck('resume '+boundary+' substituted pending UUID',g['delivery_resume_stage'](boundary,q,actual),None)
    else:
        ck('no_pending cannot bypass retained UUID',g['delivery_resume_stage'](boundary,pending,actual),None)
    if boundary=='suspended_external_blocker':
        for key,bad in [('operation_settled',False),('operation_settled',1),('operation_settled',None),('suspension_ref',''),('suspension_ref','../wrong'),('suspension_ref',None),('suspension_ref',7)]:
            a=copy.deepcopy(actual);a[key]=bad
            ck('suspension invalid '+key+' '+repr(bad),g['delivery_resume_stage'](boundary,p,a),None)

summary={'checks':len(results),'passed':sum(r['actual']==r['expected'] for r in results),'failed':[r for r in results if r['actual']!=r['expected']],'results':results,'spec_sha256':hashlib.sha256(S.read_bytes()).hexdigest()}
(R/'independent-results.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k!='results'},ensure_ascii=False,indent=2))
if summary['failed']:raise SystemExit(1)
