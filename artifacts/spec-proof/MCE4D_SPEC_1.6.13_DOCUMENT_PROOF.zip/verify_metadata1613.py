"""Current labels and exact authority preservation for this document-only patch."""
start1613=len(checks)
current_labels=[]
for pattern in [r'^Bản hiện tại([0-9.]+) gồm',r'^V([0-9.]+) routing',r'^Đặc tả v([0-9.]+) là bản vẽ',r'^S53 là execution/completion authority v([0-9.]+);']:
    values=re.findall(pattern,s,re.M)
    ck('V1612 current label '+pattern,len(values)==1 and values[0]==fm['spec_version'])
    current_labels.extend(values)
before_authority=re.findall(r'<!-- BEGIN ([A-Z0-9_]+) -->(.*?)<!-- END \1 -->',orig,re.S)
after_authority=re.findall(r'<!-- BEGIN ([A-Z0-9_]+) -->(.*?)<!-- END \1 -->',s,re.S)
ck('V1612 all13 machine authority blocks unchanged',len(before_authority)==13 and before_authority==after_authority)
ck('V1612 five technical and one editorial closure synchronized',fm['latest_review_findings']==fm['latest_review_findings_integrated']==5 and resume['latest_review_baseline']=='1.6.12' and resume['latest_review_closure']=='S52_CLOSE_13' and all(token in s for token in ['A054','D072','D073','D074','D075','D076','E1612-01']))
ck('V1612 typed guard owners and proof owners routed',all(token in s for token in ['CHECKPOINT-TYPE-01','RATIONALE-TEXT-01','MEMBER-SHAPE-01','MANIFEST-CHECK-01','PROOF-SOURCE-01','GIT-DATA-13','QA-06']))
(run/'metadata-1.6.13-validation.json').write_text(json.dumps({'spec_version':'1.6.13','checks':len(checks)-start1613,'current_labels':current_labels,'machine_blocks_unchanged':13,'technical_findings_closed':5,'editorial_findings_closed':1},indent=2),encoding='utf-8')
