"""v1.6.10 pure reference guards. No Git, process or network implementation."""


def canary_proven_events(pl, observation, fs):
    """Workflow discovery precedes per-event job selection, including no-job runs."""
    collection = typed(fs, observation['collection_evidence_ref'], 'GitCICollectionEvidence')
    workflow_rows = []
    for page in collection['pages']:
        if page['endpoint'] == 'workflow_runs':
            workflow_rows.extend(object_member(fs, page['raw_page_ref'])['items'])
    proven = set()
    subject = observation['subject_sha']
    for req in pl['checks']:
        for event in req['eligible_events']:
            candidates = [v for v in observation['checks'] if v['check_id'] == req['id'] and v['event'] == event]
            if req['workflow_path'] is not None:
                rows = [row for row in workflow_rows if row['workflow_path'] == req['workflow_path'] and row['event'] == event]
                if not rows:
                    continue
                current = max(rows, key=lambda row: (instant(row['created_at']), int(row['run_id'])))
                candidates = [v for v in candidates if v['run_id'] == current['run_id']]
                # A later workflow generation or unresolved rerun cannot be
                # hidden by success from another eligible event.
                if current['status'] != 'completed' or not current['job_source_refs']:
                    continue
            if not candidates:
                continue
            value = max(candidates, key=lambda v: (instant(v['run_created_at_utc']), int(v['run_id']), v['attempt']))
            if value['status'] != 'completed' or value['conclusion'] != 'success' or not value['execution_verified']:
                continue
            if not check_evidence_ok(pl, req, value, subject, fs, True):
                continue
            if req['checkout_binding'] == 'head' and value['tested_checkout_sha'] != subject:
                continue
            if req['checkout_binding'] == 'pr_merge':
                binding = typed(fs, observation['pull_request_binding_ref'], 'GitPullRequestBinding')
                if (value['pr_head_sha'], value['pr_base_sha'], value['tested_merge_sha'], value['tested_checkout_sha']) != (subject, binding['base_sha'], binding['tested_merge_sha'], binding['tested_merge_sha']):
                    continue
            expected_reported = subject if req['reported_sha_binding'] == 'subject' else value['tested_checkout_sha']
            if value['reported_head_sha'] == expected_reported:
                proven.add(event)
    return proven


_live169 = live_verification_ok


def live_verification_ok(at, pl, co, po, verification, fs, context, live_remote, archived_fs):
    if not _live169(at, pl, co, po, verification, fs, context, live_remote, archived_fs):
        return False
    current = typed(fs, verification['closing_observation_ref'], 'GitDeliveryObservation')
    return canary_ok(at, pl, po, co, archived_fs, extra_observations=[(current, fs)])


_commit169 = commit_ok


def commit_ok(record, at, parents, fs, phase):
    if phase != 'payload' or at['payload_mode'] != 'verified_noop':
        return _commit169(record, at, parents, fs, phase)
    # Reused P is existing Git history, not a newly authored payload message.
    # Its original scope and actual raw snapshot remain unchanged and checked.
    if not gv('GitCommit', record):
        return False
    scope = typed(fs, record['scope_ref'], 'GitCommitScopeEvidence')
    if scope['phase'] == 'payload':
        return _commit169(record, at, parents, fs, 'payload')
    trailers = parse_delivery_trailers(record['body'])
    original_parents = parents.get(record['sha'])
    if scope['phase'] != 'closing' or not trailers or len(scope['task_ids']) != 1 or original_parents is None or len(original_parents) != 1:
        return False
    if trailers['MCE4D-Delivery-ID'] == at['delivery_id'] or original_parents[0] == record['sha']:
        return False
    original = {**at, 'task_id': scope['task_ids'][0], 'priority': scope['priority'], 'delivery_id': trailers['MCE4D-Delivery-ID'], 'verified_payload_sha': original_parents[0]}
    return _commit169(record, original, parents, fs, 'closing')


_checkpoint169 = checkpoint_ok


def checkpoint_ok(value, selector, actual, fs):
    """The secured caller supplies the current command identity, never the cache."""
    try:
        fields = ['command_record_ref', 'command_record_sha256', 'lifecycle_id', 'retry_index', 'push_operation_ref']
        if any(key not in actual for key in fields):
            return False
        if actual['operation_id'] is None:
            if any(actual[key] is not None for key in fields):
                return False
        else:
            if type(actual['retry_index']) is not int or not 0 <= actual['retry_index'] <= 9007199254740991:
                return False
            if value['command_record_ref'] != actual['command_record_ref']:
                return False
            command = typed(fs, actual['command_record_ref'], 'GitCommandLifecycle')
            if hashlib.sha256(fs[actual['command_record_ref']]).hexdigest() != actual['command_record_sha256']:
                return False
            if any(command[key] != actual[key] for key in ['operation_id', 'lifecycle_id', 'retry_index']):
                return False
            ref = actual['push_operation_ref']
            if ref is not None:
                operation = typed(fs, ref, 'GitPushOperationEvidence')
                if operation['push_operation_id'] != command['operation_id'] or operation['command_record_ref'] != actual['command_record_ref'] or any(operation[key] != command[key] for key in ['lifecycle_id', 'retry_index']):
                    return False
        return _checkpoint169(value, selector, actual, fs)
    except (ValueError, KeyError, TypeError, OverflowError):
        return False
