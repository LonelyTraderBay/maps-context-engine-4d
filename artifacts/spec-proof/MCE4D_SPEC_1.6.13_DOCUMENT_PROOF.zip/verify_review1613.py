"""Retained v1.6.12 audit counterexamples and typed-input regressions.

These use synthetic immutable fixtures only. They do not invoke Git, GitHub,
process ownership, or product code. Every mutation is made before evaluation;
the evaluator must neither repair evidence nor mutate its inputs.
"""


def verify_review1613():
    start_count = len(checks)
    cases = []

    def outcome(call):
        try:
            return call()
        except Exception as exc:
            return dict(exception=type(exc).__name__, message=str(exc))

    def record(name, actual, expected, group, immutable=True, retained=False):
        # A boolean result must actually be bool, not Python's equal int alias.
        matches = type(actual) is bool and actual is expected if type(expected) is bool else exact_json_equal(actual, expected)
        value = dict(name=name, actual=actual, expected=expected, group=group,
                     immutable=immutable, retained=retained, match=matches and immutable)
        cases.append(value)
        ck('Z ' + group + ' ' + name, value['match'])

    def evaluate_case(name, x, expected, group, retained=False):
        frozen = copy.deepcopy(x)
        actual = outcome(lambda: evaluate169(x))
        record(name, actual, expected, group, x == frozen, retained)

    def input_json(value, noncanonical_float=False):
        # Float members are intentional raw JSON negatives: C14 correctly
        # refuses to construct them, so retain bytes from an external producer.
        # The loader must reject these before any typed object projection.
        if noncanonical_float:
            return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
        return C14(value)

    def rationale_fixture(purpose, reason):
        x = prepared169()
        rec = x['at']['ordered_commits'][0]
        scope = typed(x['fs'], rec['scope_ref'], 'GitCommitScopeEvidence')
        subject, body = rec['subject'], rec['body']
        ref = 'probe/' + purpose + '.json'
        if purpose == 'priority':
            scope.update(priority='P2', priority_reason_ref=ref)
            subject = subject.replace('[P1]', '[P2]')
            rationale = dict(kind='priority_rationale', task_id=x['at']['task_id'], priority='P2', reason=reason)
        elif purpose == 'shared':
            scope.update(task_ids=['T001', 'T002'], shared_invariant_ref=ref)
            subject = subject.replace('[T001]', '[T001,T002]')
            rationale = dict(kind='shared_invariant', task_ids=scope['task_ids'], reason=reason)
        else:
            scope.update(breaking_decision_ref=ref)
            subject = subject.replace(': [', '!: [')
            body += '\nBREAKING CHANGE: Thay đổi hợp đồng đã được chấp thuận.'
            rationale = dict(kind='breaking_decision', reason=reason)
        x['fs'][ref] = input_json(rationale, type(reason) is float)
        x['fs'][rec['scope_ref']] = C14(scope)
        change_commit169(x, 'payload', 'subject', subject)
        change_commit169(x, 'payload', 'body', body)
        return x

    # Original 128 CI probes: names, expectations and isolated mutation roles
    # retained. The end-of-run digest independently pins the original oracle.
    for pr in [False, True]:
        x = prepared169(pr=pr)
        frozen = copy.deepcopy(x)
        value = outcome(lambda: evaluate169(x))
        record('baseline composed ' + str(pr), value, True, 'retained-ci', x == frozen, True)
        record('baseline immutable ' + str(pr), x == frozen, True, 'retained-ci', retained=True)

    for purpose in ['priority', 'shared', 'breaking']:
        for reason in ['Giải thích phạm vi đã được kiểm tra.', True, 1, [], {}, '   ', None]:
            x = rationale_fixture(purpose, reason)
            frozen = copy.deepcopy(x)
            actual = outcome(lambda: evaluate169(x))
            expected = isinstance(reason, str) and bool(reason.strip())
            record(purpose + ' reason ' + repr(reason), actual, expected, 'retained-ci', x == frozen, True)
            record(purpose + ' immutable ' + repr(reason), x == frozen, True, 'retained-ci', retained=True)

    for phase in ['payload', 'closing']:
        for flag in ['--force', '--force-with-lease', '--all', '--mirror', '--delete', '--tags', '--no-verify', '-f', '--follow-tags']:
            x = prepared169()
            observation = x['po'] if phase == 'payload' else x['ob']
            op = typed(x['fs'], observation['destination_observation']['operation_evidence_ref'], 'GitPushOperationEvidence')
            command = typed(x['fs'], op['command_record_ref'], 'GitCommandLifecycle')
            command['contract']['argv'].insert(2, flag)
            x['fs'][op['command_record_ref']] = C14(command)
            retain169(x)
            evaluate_case(phase + ' forbidden push ' + flag, x, False, 'retained-ci', True)
        for mode in ['branch-ref', 'sha-ref', 'porcelain', 'atomic', 'porcelain-atomic', 'force-ref', 'wrong-remote', 'wrong-branch', 'wrong-sha']:
            x = prepared169()
            observation = x['po'] if phase == 'payload' else x['ob']
            op = typed(x['fs'], observation['destination_observation']['operation_evidence_ref'], 'GitPushOperationEvidence')
            command = typed(x['fs'], op['command_record_ref'], 'GitCommandLifecycle')
            repository = x['pl']['repository']
            ref, remote, options = observation['subject_sha'] + ':' + repository['ref'], repository['remote_name'], []
            if mode == 'branch-ref': ref = repository['ref']
            if mode in ['porcelain', 'porcelain-atomic']: options += ['--porcelain']
            if mode in ['atomic', 'porcelain-atomic']: options += ['--atomic']
            if mode == 'force-ref': ref = '+' + ref
            if mode == 'wrong-remote': remote = 'other'
            if mode == 'wrong-branch': ref = observation['subject_sha'] + ':refs/heads/other'
            if mode == 'wrong-sha': ref = '7' * 40 + ':' + repository['ref']
            command['contract']['argv'] = ['git', 'push', *options, remote, ref]
            x['fs'][op['command_record_ref']] = C14(command)
            retain169(x)
            evaluate_case(phase + ' normal refspec ' + mode, x, mode not in ['force-ref', 'wrong-remote', 'wrong-branch', 'wrong-sha'], 'retained-ci', True)

    for status, conclusion in [('queued', 'unknown'), ('in_progress', 'unknown'), ('completed', 'failure'), ('completed', 'success')]:
        for mode in ['foreign-id', 'wrong-context', 'wrong-matrix', 'wrong-app']:
            x = prepared169()
            observation = typed(x['lf'], x['live']['closing_observation_ref'], 'GitDeliveryObservation')
            value = copy.deepcopy(observation['checks'][0])
            value.update(run_id='99001', job_id='99002', status=status, conclusion=conclusion, execution_verified=conclusion == 'success')
            if mode == 'foreign-id': value['check_id'] = 'unknown-probe'
            if mode == 'wrong-context': value['context'] = 'unknown-probe'
            if mode == 'wrong-matrix': value['matrix'] = {'os': 'windows'}
            if mode == 'wrong-app': value['source_app'] = 'github.com:app:99999'
            put_check_evidence(x['lf'], value, C, 'probe-' + mode + '-' + status, req=x['pl']['checks'][0])
            observation['checks'].append(value)
            make_collection_fixture(x['pl'], observation, x['lf'], x['live']['started_at_utc'], x['live']['completed_at_utc'])
            x['lf'][x['live']['closing_observation_ref']] = C14(observation)
            x['live']['files'] = manifest_for(x['lf'])
            evaluate_case('latest mapping ' + status + ' ' + mode, x, False, 'retained-ci', True)

    def wrong_root_fixture(layer, value):
        x = prepared169()
        raw = input_json(value, type(value) is float)
        if layer == 'ci-page':
            observation = typed(x['lf'], x['live']['closing_observation_ref'], 'GitDeliveryObservation')
            collection = typed(x['lf'], observation['collection_evidence_ref'], 'GitCICollectionEvidence')
            x['lf'][collection['pages'][0]['raw_page_ref']] = raw
            x['live']['files'] = manifest_for(x['lf'])
        elif layer == 'git-parents':
            x['fs'][x['ar']['git_evidence_ref']] = raw
            retain169(x)
        elif layer == 'live-git-parents':
            x['lf'][x['live']['git_evidence_ref']] = raw
            x['live']['files'] = manifest_for(x['lf'])
        elif layer == 'noop-reason':
            x['current_pr'] = {'closing': None}
            later_task169(x)
            x['fs'][x['at']['noop_reason_ref']] = raw
            retain169(x)
        else:
            purpose = {'priority-rationale': 'priority', 'shared-invariant': 'shared', 'breaking-decision': 'breaking'}[layer]
            x = rationale_fixture(purpose, 'Giải thích phạm vi đã được kiểm tra.')
            x['fs']['probe/' + purpose + '.json'] = raw
            retain169(x)
        return x

    for value in [[], True, 1, None, 'not an object']:
        for layer in ['ci-page', 'priority-rationale', 'shared-invariant', 'breaking-decision', 'noop-reason', 'git-parents']:
            evaluate_case(layer + ' canonical wrong top-level ' + repr(value), wrong_root_fixture(layer, value), False, 'retained-ci', True)

    # Original 8 resume audit probes with the same expected decisions.
    x = prepared169()
    destination = x['ob']['destination_observation']
    op = typed(x['fs'], destination['operation_evidence_ref'], 'GitPushOperationEvidence')
    checkpoint = {**valid_checkpoint, 'command_record_ref': op['command_record_ref'], 'operation_id': op['push_operation_id'], 'command_state': 'SUCCEEDED'}
    actual = checkpoint_actual_fixture({**actual_checkpoint, 'operation_id': op['push_operation_id'], 'command_state': 'SUCCEEDED'}, op['command_record_ref'], x['fs'], destination['operation_evidence_ref'])

    def checkpoint_case(name, current, expected, retained=False, candidate=checkpoint, fixture=x):
        frozen = copy.deepcopy((candidate, fixture['sel'], current, fixture['fs']))
        result = outcome(lambda: checkpoint_ok(candidate, fixture['sel'], current, fixture['fs']))
        record(name, result, expected, 'retained-resume' if retained else 'V1612-01',
               frozen == (candidate, fixture['sel'], current, fixture['fs']), retained)

    for name, retry, expected in [
        ('unchanged exact secured context', 0, True),
        ('boolean false is not integer zero retry identity', False, False),
        ('float zero is not integer zero retry identity', 0.0, False),
        ('wrong integer retry identity', 1, False),
        ('string zero is not integer zero retry identity', '0', False)]:
        checkpoint_case(name, {**actual, 'retry_index': retry}, expected, True)
    pending = {k: x['at'][k] for k in ['delivery_id', 'task_revision']}
    facts = dict(boundary='suspended_external_blocker', **pending, effective_done=False, suspension_ref='suspension/retained.json', operation_settled=True)
    frozen = copy.deepcopy((pending, facts))
    record('settled supplied suspension chooses independent work', outcome(lambda: delivery_resume_stage('suspended_external_blocker', pending, facts)), 'resolve_independent_ready', 'retained-resume', frozen == (pending, facts), True)
    historical_args = (x['at'], x['pl'], x['ob'], x['ar'], x['fs'], [x['ca']], ['S19/T001/Status'], Q)
    frozen = copy.deepcopy(x)
    record('old sealed archive remains historical after remote advances', outcome(lambda: effective_done(*historical_args, offline=True, sel=x['sel'], seal_record=seal_for(x['ar']), published=True)), True, 'retained-resume', x == frozen, True)
    record('old C current closure rejects advanced ref', outcome(lambda: effective_done(*historical_args, sel=x['sel'], seal_record=seal_for(x['ar']), published=True, live_verification=x['live'], live_files=x['lf'], live_context=x['ctx'])), False, 'retained-resume', x == frozen, True)

    for retry in [True, 1.0, -1, 9007199254740992, None, [], {}]:
        checkpoint_case('secured retry rejects type/range ' + repr(retry), {**actual, 'retry_index': retry}, False)
    checkpoint_case('secured allocated context requires retry field', {key: value for key, value in actual.items() if key != 'retry_index'}, False)
    for retry in [1, 9007199254740991]:
        fixture = prepared169()
        destination = fixture['ob']['destination_observation']
        operation = typed(fixture['fs'], destination['operation_evidence_ref'], 'GitPushOperationEvidence')
        command = typed(fixture['fs'], operation['command_record_ref'], 'GitCommandLifecycle')
        command['retry_index'] = operation['retry_index'] = retry
        for boundary in ['preflight', 'postflight']:
            operation[boundary]['retry_index'] = retry
            raw_ref = operation[boundary]['raw_api_ref']
            raw = load_member(fixture['fs'], raw_ref)
            raw['retry_index'] = retry
            fixture['fs'][raw_ref] = C14(raw)
        fixture['fs'][operation['command_record_ref']] = C14(command)
        fixture['fs'][destination['operation_evidence_ref']] = C14(operation)
        candidate = {**valid_checkpoint, 'command_record_ref': operation['command_record_ref'], 'operation_id': operation['push_operation_id'], 'command_state': 'SUCCEEDED'}
        current = checkpoint_actual_fixture({**actual_checkpoint, 'operation_id': operation['push_operation_id'], 'command_state': 'SUCCEEDED'}, operation['command_record_ref'], fixture['fs'], destination['operation_evidence_ref'])
        checkpoint_case('secured retry exact valid integer ' + str(retry), current, True, candidate=candidate, fixture=fixture)

    for purpose in ['priority', 'shared', 'breaking']:
        for reason in [False, 0, 0.0, '', '\t\r\n']:
            label = ' noncanonical float reason ' if type(reason) is float else ' typed blank reason '
            evaluate_case(purpose + label + repr(reason), rationale_fixture(purpose, reason), False, 'V1612-02')
        x = rationale_fixture(purpose, 'Giải thích phạm vi đã được kiểm tra.')
        ref = 'probe/' + purpose + '.json'
        reason = load_member(x['fs'], ref)
        del reason['reason']
        x['fs'][ref] = C14(reason)
        retain169(x)
        evaluate_case(purpose + ' rationale requires reason field', x, False, 'V1612-02')
        x = rationale_fixture(purpose, 'Giải thích phạm vi đã được kiểm tra.')
        reason = load_member(x['fs'], ref)
        if purpose == 'priority': reason['task_id'] = 'T003'
        elif purpose == 'shared': reason['task_ids'] = ['T001', 'T003']
        else: reason['kind'] = 'unrelated_decision'
        x['fs'][ref] = C14(reason)
        retain169(x)
        evaluate_case(purpose + ' valid text cannot bypass rationale identity', x, False, 'V1612-02')

    for value in [[], True, 1, None, 'not an object']:
        evaluate_case('live Git parents wrong root ' + repr(value), wrong_root_fixture('live-git-parents', value), False, 'V1612-03')
    noop = prepared169()
    noop['current_pr'] = {'closing': None}
    later_task169(noop)
    evaluate_case('verified no-op composed valid control', noop, True, 'V1612-03')
    for reason in [True, False, 1, 0, 0.0, [], {}, None, '', '   ']:
        fixture = copy.deepcopy(noop)
        ref = fixture['at']['noop_reason_ref']
        value = load_member(fixture['fs'], ref)
        value['reason'] = reason
        fixture['fs'][ref] = input_json(value, type(reason) is float)
        retain169(fixture)
        label = 'verified no-op rejects noncanonical float reason ' if type(reason) is float else 'verified no-op rejects nontext/blank reason '
        evaluate_case(label + repr(reason), fixture, False, 'V1612-03')
    fixture = copy.deepcopy(noop)
    ref = fixture['at']['noop_reason_ref']
    reason = load_member(fixture['fs'], ref)
    del reason['reason']
    fixture['fs'][ref] = C14(reason)
    retain169(fixture)
    evaluate_case('verified no-op requires reason field', fixture, False, 'V1612-03')
    for kind, value in [('false', False), ('zero', 0), ('noncanonical-float-zero', 0.0), ('empty', '')]:
        for layer in ['ci-page', 'priority-rationale', 'shared-invariant', 'breaking-decision', 'noop-reason', 'git-parents', 'live-git-parents']:
            evaluate_case(layer + ' additional wrong root ' + kind, wrong_root_fixture(layer, value), False, 'V1612-03')

    def selection_case(name, fixture, expected):
        frozen = copy.deepcopy(fixture)
        actual = outcome(lambda: selection_ok(fixture['sel'], fixture['at'], fixture['fs']))
        record(name, actual, expected, 'V1612-03', fixture == frozen)

    selection_case('revision invalidation valid typed control', revision166(), True)
    for value in [[], True, 1, None, 'not an object']:
        fixture = revision166()
        fixture['fs']['invalidation.json'] = C14(value)
        selection_case('revision invalidation wrong root ' + repr(value), fixture, False)
    for reason in [True, 1, '   ', None]:
        fixture = revision166()
        invalidation = load_member(fixture['fs'], 'invalidation.json')
        invalidation['reason'] = reason
        fixture['fs']['invalidation.json'] = C14(invalidation)
        selection_case('revision invalidation requires text reason ' + repr(reason), fixture, False)

    record('nullable identity must be present', reason_ok({'kind':'delivery_invalidation','reason':'Lý do hợp lệ.'}, 'delivery_invalidation', new_delivery_id=None), False, 'V1612-03')
    record('explicit nullable identity remains valid', reason_ok({'kind':'delivery_invalidation','reason':'Lý do hợp lệ.','new_delivery_id':None}, 'delivery_invalidation', new_delivery_id=None), True, 'V1612-03')
    retained = [v for v in cases if v['retained']]
    retained_oracle_sha256 = hashlib.sha256(json.dumps([[v['name'], v['expected']] for v in retained], ensure_ascii=False, separators=(',', ':')).encode('utf-8')).hexdigest()
    ck('Z original 128 CI plus 8 resume probes retained', len(retained) == 136 and sum(v['group'] == 'retained-ci' for v in retained) == 128 and sum(v['group'] == 'retained-resume' for v in retained) == 8 and retained_oracle_sha256 == '0f804b6f5464452719e09913d1ac5908eda228c2d1dc30be3aa86e1115750306')
    result = dict(spec_version='1.6.13', groups_closed=['V1612-01', 'V1612-02', 'V1612-03'],
                  retained_ci_probes=128, retained_resume_probes=8, retained_oracle_sha256=retained_oracle_sha256,
                  prior_false_acceptances_corrected=11, prior_uncaught_exceptions_corrected=30,
                  probe_count=len(cases), current_mismatches=sum(not v['match'] for v in cases),
                  new_assertions=len(checks) - start_count, cases=cases,
                  scope='Document/pure-reference only; actual product/Git/GitHub/CI/process ownership NOT_RUN.')
    (run/'review-1.6.13-validation.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')


verify_review1613()
