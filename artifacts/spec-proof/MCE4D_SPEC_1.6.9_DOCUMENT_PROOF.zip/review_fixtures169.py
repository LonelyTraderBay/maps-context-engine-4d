"""Synthetic fixtures migrated from the immutable v168 review reproduction. No normative guard calls these constructors."""
def prepared169(pr=False):
    x = fixture166()
    if pr:
        pr166(x)
    rebind166(x)
    x['live'], x['lf'], x['ctx'] = make_live_fixture(x['at'], x['pl'], x['ob'], x['ar'], x['fs'], x['current_pr']['closing'] if x['current_pr'] else None)
    return x

def evaluate169(x):
    return effective_done(x['at'], x['pl'], x['ob'], x['ar'], x['fs'], [x['ca']], ['S19/'+x['at']['task_id']+'/Status'], C, sel=x['sel'], seal_record=x.get('seal', seal_for(x['ar'])), published=True, live_verification=x['live'], live_files=x['lf'], live_context=x['ctx'])

def retain169(x):
    x['fs'][x['ar']['attempt_ref']] = C14(x['at'])
    x['ar']['files'] = manifest_for(x['fs'])
    rehash_publication_fixture(x['ar'], x.get('live'), x.get('ctx'))

def change_commit169(x, phase, field, value):
    rec = x['at']['ordered_commits'][0] if phase == 'payload' else typed(x['fs'], x['ar']['closing_commit_ref'], 'GitCommit')
    raw = load_member(x['fs'], rec['git_evidence_ref'])
    rec[field] = raw[field] = value
    x['fs'][rec['git_evidence_ref']] = C14(raw)
    if phase == 'closing':
        x['fs'][x['ar']['closing_commit_ref']] = C14(rec)
    retain169(x)

def current_base169(x, reuse):
    lf = x['lf']
    o = typed(lf, x['live']['closing_observation_ref'], 'GitDeliveryObservation')
    v = typed(lf, o['pull_request_binding_ref'], 'GitPullRequestBinding')
    newbase = '8' * 40
    merge = '9' * 40
    v.update(base_sha=newbase, tested_merge_sha=merge)
    for ref in [o['pull_request_binding_ref'], x['live']['current_pr_ref']]:
        lf[ref] = C14(v)
    lf[v['api_evidence_ref']] = C14({'kind': 'pull_request_api_snapshot', **{k: v for k, v in v.items() if k not in ['format_version', 'kind', 'api_evidence_ref']}})
    parents = load_member(lf, x['live']['git_evidence_ref'])
    parents.update({newbase: [], merge: [newbase, C]})
    lf[x['live']['git_evidence_ref']] = C14(parents)
    for value in o['checks']:
        value.update(pr_base_sha=newbase, tested_merge_sha=merge, tested_checkout_sha=merge)
        if not reuse:
            value.update(run_id='7000', job_id='8000')
        put_check_evidence(lf, value, C, 'live-new-base', req=x['pl']['checks'][0])
    make_collection_fixture(x['pl'], o, lf, x['live']['started_at_utc'], x['live']['completed_at_utc'])
    lf[x['live']['closing_observation_ref']] = C14(o)
    x['live']['files'] = manifest_for(lf)

def historical_canary169(x, unrelated=False, validpr=False):
    old = prepared169(pr=validpr)
    oldplan = old['pl']
    oldpo = old['po']
    oldfs = old['fs']
    oldpo['delivery_id'] = U2
    oldplan['canary_ref'] = 'delivery:' + U2 + ':payload'
    for v in oldpo['checks']:
        v.update(run_id='9000', job_id='9100')
        put_check_evidence(oldfs, v, P, 'historical-canary', req=oldplan['checks'][0])
    if unrelated:
        v = {**copy.deepcopy(oldpo['checks'][0]), 'check_id': 'unrelated-pr', 'context': 'unrelated-pr', 'workflow_path': '.github/workflows/unrelated.yml', 'job_name': 'unrelated-pr', 'run_id': '9001', 'job_id': '9101', 'event': 'pull_request', 'status': 'queued', 'conclusion': 'unknown', 'execution_verified': False}
        put_check_evidence(oldfs, v, P, 'historical-unrelated')
        oldpo['checks'].append(v)
    make_collection_fixture(oldplan, oldpo, oldfs)
    canaryfiles = copy.deepcopy(oldfs)
    refs = {name: 'canary/' + name for name in canaryfiles}

    def rename(v):
        if isinstance(v, str):
            return refs.get(v, v)
        if isinstance(v, list):
            return [rename(a) for a in v]
        if isinstance(v, dict):
            return {k: rename(a) for k, a in v.items()}
        return v
    for name, data in canaryfiles.items():
        try:
            x['fs'][refs[name]] = C14(rename(json.loads(data)))
        except (UnicodeDecodeError, ValueError):
            x['fs'][refs[name]] = data
    planref = 'canary-historical-plan.json'
    obsref = 'canary-historical-payload.json'
    x['fs'][planref] = C14(rename(oldplan))
    oldpo = rename(oldpo)
    oldpo['check_plan_sha256'] = hashlib.sha256(C14(rename(oldplan))).hexdigest()
    coll = typed(x['fs'], oldpo['collection_evidence_ref'], 'GitCICollectionEvidence')
    coll['check_plan_sha256'] = oldpo['check_plan_sha256']
    x['fs'][oldpo['collection_evidence_ref']] = C14(coll)
    x['fs'][obsref] = C14(oldpo)
    x['fs']['canary-evidence.json'] = C14({'format_version': 1, 'kind': 'canary', 'credential_class': oldplan['credential_class'], 'check_plan_ref': planref, 'observation_ref': obsref, 'git_evidence_ref': refs['git.json']})
    x['pl'].update(phase='foundation', canary_ref='canary-evidence.json')
    rebind166(x)
    x['live'], x['lf'], x['ctx'] = make_live_fixture(x['at'], x['pl'], x['ob'], x['ar'], x['fs'], x['current_pr']['closing'])
    return oldpo

def later_task169(x):
    for row in [x['at'], x['ar'], x['sel']]:
        row['task_id'] = 'T002'
    x['at'].update(payload_mode='verified_noop', base_sha=P, noop_reason_ref='t002-noop.json')
    x['fs']['t002-noop.json'] = C14({'kind': 'verified_noop_reason', **{k: x['at'][k] for k in ['assignment_ref', 'task_id', 'delivery_id', 'verified_payload_sha']}, 'reason': 'Tái kiểm payload đã tồn tại cho task kế tiếp, không có thay đổi nguồn.'})
    for ref in x['at']['local_evidence_refs']:
        v = load_member(x['fs'], ref)
        v['task_id'] = 'T002'
        x['fs'][ref] = C14(v)
    for o in [x['po'], x['ob']]:
        bind_command_fixture_identity(x['at'], o, x['fs'])
    rec = typed(x['fs'], x['ar']['closing_commit_ref'], 'GitCommit')
    scope = typed(x['fs'], rec['scope_ref'], 'GitCommitScopeEvidence')
    scope['task_ids'] = ['T002']
    x['fs'][rec['scope_ref']] = C14(scope)
    change_commit169(x, 'closing', 'subject', rec['subject'].replace('[T001]', '[T002]'))
    x['fs'][x['ar']['selection_ref']] = C14(x['sel'])
    retain169(x)
    x['live'], x['lf'], x['ctx'] = make_live_fixture(x['at'], x['pl'], x['ob'], x['ar'], x['fs'], x['current_pr']['closing'])
