"""Synthetic v168 fixtures, explicit test input construction only."""

def command_fixture(checkpoint_like=None,op=None,destination=None,at=None):
    cp=checkpoint_like or {};a=at or attempt
    state=cp.get('command_state','SUCCEEDED');oid=cp.get('operation_id',op['push_operation_id'] if op else UP)
    contract={'command_id':'fixture/git-push','task_mode':'verify','owner':'AI','baseline_ref':'fixture/baseline','executable':'git','argv':['git','push',destination['repository']['remote_name'],destination['candidate_sha']+':'+destination['repository']['ref']] if destination else ['git','status'],'cwd':'fixture/workspace','tool_versions':{'git':'fixture-pinned'},'command_source_ref':'fixture/pinned-command','input_refs':['plan.json'],'contracts':['S51','COMMAND-LIFECYCLE-01'],'fingerprints':{'baseline':'1'*64},'expected_writes':[],'temporary_roots':[],'cache_roots':[],'log_roots':['fixture/logs'],'download_roots':[],'network_scope':['https://github.com/fixture/mce4d-fixture'] if destination else [],'child_processes':[],'side_effect_class':'external_service' if destination else 'read_only','permission_ref':'fixture-assignment','storage_mode':'bounded_small','volumes':[],'budget_refs':[],'retention_ref':'fixture/retain','deadline_at_utc':op['deadline_at_utc'] if op else '2026-10-15T03:01:00Z','monitor_interval_ms':1000,'run_id':oid,'output_root':'fixture/output','cleanup_plan_ref':'fixture/no-cleanup','cleanup_permission_ref':None}
    result={'started_at_utc':None if state=='NOT_STARTED' else op['lifecycle_started_at_utc'] if op else before,'completed_at_utc':now if state in ['SUCCEEDED','FAILED'] else None,'command_exit_status':0 if state=='SUCCEEDED' else 1 if state=='FAILED' else None,'termination_reason':'not_started' if state=='NOT_STARTED' else 'unknown' if state=='UNKNOWN' else 'completed' if state in ['SUCCEEDED','FAILED'] else 'running','cleanup_status':'NOT_REQUIRED','final_status':state,'outputs_created':[],'artifact_refs':[]}
    return {'format_version':1,'kind':'command_lifecycle','operation_id':oid,'lifecycle_id':op['lifecycle_id'] if op else str(uuid.uuid5(uuid.UUID(oid),'lifecycle')),'retry_index':op['retry_index'] if op else 0,**{k:cp.get(k,a[k]) for k in ['assignment_ref','task_id','task_revision','delivery_id']},'command_state':state,'contract':contract,'result':result}


def bind_command_fixture_identity(at,o,fs):
    op=typed(fs,o['destination_observation']['operation_evidence_ref'],'GitPushOperationEvidence');cmd=load_member(fs,op['command_record_ref'])
    for k in ['assignment_ref','task_id','task_revision','delivery_id']:cmd[k]=at[k]
    fs[op['command_record_ref']]=C14(cmd)


def install_commit_fixtures(at,ar,fs):
    parents=load_member(fs,ar['git_evidence_ref'])
    body='Mục đích: Giữ bằng chứng kiểm tra tài liệu.\nThay đổi: Đồng bộ hợp đồng và bộ kiểm chứng.\nKiểm tra: Kiểm chứng tham chiếu cục bộ; sản phẩm và GitHub chưa chạy.'
    for commit in at['ordered_commits']:
        commit.setdefault('body',body);commit.setdefault('git_evidence_ref','commit-'+commit['sha']+'.json')
        scope=load_member(fs,commit['scope_ref']) if commit['scope_ref'] in fs and load_member(fs,commit['scope_ref']).get('kind')=='commit_scope' else None
        if scope is None:
            scope={'format_version':1,'kind':'commit_scope','phase':'payload','task_ids':[at['task_id']],'priority':at['priority'],'priority_reason_ref':None,'shared_invariant_ref':None,'breaking_decision_ref':None,'changed_paths':['Maps-Context-Engine-4D_SPEC.md']}
            fs[commit['scope_ref']]=C14(scope)
        fs[commit['git_evidence_ref']]=C14({'kind':'git_commit_snapshot','sha':commit['sha'],'parents':parents.get(commit['sha']),'subject':commit['subject'],'body':commit['body'],'changed_paths':scope['changed_paths']})
    ar['closing_commit_ref']='commit-closing.json'
    closing={'sha':ar['closing_sha'],'subject':'docs(progress): ['+at['priority']+']['+at['task_id']+'] Chốt bằng chứng hoàn thành task','body':body+'\n\nMCE4D-Delivery-ID: '+at['delivery_id']+'\nMCE4D-Delivery-Phase: closing','scope_ref':'scope/closing','git_evidence_ref':'git-closing-snapshot.json'}
    scope={'format_version':1,'kind':'commit_scope','phase':'closing','task_ids':[at['task_id']],'priority':at['priority'],'priority_reason_ref':None,'shared_invariant_ref':None,'breaking_decision_ref':None,'changed_paths':['Maps-Context-Engine-4D_SPEC.md']}
    fs[closing['scope_ref']]=C14(scope);fs[closing['git_evidence_ref']]=C14({'kind':'git_commit_snapshot','sha':closing['sha'],'parents':parents.get(closing['sha']),'subject':closing['subject'],'body':closing['body'],'changed_paths':scope['changed_paths']});fs[ar['closing_commit_ref']]=C14(closing)


def make_collection_fixture(pl,o,fs,start=None,end=None):
    start=start or o['observed_at_utc'];end=end or o['observed_at_utc']
    ref=o.get('collection_evidence_ref','collection-'+o['phase']+'-'+o['delivery_id']+'.json');identity=str(uuid.uuid5(uuid.UUID(o['delivery_id']),ref+'|'+start));pages=[]
    sources={v['source_evidence_ref']:typed(fs,v['source_evidence_ref'],'GitCheckSourceEvidence') for v in o['checks']};shas={o['subject_sha']}
    if o.get('pull_request_binding_ref') is not None:shas.add(typed(fs,o['pull_request_binding_ref'],'GitPullRequestBinding')['tested_merge_sha'])
    groups={}
    for source_ref,x in sources.items():
        if x['source_kind']!='actions_check_run' or x['workflow_head_sha'] not in shas:continue
        key=(x['run_id'],x['attempt'])
        row=groups.setdefault(key,{'run_id':x['run_id'],'run_attempt':x['attempt'],'head_sha':x['workflow_head_sha'],'workflow_path':x['workflow_path'],'event':x['event'],'created_at':x['created_at_utc'],'status':'completed','conclusion':'success','job_source_refs':[]})
        row['job_source_refs'].append(source_ref)
        if x['native_status']!='completed':row.update(status='in_progress',conclusion=None)
        elif x['native_conclusion']!='success' and row['status']=='completed':row['conclusion']=x['native_conclusion']
    latest={}
    for (rid,attemptno),row in groups.items():
        if rid not in latest or attemptno>latest[rid]['run_attempt']:latest[rid]=row
    targets=[(endpoint,sha,None,None) for sha in sorted(shas) for endpoint in ['check_runs','commit_statuses']]
    if any(req['workflow_path'] is not None for req in pl['checks']):
        targets.extend(('workflow_runs',sha,None,None) for sha in sorted(shas))
        targets.extend(('workflow_run_attempt',row['head_sha'],rid,attemptno) for (rid,attemptno),row in groups.items() if attemptno<latest[rid]['run_attempt'])
    for endpoint,sha,rid,attemptno in targets:
        suffix=endpoint+'|'+sha+'|'+str(rid)+'|'+str(attemptno);qid=str(uuid.uuid5(uuid.UUID(identity),suffix));rawref=ref+'-'+suffix.replace('|','-')+'.page.json'
        if endpoint=='workflow_runs':items=[row for row in latest.values() if row['head_sha']==sha]
        elif endpoint=='workflow_run_attempt':items=[groups[(rid,attemptno)]]
        else:items=[source_snapshot(x) for x in sources.values() if x['reported_head_sha']==sha and (x['source_kind']=='commit_status')==(endpoint=='commit_statuses')]
        page={'query_id':qid,'endpoint':endpoint,'requested_sha':sha,'workflow_run_id':rid,'workflow_run_attempt':attemptno,'page_number':1,'next_page_number':None,'raw_page_ref':rawref}
        fs[rawref]=C14({'kind':'ci_api_page',**{k:v for k,v in page.items() if k!='raw_page_ref'},'state_filter':'all','observed_at_utc':end,'items':items});pages.append(page)
    value={'format_version':1,'kind':'ci_collection','collection_id':identity,'host':pl['repository']['host'],'repository_id':pl['repository']['repository_id'],'subject_sha':o['subject_sha'],'check_plan_sha256':hashlib.sha256(C14(pl)).hexdigest(),'started_at_utc':start,'completed_at_utc':end,'pages':pages}
    fs[ref]=C14(value);o['collection_evidence_ref']=ref
    return value
