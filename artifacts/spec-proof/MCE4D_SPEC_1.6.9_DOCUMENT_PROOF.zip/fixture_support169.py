"""Explicit synthetic publication input only; never invoked by normative guards."""
_live_fixture168 = make_live_fixture


def publication_fixture(at,ar,seal_record,published_at=None,readback_at=None):
    return {'format_version':1,'kind':'archive_publication','planned_archive_path':at['planned_archive_path'],'archive_manifest_sha256':hashlib.sha256(C14(ar)).hexdigest(),'archive_seal_sha256':hashlib.sha256(C14(seal_record)).hexdigest(),'published_at_utc':published_at or seal_record['sealed_at_utc'],'readback_completed_at_utc':readback_at or seal_record['sealed_at_utc']}


def make_live_fixture(at,pl,ob,ar,fs,current_pr=None,identity=None,start=None,end=None):
    value,lf,ctx=_live_fixture168(at,pl,ob,ar,fs,current_pr,identity,start,end)
    value['archive_publication']=publication_fixture(at,ar,seal_for(ar))
    ctx['archive_publication_sha256']=hashlib.sha256(C14(value['archive_publication'])).hexdigest()
    return value,lf,ctx


def rehash_publication_fixture(ar,verification,context=None):
    """Test-only rehash of already supplied facts; no timestamps/evidence invented."""
    if verification is not None and 'archive_publication' in verification:
        verification['archive_publication']['archive_manifest_sha256']=hashlib.sha256(C14(ar)).hexdigest()
        verification['archive_publication']['archive_seal_sha256']=hashlib.sha256(C14(seal_for(ar))).hexdigest()
        if context is not None:context['archive_publication_sha256']=hashlib.sha256(C14(verification['archive_publication'])).hexdigest()
