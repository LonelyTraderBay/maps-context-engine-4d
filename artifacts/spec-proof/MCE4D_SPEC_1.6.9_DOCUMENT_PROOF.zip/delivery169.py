"""v1.6.9 pure document governance guards. No product/Git/network implementation."""

_native168 = native_ledger_ok


def terminal_execution_key(value, fs):
    source = typed(fs, value['source_evidence_ref'], 'GitCheckSourceEvidence')
    return tuple(source[k] for k in ['host','repository_id','source_kind','record_id','run_id','attempt','job_id'])


def terminal_execution_pin(value, fs):
    evidence = typed(fs, value['execution_evidence_ref'], 'GitCheckExecutionEvidence')
    commands = []
    for result in evidence['command_results']:
        # Reference names may change across collection/archive; content may not.
        commands.append((result['command_ref'], result['revision'], result['result'], hashlib.sha256(fs[result['log_ref']]).hexdigest()))
    if len({c[0] for c in commands}) != len(commands):
        raise ValueError('ambiguous execution command')
    return (value['tested_checkout_sha'],value['pr_head_sha'],value['pr_base_sha'],value['tested_merge_sha'],C14(value['matrix']),tuple(sorted(commands)))


def native_ledger_ok(observations):
    if not _native168(observations):return False
    pins = {}
    # Callers supply historical -> current observations. Equal clock ticks can
    # still contain an earlier pending read followed by terminal completion.
    for observation, fs in observations:
        for value in observation['checks']:
            key = terminal_execution_key(value,fs)
            terminal = value['status']=='completed' and value['execution_evidence_ref'] is not None
            if terminal:
                pin = terminal_execution_pin(value,fs)
                if key in pins and pins[key] != pin:return False
                pins[key] = pin
            elif key in pins:return False
    return True


def selected_required(pl, observation):
    return [max([v for v in observation['checks'] if v['check_id']==req['id']],key=lambda v:(instant(v['run_created_at_utc']),int(v['run_id']),v['attempt'])) for req in pl['checks']]


def canary_proven_events(pl, observation, fs):
    proven = set();subject = observation['subject_sha']
    for req in pl['checks']:
        for event in req['eligible_events']:
            candidates = [v for v in observation['checks'] if v['check_id']==req['id'] and v['event']==event]
            if not candidates:continue
            value = max(candidates,key=lambda v:(instant(v['run_created_at_utc']),int(v['run_id']),v['attempt']))
            if value['status']!='completed' or value['conclusion']!='success' or not value['execution_verified']:continue
            if not check_evidence_ok(pl,req,value,subject,fs,True):continue
            if req['checkout_binding']=='head' and value['tested_checkout_sha']!=subject:continue
            if req['checkout_binding']=='pr_merge':
                binding = typed(fs,observation['pull_request_binding_ref'],'GitPullRequestBinding')
                if (value['pr_head_sha'],value['pr_base_sha'],value['tested_merge_sha'],value['tested_checkout_sha']) != (subject,binding['base_sha'],binding['tested_merge_sha'],binding['tested_merge_sha']):continue
            expected_reported = subject if req['reported_sha_binding']=='subject' else value['tested_checkout_sha']
            if value['reported_head_sha']!=expected_reported:continue
            proven.add(event)
    return proven


def archive_time_ok(at, ar, fs, seal_record):
    receipts = {};operations = {}
    for phase in ['payload','closing']:
        receipt = typed(fs,ar[phase+'_observation_ref'],'GitDeliveryObservation')
        operation = typed(fs,receipt['destination_observation']['operation_evidence_ref'],'GitPushOperationEvidence')
        command = typed(fs,operation['command_record_ref'],'GitCommandLifecycle')
        if instant(receipt['observed_at_utc']) < max(instant(operation['postflight']['completed_at_utc']),instant(command['result']['completed_at_utc'])):return False
        receipts[phase]=receipt;operations[phase]=operation
    return instant(receipts['payload']['observed_at_utc'])<=instant(operations['closing']['lifecycle_started_at_utc']) and instant(receipts['closing']['observed_at_utc'])<=instant(ar['created_at_utc'])<=instant(seal_record['sealed_at_utc'])


def publication_ok(at,ar,seal_record,verification):
    p = verification['archive_publication']
    if p['planned_archive_path']!=at['planned_archive_path'] or p['archive_manifest_sha256']!=hashlib.sha256(C14(ar)).hexdigest() or p['archive_seal_sha256']!=hashlib.sha256(C14(seal_record)).hexdigest():return False
    return instant(seal_record['sealed_at_utc'])<=instant(p['published_at_utc'])<=instant(p['readback_completed_at_utc'])<=instant(verification['started_at_utc'])<=instant(verification['completed_at_utc'])


def has_skip_directive(subject,body):
    message = subject+'\n'+body
    if re.search(r'\[(?:skip ci|ci skip|no ci|skip actions|actions skip)\]',message,re.I):return True
    lines=message.replace('\r\n','\n').split('\n')
    for i,line in enumerate(lines):
        if re.match(r'^[ \t]*skip-checks[ \t]*[:=]',line,re.I):
            # Only an explicit single-line false is supported by MCE4D policy.
            if not re.fullmatch(r'[ \t]*skip-checks[ \t]*:[ \t]*false[ \t]*',line,re.I):return True
            if i+1<len(lines) and re.match(r'^[ \t]+\S',lines[i+1]):return True
    return False


def parse_delivery_trailers(body):
    """Pinned closed delivery subset, not an implementation of all Git config."""
    if '\x00' in body:return None
    text = body.replace('\r\n','\n')
    if '\r' in text:return None
    if re.search(r'^---(?:[ \t]|$)',text,re.M):return None
    text = text.rstrip('\n')
    reserved = [line for line in text.split('\n') if re.match(r'^[ \t]*MCE4D-Delivery-',line,re.I)]
    if not reserved:return {}
    blocks = re.split(r'\n[ \t]*\n',text)
    if len(blocks)<2:return None
    trailer_lines=blocks[-1].split('\n')
    if any(not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9-]*: [^\s].*',line) for line in trailer_lines):return None
    values = {}
    for line in reserved:
        if line not in trailer_lines:return None
        match = re.fullmatch(r'(MCE4D-Delivery-ID|MCE4D-Delivery-Phase): ([^\s]+)',line)
        if not match or match[1] in values:return None
        values[match[1]]=match[2]
    if set(values)!={'MCE4D-Delivery-ID','MCE4D-Delivery-Phase'}:return None
    value=values['MCE4D-Delivery-ID']
    if not re.fullmatch(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}',value) or values['MCE4D-Delivery-Phase']!='closing':return None
    return values


_commit168 = commit_ok


def commit_ok(record,at,parents,fs,phase):
    if not gv('GitCommit',record) or has_skip_directive(record['subject'],record['body']):return False
    trailers = parse_delivery_trailers(record['body'])
    if trailers is None:return False
    if phase=='payload' and trailers:return False
    if phase=='closing' and trailers!={'MCE4D-Delivery-ID':at['delivery_id'],'MCE4D-Delivery-Phase':'closing'}:return False
    return _commit168(record,at,parents,fs,phase)


_archive168 = archive_done


def archive_done(at,pl,ob,ar,fs,candidates,changes,live_remote,offline=False,sel=None,seal_record=None,published=False,current_pr=None):
    try:
        return _archive168(at,pl,ob,ar,fs,candidates,changes,live_remote,offline,sel,seal_record,published,current_pr) and archive_time_ok(at,ar,fs,seal_record)
    except (ValueError,KeyError,TypeError,OverflowError):return False


_effective168 = effective_done

_live168 = live_verification_ok


def live_verification_ok(at,pl,co,po,verification,fs,context,live_remote,archived_fs):
    if context is None or set(context)!={'verification_id','started_at_utc','archive_publication_sha256'}:return False
    if context['archive_publication_sha256']!=hashlib.sha256(C14(verification['archive_publication'])).hexdigest():return False
    invocation={k:context[k] for k in ['verification_id','started_at_utc']}
    return _live168(at,pl,co,po,verification,fs,invocation,live_remote,archived_fs)


def effective_done(at,pl,ob,ar,fs,candidates,changes,live_remote,offline=False,sel=None,seal_record=None,published=False,live_verification=None,live_files=None,live_context=None):
    try:
        if not _effective168(at,pl,ob,ar,fs,candidates,changes,live_remote,offline,sel,seal_record,published,live_verification,live_files,live_context):return False
        return offline or publication_ok(at,ar,seal_record,live_verification)
    except (ValueError,KeyError,TypeError,OverflowError):return False
