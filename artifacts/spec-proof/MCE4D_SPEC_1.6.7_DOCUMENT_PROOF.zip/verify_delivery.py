from datetime import datetime

def C14(x):
    return canonical(x)
P = 'a' * 40
C = 'b' * 40
Q = 'c' * 40
M = 'd' * 40
U = '11111111-1111-4111-8111-111111111111'
U2 = '22222222-2222-4222-8222-222222222222'
UP = '33333333-3333-4333-8333-333333333333'
UC = '44444444-4444-4444-8444-444444444444'
now = '2026-10-15T03:00:00Z'
before = '2026-10-15T02:59:59Z'
repo = {'host': 'github.com', 'repository_id': 123, 'owner': 'fixture', 'name': 'mce4d-fixture', 'visibility': 'private', 'publication_authority_ref': None, 'remote_name': 'origin', 'remote_url_sanitized': 'https://github.com/fixture/mce4d-fixture.git', 'ref': 'refs/heads/main'}
check = {'id': 'bootstrap-document', 'kind': 'check_run', 'context': 'bootstrap-document', 'source_app': 'github-actions:15368', 'workflow_path': '.github/workflows/ci.yml', 'job_name': 'bootstrap-document', 'matrix': {}, 'eligible_events': ['push'], 'checkout_binding': 'head', 'reported_sha_binding': 'subject', 'requirement_origins': ['project', 'repository'], 'command_refs': ['local/bootstrap-document']}
plan = {'format_version': 1, 'phase': 'bootstrap', 'repository': repo, 'credential_class': 'local_user', 'required_set_status': 'VERIFIED', 'canary_ref': 'delivery:' + U + ':payload', 'checks': [check], 'merge_checks': [], 'local_check_refs': ['local/bootstrap-document'], 'closing_local_reuse_refs': []}
ph = hashlib.sha256(C14(plan)).hexdigest()
selection = {'format_version': 1, 'assignment_ref': 'fixture-assignment', 'task_id': 'T001', 'task_revision': 1, 'active_delivery_id': U, 'supersedes_delivery_id': None, 'invalidation_refs': [], 'reason_ref': 'assignment:start', 'updated_at_utc': before}
attempt = {'format_version': 1, 'delivery_id': U, 'task_id': 'T001', 'task_revision': 1, 'assignment_ref': 'fixture-assignment', 'priority': 'P1', 'phase': 'closing_proposed', 'payload_mode': 'changes', 'base_sha': None, 'ordered_commits': [{'sha': P, 'subject': 'ci(bootstrap): [P1][T001] Kiểm tra bản vẽ', 'scope_ref': 'scope/t001'}], 'verified_payload_sha': P, 'check_plan_ref': 'plan.json', 'check_plan_sha256': ph, 'local_evidence_refs': ['local.json'], 'payload_observation_ref': 'payload.json', 'closing_marker': 'MCE4D-Delivery-ID: ' + U, 'closing_parent_sha': P, 'planned_archive_path': 'artifacts/git-delivery/' + U, 'archive_staging_path': 'artifacts/git-delivery/.staging-' + U}

def destination(subject, op):
    return {'format_version': 1, 'push_operation_id': op, 'candidate_sha': subject, 'repository': copy.deepcopy(repo), 'local_remote_config_digest': '1' * 64, 'observed_at_utc': before, 'push_started_at_utc': now, 'identity_verified': True, 'visibility_verified': True, 'operation_evidence_ref': 'push-' + op + '-operation.json'}
observed = {'check_id': check['id'], 'kind': 'check_run', 'context': check['context'], 'source_app': check['source_app'], 'workflow_path': check['workflow_path'], 'job_name': check['job_name'], 'matrix': {}, 'event': 'push', 'run_id': '1001', 'run_created_at_utc': now, 'job_id': '2001', 'attempt': 1, 'reported_head_sha': C, 'tested_checkout_sha': C, 'pr_head_sha': None, 'pr_base_sha': None, 'tested_merge_sha': None, 'status': 'completed', 'conclusion': 'success', 'execution_verified': True, 'url': 'https://github.com/fixture/mce4d-fixture/actions/runs/1001', 'evidence_refs': ['check.log']}
observation = {'format_version': 1, 'delivery_id': U, 'phase': 'closing', 'subject_sha': C, 'parent_sha': P, 'check_plan_sha256': ph, 'observed_remote_sha': C, 'observed_at_utc': now, 'binding_verified': True, 'required_set_verified': True, 'checks': [observed], 'result': 'PASS', 'blocker': None, 'merge_group_binding': None, 'destination_observation': destination(C, UC)}
payload_obs = {**observation, 'phase': 'payload', 'subject_sha': P, 'parent_sha': None, 'observed_remote_sha': P, 'checks': [{**observed, 'reported_head_sha': P, 'tested_checkout_sha': P, 'run_id': '1000', 'job_id': '2000'}], 'destination_observation': destination(P, UP)}
local = {'kind': 'local-command-evidence', 'task_id': 'T001', 'revision': P, 'result': 'PASS', 'push_operations': {UP: {'candidate_sha': P, 'remote_config_digest': '1' * 64}, UC: {'candidate_sha': C, 'remote_config_digest': '1' * 64}}}
git_parents = {P: [], C: [P]}
files = {'plan.json': C14(plan), 'attempt.json': C14(attempt), 'selection.json': C14(selection), 'payload.json': C14(payload_obs), 'closing.json': C14(observation), 'check.log': b'fixture check command executed, success', 'local.json': C14(local), 'git.json': C14(git_parents)}

def manifest_for(fs):
    return [{'path': k, 'byte_length': len(v), 'sha256': hashlib.sha256(v).hexdigest()} for k, v in fs.items()]
archive = {'format_version': 1, 'delivery_id': U, 'task_id': 'T001', 'task_revision': 1, 'assignment_ref': 'fixture-assignment', 'verified_payload_sha': P, 'closing_sha': C, 'check_plan_sha256': ph, 'payload_observation_ref': 'payload.json', 'closing_observation_ref': 'closing.json', 'files': manifest_for(files), 'attempt_ref': 'attempt.json', 'selection_ref': 'selection.json', 'git_evidence_ref': 'git.json', 'retention_authority_ref': 'assignment:retain-until-final-acceptance-no-auto-delete', 'created_at_utc': now}

def seal_for(ar):
    return {'format_version': 1, 'delivery_id': ar['delivery_id'], 'task_id': ar['task_id'], 'task_revision': ar['task_revision'], 'manifest_sha256': hashlib.sha256(C14(ar)).hexdigest(), 'sealed_at_utc': now}
seal = seal_for(archive)
candidate = {'sha': C, 'parents': [P], 'marker': attempt['closing_marker'], 'phase_trailer': 'closing', 'approved_ancestry': True}

def safe_rel(x):
    return bool(x) and (not x.startswith(('/', '\\'))) and (':' not in x) and ('\\' not in x) and all((y not in ('', '.', '..') for y in x.split('/')))



def archive_ok(ar, fs, seal_record):
    if not gv('GitEvidenceArchive', ar) or not gv('GitArchiveSeal', seal_record):
        return False
    if any((ar[k] != seal_record[k] for k in ['delivery_id', 'task_id', 'task_revision'])):
        return False
    if seal_record['manifest_sha256'] != hashlib.sha256(C14(ar)).hexdigest():
        return False
    paths = [x['path'] for x in ar['files']]
    if len(paths) != len(set(paths)) or set(paths) != set(fs) or {'manifest.json', 'seal.json'} & set(paths):
        return False
    if ar['payload_observation_ref'] == ar['closing_observation_ref']:
        return False
    try:
        return all((safe_rel(x['path']) and len(fs[x['path']]) == x['byte_length'] and (hashlib.sha256(fs[x['path']]).hexdigest() == x['sha256']) for x in ar['files']))
    except KeyError:
        return False
allowed = {'S19/T001/Status', 'S19/T001/Owner', 'S19/T001/Evidence', 'S19/progress', 'S20/G0/status', 'S20/G0/evidence', 'S21/task/T001/evidence', 'S21/task/T001/command', 'S21/task/T001/delivery', 'S21/task/T001/selection', 'S22/derived/checkpoint', 'S22/derived/active', 'S22/derived/pending', 'S22/derived/progress', 'S22/derived/final'}

def closing_diff_ok(changes, other_bytes_equal=True):
    return bool(changes) and set(changes) <= allowed and other_bytes_equal

def resolve(at, candidates):
    if not gv('GitDeliveryAttempt', at) or at['phase'] != 'closing_proposed' or at['closing_parent_sha'] != at['verified_payload_sha'] or (at['closing_marker'] != 'MCE4D-Delivery-ID: ' + at['delivery_id']):
        return None
    if at['planned_archive_path'] != 'artifacts/git-delivery/' + at['delivery_id'] or at['archive_staging_path'] != 'artifacts/git-delivery/.staging-' + at['delivery_id']:
        return None
    matches = [x for x in candidates if x['parents'] == [at['verified_payload_sha']] and x['marker'] == at['closing_marker'] and (x['phase_trailer'] == 'closing') and x['approved_ancestry']]
    return matches[0]['sha'] if len(matches) == 1 else None


def load_member(fs, name):
    if not safe_rel(name):
        raise ValueError('unsafe member')
    x = json.loads(fs[name], object_pairs_hook=dup)
    if C14(x) != fs[name]:
        raise ValueError('noncanonical member')
    return x

exec(compile((run/'delivery_core.py').read_text(encoding='utf-8'),str(run/'delivery_core.py'),'exec'))
for name, value in [('GitRepositoryIdentity', repo), ('GitCheckSpec', check), ('GitCheckPlan', plan), ('GitCommit', attempt['ordered_commits'][0]), ('GitDeliveryAttempt', attempt), ('GitObservedCheck', observed), ('GitDeliveryObservation', observation), ('GitEvidenceArchive', archive), ('GitArchiveSeal', seal), ('GitTaskDeliverySelection', selection), ('GitDestinationObservation', destination(P, UP))]:
    ck('governance positive ' + name, gv(name, value))
    ck('governance unknown key rejected ' + name, not gv(name, {**value, 'extra': True}))
ck('effective closing positive', fixture_done(attempt, plan, observation, archive, files, [candidate], ['S19/T001/Status'], C, seal_record=seal, sel=selection, published=True))

def test_mutation(name, mutation):
    at = copy.deepcopy(attempt)
    pl = copy.deepcopy(plan)
    ob = copy.deepcopy(observation)
    ar = copy.deepcopy(archive)
    fs = copy.deepcopy(files)
    mutation(at, pl, ob, ar, fs)
    fs['attempt.json'] = C14(at)
    fs['plan.json'] = C14(pl)
    fs['closing.json'] = C14(ob)
    ar['files'] = manifest_for(fs)
    ck('relational reject ' + name, not fixture_done(at, pl, ob, ar, fs, [candidate], ['S19/T001/Status'], C, seal_record=seal_for(ar), sel=selection, published=True))
test_mutation('H01 wrong closing phase', lambda a, p, o, r, f: o.update(phase='payload'))
test_mutation('H01 wrong archive task', lambda a, p, o, r, f: r.update(task_id='T080'))
test_mutation('H01 swapped closing pointer', lambda a, p, o, r, f: r.update(closing_observation_ref=r['payload_observation_ref']))
test_mutation('H01 ordered payload mismatch', lambda a, p, o, r, f: a['ordered_commits'][-1].update(sha=Q))
for field, value in [('assignment_ref', 'other'), ('task_revision', 2), ('delivery_id', U2), ('check_plan_sha256', 'f' * 64), ('closing_sha', Q), ('verified_payload_sha', Q)]:
    test_mutation('archive ' + field, lambda a, p, o, r, f, k=field, v=value: r.update({k: v}))
for field, value in [('phase', 'closing'), ('result', 'FAIL'), ('delivery_id', U2), ('subject_sha', Q), ('checks', [])]:
    test_mutation('payload ' + field, lambda a, p, o, r, f, k=field, v=value: f.update({'payload.json': C14({**payload_obs, k: v})}))
test_mutation('wrong closing parent', lambda a, p, o, r, f: o.update(parent_sha=Q))
test_mutation('bad manifest-local reference', lambda a, p, o, r, f: a.update(local_evidence_refs=['missing.json']))
test_mutation('bad check evidence pointer', lambda a, p, o, r, f: o['checks'][0].update(evidence_refs=['missing.log']))
test_mutation('wrong planned UUID path', lambda a, p, o, r, f: a.update(planned_archive_path='artifacts/git-delivery/' + U2))
test_mutation('wrong ordered ancestry', lambda a, p, o, r, f: f.update({'git.json': C14({P: [Q], C: [P]})}))
test_mutation('missing actual push operation', lambda a, p, o, r, f: o['destination_observation'].update(push_operation_id=U2))
test_mutation('reuse payload prepush observation at closing', lambda a, p, o, r, f: o.update(destination_observation=copy.deepcopy(payload_obs['destination_observation'])))
test_mutation('new unknown visibility', lambda a, p, o, r, f: o['destination_observation'].update(visibility_verified=False))
test_mutation('visibility changed public', lambda a, p, o, r, f: o['destination_observation']['repository'].update(visibility='public'))
test_mutation('remote config changed before push', lambda a, p, o, r, f: o['destination_observation'].update(local_remote_config_digest='2' * 64))
test_mutation('pushed before fresh observation', lambda a, p, o, r, f: o['destination_observation'].update(push_started_at_utc='2026-10-15T02:00:00Z'))
for field, value in [('visibility', 'public'), ('visibility', 'unknown'), ('repository_id', 321), ('ref', 'refs/heads/other')]:
    dr = destination(C, UC)
    dr['repository'][field] = value
    ck('fresh destination rejects drift ' + field + str(value), not destination_ok(plan, dr, C, files))
pubplan = copy.deepcopy(plan)
pubplan['repository'].update(visibility='public', publication_authority_ref='explicit-user-fixture')
pubdest = destination(C, UC)
pubdest['repository'] = copy.deepcopy(pubplan['repository'])
pubfs=copy.deepcopy(files)
put_push_evidence(pubfs,pubdest)
ck('authorized public destination with matching new plan', destination_ok(pubplan, pubdest, C, pubfs))
for field, value in [('manifest_sha256', '0' * 64), ('task_revision', 2), ('delivery_id', U2)]:
    ck('seal mismatch rejected ' + field, not fixture_done(attempt, plan, observation, archive, files, [candidate], ['S19/T001/Status'], C, seal_record={**seal, field: value}, sel=selection, published=True))
ck('staging seal never DONE', not fixture_done(attempt, plan, observation, archive, files, [candidate], ['S19/T001/Status'], C, published=False, seal_record=seal, sel=selection))
ck('offline sealed historical receipt valid', fixture_done(attempt, plan, observation, archive, files, [candidate], ['S19/T001/Status'], Q, True, seal_record=seal, sel=selection, published=True))
ck('current final remote mismatch rejected', not fixture_done(attempt, plan, observation, archive, files, [candidate], ['S19/T001/Status'], Q, seal_record=seal, sel=selection, published=True))
for sel in [{**selection, 'active_delivery_id': None}, {**selection, 'active_delivery_id': U2}, {**selection, 'task_revision': 2, 'supersedes_delivery_id': U, 'invalidation_refs': ['regression:E1']}, {**selection, 'task_id': 'T080'}, {**selection, 'assignment_ref': 'other'}]:
    ck('current selector rejects stale ' + str(sel['task_revision']) + str(sel['active_delivery_id']) + sel['task_id'] + sel['assignment_ref'], not fixture_done(attempt, plan, observation, archive, files, [candidate], ['S19/T001/Status'], C, sel=sel, seal_record=seal, published=True))
ck('duplicate closing marker ambiguous', resolve(attempt, [candidate, {**candidate, 'sha': Q}]) is None)
for patch in [{'parents': [Q]}, {'parents': [P, Q]}, {'approved_ancestry': False}, {'marker': 'other'}, {'phase_trailer': 'payload'}]:
    ck('resolve rejects ' + str(patch), resolve(attempt, [{**candidate, **patch}]) is None)
for leaf in ['S43/RuntimeConfig', 'S21/schema', 'S21/ADR/A046', 'S21/task/T001/check-plan', 'S19/T002/Status', 'S22/authority', 'frontmatter/spec_version', 'source/main.go']:
    ck('leaf classifier rejects ' + leaf, not closing_diff_ok(['S19/T001/Status', leaf]))
ck('typed checkpoint allowed only derived leaf', closing_diff_ok(['S22/derived/checkpoint', 'S21/task/T001/selection']))
ck('other tracked byte delta forbidden', not closing_diff_ok(['S19/T001/Status'], False))
for patch in [{'event': 'workflow_dispatch'}, {'event': 'repository_dispatch'}, {'source_app': 'other'}, {'tested_checkout_sha': Q}, {'reported_head_sha': Q}, {'execution_verified': False}, {'status': 'queued'}, {'conclusion': 'failure'}, {'conclusion': 'skipped'}, {'conclusion': 'neutral'}]:
    ck('CI rejects ' + str(patch), not checks_ok(plan, [{**observed, **patch}], C))
ck('new failed run wins old green', not checks_ok(plan, [observed, {**observed, 'run_id': '1002', 'conclusion': 'failure'}], C))
ck('new queued rerun wins old green', not checks_ok(plan, [observed, {**observed, 'attempt': 2, 'status': 'queued', 'conclusion': 'unknown'}], C))
for field, value in [('checks', []), ('canary_ref', None), ('required_set_status', 'NOT_VERIFIED')]:
    ck('CI plan reject ' + field, not checks_ok({**plan, field: value}, [observed], C))
prcheck = {**check, 'eligible_events': ['pull_request'], 'checkout_binding': 'pr_merge'}
prplan = {**plan, 'checks': [prcheck]}
prgood = {**observed, 'event': 'pull_request', 'reported_head_sha': P, 'pr_head_sha': P, 'pr_base_sha': Q, 'tested_merge_sha': C, 'tested_checkout_sha': C}
ck('PR head-base merge separate positive', checks_ok(prplan, [prgood], P))
ck('PR actual merge checkout mismatch rejected', not checks_ok(prplan, [{**prgood, 'tested_checkout_sha': P}], P))
mgcheck = {**check, 'id': 'queue-document', 'eligible_events': ['merge_group'], 'checkout_binding': 'merge_group', 'reported_sha_binding': 'tested'}
mgplan = {**plan, 'merge_checks': [mgcheck]}
group = {'format_version': 1, 'group_head_sha': M, 'group_base_sha': Q, 'group_ref': 'refs/heads/gh-readonly-queue/main/fixture', 'target_ref': 'refs/heads/main', 'repository_id': 123, 'source_subject_sha': C, 'member_heads': [{'pull_request_number': 1, 'repository_id': 123, 'head_sha': C}], 'membership_evidence_refs': ['group-api.json'], 'group_created_at_utc': now, 'authority_ref': 'fixture-explicit-queue-authority'}
mgobs = {**observed, 'check_id': 'queue-document', 'event': 'merge_group', 'reported_head_sha': M, 'tested_checkout_sha': M}
ck('merge group schema positive', gv('GitMergeGroupBinding', group))
ck('group M different member C accepted at merge stage', checks_ok(mgplan, [mgobs], C, 'merge', group, copy.deepcopy(group)))
ck('pending merge-only check does not block task delivery', checks_ok(mgplan, [observed], C))
ck('group proof cannot substitute task delivery', not checks_ok(mgplan, [mgobs], C))
ck('merge-group not legal in delivery set', not checks_ok({**plan, 'checks': [mgcheck]}, [mgobs], C))
for patch in [{'group_head_sha': P}, {'group_base_sha': P}, {'group_ref': 'other'}, {'member_heads': []}, {'repository_id': 456}, {'source_subject_sha': P}, {'authority_ref': ''}]:
    ck('merge group stale/unauthorized ' + str(patch), not checks_ok(mgplan, [mgobs], C, 'merge', {**group, **patch}, group))
ck('head SHA cannot replace queue checkout', not checks_ok(mgplan, [{**mgobs, 'tested_checkout_sha': C}], C, 'merge', group, group))
checkpoint = {'format_version': 1, 'checkpoint_id': U2, 'assignment_ref': 'fixture-assignment', 'task_id': 'T001', 'task_revision': 1, 'delivery_id': U, 'local_branch': 'main', 'head_sha': C, 'working_tree_digest': '1' * 64, 'index_digest': '2' * 64, 'command_record_ref': 'command:push-C', 'operation_id': UC, 'command_state': 'UNKNOWN', 'unfinished_check_refs': ['closing-checks'], 'blocker_refs': [], 'next_action_ref': 'observe-closing-then-seal', 'planned_archive_path': attempt['planned_archive_path'], 'checkpointed_at_utc': now}
ck('typed execution checkpoint positive', gv('GitExecutionCheckpoint', checkpoint))
for field in G['GitExecutionCheckpoint']['required']:
    ck('checkpoint required ' + field, not gv('GitExecutionCheckpoint', {k: v for k, v in checkpoint.items() if k != field}))
ck('current resume checkpoint absent before code', resume['execution_checkpoint'] is None and resume['git_delivery']['task_revision'] is None and (resume['git_delivery']['planned_archive_path'] is None))
ck('schema forbids status second tracker', 'status' not in G['GitTaskDeliverySelection']['properties'] and 'status' not in G['GitExecutionCheckpoint']['properties'])

def merge(*layers):
    out = {}
    for layer in layers:
        for k, v in layer.items():
            out[k] = merge(out.get(k, {}), v) if isinstance(v, dict) else copy.deepcopy(v)
    return out
home = {'schema_version': 1, 'core': {'max_indexed_files': 100}}
input_config = {'schema_version': 1, 'core': {'query_timeout_ms': 1000}}

def config_preview(candidate, process=None):
    if not val('RuntimeConfig', candidate):
        raise ValueError('invalid config')
    process = process or {}
    allowed_process = set(D['CoreRuntimeLimits']['properties']) - {'max_worktree_cache_bytes', 'volume_reserve_bytes', 'volume_warning_bytes'}
    if set(process) - {'core'} or set(process.get('core', {})) - allowed_process:
        raise ValueError('CLI override scope')
    effective = merge(defaults, candidate, process)
    if effective['core']['max_parse_workers'] == 0:
        effective['core']['max_parse_workers'] = 4
    if not val('RuntimeConfig', effective) or not semantic_limits(effective):
        raise ValueError('crossfield')
    return effective
validate_preview = config_preview(input_config)
set_preview = config_preview(input_config)
ck('replacement validate equals set same candidate', validate_preview == set_preview)
ck('home100 not implicitly merged into replacement', validate_preview['core']['max_indexed_files'] == 1000000)
ck('runtime show alternate merge retains home100', merge(defaults, home, input_config)['core']['max_indexed_files'] == 100)
ck('explicit candidate100 retained', config_preview(merge(input_config, home))['core']['max_indexed_files'] == 100)
validate_data = {**cfgdata, 'source_digest': Hsource(home), 'config': validate_preview, 'effective_sources': ['built_in', 'candidate_input']}
ck('validate provenance excludes observed canonical home', provenance_ok(validate_data, True, 'validate'))
ck('validate source_digest still live home source', validate_data['source_digest'] == Hsource(home) and Hsource(home) != Hsource(input_config))
ck('validate fake canonical layer rejected', not provenance_ok({**validate_data, 'effective_sources': ['built_in', 'canonical_home', 'candidate_input']}, True, 'validate'))
ck('show candidate layer rejected', not provenance_ok(validate_data, True, 'show'))
snapshot = copy.deepcopy(home)
config_preview(input_config)
ck('validate pure function leaves current home unchanged', home == snapshot)
cleanup = {'new_in_current_run': True, 'reconstructible': True, 'contract_exact': True, 'baseline_verified': True, 'same_owner': True, 'contained_no_links': True, 'identity_verified': True, 'writers_stopped': True, 'evidence_retained': True, 'authority_A046': True, 'canonical_or_user': False, 'real_or_linked_git': False, 'actual_home': False, 'unique_evidence': False, 'accumulated': False, 'crash_leftover': False}

def teardown_ok(x):
    return all((x[k] for k in ['new_in_current_run', 'reconstructible', 'contract_exact', 'baseline_verified', 'same_owner', 'contained_no_links', 'identity_verified', 'writers_stopped', 'evidence_retained', 'authority_A046'])) and (not any((x[k] for k in ['canonical_or_user', 'real_or_linked_git', 'actual_home', 'unique_evidence', 'accumulated', 'crash_leftover'])))
for kind in ['synthetic-fixture-dotgit', 'synthetic-test-catalog', 'synthetic-test-records-WAL-SHM', 'generated-mutable-copy']:
    ck('fresh fixture teardown ' + kind, teardown_ok(cleanup))
for key in cleanup:
    ck('teardown refuses unsafe ' + key, not teardown_ok({**cleanup, key: not cleanup[key]}))
ck('user fixture authority scoped in SPEC', 'TEARDOWN-FIXTURE-01' in s and 'A046' in s and ('không actual user/canonical history/data' in s))
ck('H01-H08 closure and discrepancies', all(('| D' + str(i).zfill(3) + ' |' in s for i in range(29, 37))) and all(('| H' + str(i).zfill(2) + ' P' in s for i in range(1, 9))))
ck('current review metadata167', fm['latest_review_findings'] == fm['latest_review_findings_integrated'] == 6 and resume['latest_review_baseline'] == '1.6.6' and (resume['latest_review_closure'] == 'S52_CLOSE_07'))
ck('editorial historical18 current20 exact', 'current vectors18' not in s and 'historical v1.6.2 có18 codec vectors' in s)
ck('22 governance schemas all closed', len(G) == 22 and all((d.get('additionalProperties') is False for d in G.values())))
ck('source config limits preserve hardcaps', D['CoreRuntimeLimits'] == olddefs['CoreRuntimeLimits'])
oldrows = [re.split('(?<!\\\\)\\|', l)[1:-1] for l in orig.split('## S19 —', 1)[1].split('## S20 —', 1)[0].splitlines() if re.match('^\\| T\\d{3} \\|', l)]
ck('108 original task identities/dependencies preserved', all((r[:3] == o[:3] for r, o in zip(tasks, oldrows))))
expanded = set()
for r in tasks:
    expanded.update(re.findall('C\\d{3}', r[5]))
    for a, z in re.findall('C(\\d{3})\\.\\.C(\\d{3})', r[5]):
        expanded.update(('C' + str(i).zfill(3) for i in range(int(a), int(z) + 1)))
ck('all195 cases assigned after expanding ranges', expanded == set(cc))
ck('missing actual seal rejected', not fixture_done(attempt, plan, observation, archive, files, [candidate], ['S19/T001/Status'], C, sel=selection, published=True))
noat = {**attempt, 'payload_mode': 'verified_noop', 'base_sha': P}
nofs = {**files, 'attempt.json': C14(noat)}
noar = {**archive, 'files': manifest_for(nofs)}
ck('declared verified no-op with actual existing P positive', fixture_done(noat, plan, observation, noar, nofs, [candidate], ['S19/T001/Status'], C, seal_record=seal_for(noar), sel=selection, published=True))
test_mutation('attempt pointer wrong kind', lambda a, p, o, r, f: r.update(attempt_ref='payload.json'))
test_mutation('selection pointer wrong kind', lambda a, p, o, r, f: r.update(selection_ref='payload.json'))
test_mutation('Git ancestry pointer wrong kind', lambda a, p, o, r, f: r.update(git_evidence_ref='payload.json'))

# All typed pointers may be renamed: actual refs, not magic filenames.
mapping={'plan.json':'roles/plan.json','attempt.json':'roles/attempt.json','selection.json':'roles/selection.json','payload.json':'roles/payload.json','closing.json':'roles/terminal.json','local.json':'roles/commands.json','git.json':'roles/ancestry.json'}
renat=copy.deepcopy(attempt)
renat.update(check_plan_ref=mapping['plan.json'],payload_observation_ref=mapping['payload.json'],local_evidence_refs=[mapping.get(ref,ref) for ref in attempt['local_evidence_refs']])
renfs={mapping.get(k,k):v for k,v in files.items()}
renfs[mapping['attempt.json']]=C14(renat)
renar={**archive,'attempt_ref':mapping['attempt.json'],'selection_ref':mapping['selection.json'],'git_evidence_ref':mapping['git.json'],'payload_observation_ref':mapping['payload.json'],'closing_observation_ref':mapping['closing.json'],'files':manifest_for(renfs)}
ck('all member roles resolve by refs not filenames',fixture_done(renat,plan,observation,renar,renfs,[candidate],['S19/T001/Status'],C,sel=selection,seal_record=seal_for(renar),published=True))
ck('missing authoritative selector rejected',not fixture_done(attempt,plan,observation,archive,files,[candidate],['S19/T001/Status'],C,sel=None,seal_record=seal,published=True))
ck('unknown publication state rejected',not fixture_done(attempt,plan,observation,archive,files,[candidate],['S19/T001/Status'],C,sel=selection,seal_record=seal,published=False))
for proc in [{'core':{'max_worktree_cache_bytes':1}},{'explorer':{'session_ttl_seconds':1}},{'core':{'query_result_cache_bytes':33554433}}]:
 try:config_preview(input_config,proc);rejected=False
 except ValueError:rejected=True
 ck('candidate CLI override rejected '+str(proc),rejected)
ck('valid process timeout override not persisted',config_preview(input_config,{'core':{'query_timeout_ms':2000}})['core']['query_timeout_ms']==2000 and input_config['core']['query_timeout_ms']==1000)

ck('all normative codec/raw vectors unchanged from164',blocks['MCE4D_HASH_VECTORS_V1']==origblocks['MCE4D_HASH_VECTORS_V1'])
current_schema=copy.deepcopy(sc);prior_schema=copy.deepcopy(origblocks['MCE4D_CONTRACT_SCHEMA_V1'])
current_schema['$defs'].pop('RuntimeConfigData');prior_schema['$defs'].pop('RuntimeConfigData')
ck('runtime root plus154 definitions byte-semantic equivalent',current_schema==prior_schema)
ck('per-push freshness and stage applicability explicit','Trước MỌI push (P, C, retry, sau resume)' in s and 'merge_checks chỉ phục vụ external merge-ready claim' in s)

exec(compile((run/'verify_review166.py').read_text(encoding='utf-8'),str(run/'verify_review166.py'),'exec'))

exec(compile((run/'verify_review167.py').read_text(encoding='utf-8'),str(run/'verify_review167.py'),'exec'))
