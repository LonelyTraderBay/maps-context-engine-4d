"""Verify immutable flat proof members. Integrity check, not signature/authenticity."""
from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent
def strict_object(pairs):
    result={}
    for key,value in pairs:
        if key in result:raise ValueError('duplicate manifest key')
        result[key]=value
    return result
m=json.loads((root/'manifest.json').read_bytes(),object_pairs_hook=strict_object)
for name,entry in m['files'].items():
    if Path(name).name!=name or '/' in name or '\\' in name or ':' in name:raise ValueError('unsafe member')
    path=root/name
    assert path.is_file() and not path.is_symlink(),name
    raw=path.read_bytes()
    assert len(raw)==entry['bytes'] and hashlib.sha256(raw).hexdigest()==entry['sha256'],name
assert hashlib.sha256((root/'final-spec.bin').read_bytes()).hexdigest()==m['spec_sha256']
print(json.dumps({'spec_version':m['spec_version'],'members_verified':len(m['files']),'result':'PASS'}))
