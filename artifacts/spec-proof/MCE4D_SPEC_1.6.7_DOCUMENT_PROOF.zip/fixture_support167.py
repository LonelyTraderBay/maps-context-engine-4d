"""Synthetic inputs ONLY. Never called by normative evaluator to invent live evidence.
Legacy regression callsites explicitly use fixture_done; new tests freeze inputs first.
"""

def make_collection_fixture(pl,o,fs,start=None,end=None):
    start=start or o['observed_at_utc'];end=end or o['observed_at_utc']
    ref=o.get('collection_evidence_ref','collection-'+o['phase']+'-'+o['delivery_id']+'.json')
    identity=str(uuid.uuid5(uuid.UUID(o['delivery_id']),ref+'|'+start))
    pages=[]
    sources={v['source_evidence_ref']:typed(fs,v['source_evidence_ref'],'GitCheckSourceEvidence') for v in o['checks']}
    shas={o['subject_sha']}
    if o.get('pull_request_binding_ref') is not None:shas.add(typed(fs,o['pull_request_binding_ref'],'GitPullRequestBinding')['tested_merge_sha'])
    targets=[(endpoint,sha) for sha in sorted(shas) for endpoint in ['check_runs','commit_statuses']]
    if any(req['workflow_path'] is not None for req in pl['checks']):targets.extend(('workflow_runs',sha) for sha in sorted(shas))
    for endpoint,sha in targets:
        qid=str(uuid.uuid5(uuid.UUID(identity),endpoint+'|'+sha));rawref=ref+'-'+endpoint+'-'+sha+'.page.json'
        items=[]
        if endpoint=='workflow_runs':
            groups={}
            for source_ref,x in sources.items():
                if x['source_kind']!='actions_check_run' or x['workflow_head_sha']!=sha:continue
                key=(x['run_id'],x['attempt'])
                groups.setdefault(key,{'run_id':x['run_id'],'run_attempt':x['attempt'],'head_sha':x['workflow_head_sha'],'workflow_path':x['workflow_path'],'event':x['event'],'created_at':x['created_at_utc'],'job_source_refs':[]})['job_source_refs'].append(source_ref)
            items=list(groups.values())
        else:
            items=[source_snapshot(x) for x in sources.values() if x['reported_head_sha']==sha and (x['source_kind']=='commit_status')==(endpoint=='commit_statuses')]
        fs[rawref]=C14({'kind':'ci_api_page','query_id':qid,'endpoint':endpoint,'requested_sha':sha,'page_number':1,'next_page_number':None,'state_filter':'all','observed_at_utc':end,'items':items})
        pages.append({'query_id':qid,'endpoint':endpoint,'requested_sha':sha,'page_number':1,'next_page_number':None,'raw_page_ref':rawref})
    value={'format_version':1,'kind':'ci_collection','collection_id':identity,'host':pl['repository']['host'],'repository_id':pl['repository']['repository_id'],'subject_sha':o['subject_sha'],'check_plan_sha256':hashlib.sha256(C14(pl)).hexdigest(),'started_at_utc':start,'completed_at_utc':end,'pages':pages}
    fs[ref]=C14(value);o['collection_evidence_ref']=ref
    return value


def make_live_fixture(at,pl,ob,ar,fs,current_pr=None,identity=None,start=None,end=None):
    """Explicit fake collector/secured invocation for tests, distinct file namespace."""
    start=start or ob['observed_at_utc'];end=end or start
    identity=identity or str(uuid.uuid5(uuid.UUID(at['delivery_id']),'synthetic-live|'+start))
    lf=copy.deepcopy(fs);current=copy.deepcopy(ob)
    current['observed_at_utc']=end
    current['collection_evidence_ref']='live/'+identity+'/collection.json'
    make_collection_fixture(pl,current,lf,start,end)
    prref=None
    if current_pr is not None:
        prref='live/'+identity+'/current-pr.json';lf[prref]=C14(current_pr)
    observation_ref='live/'+identity+'/closing-observation.json';lf[observation_ref]=C14(current)
    value={'format_version':1,'kind':'live_verification','verification_id':identity,'assignment_ref':at['assignment_ref'],'task_id':at['task_id'],'task_revision':at['task_revision'],'delivery_id':at['delivery_id'],'check_plan_sha256':at['check_plan_sha256'],'subject_sha':ob['subject_sha'],'observed_remote_sha':ob['subject_sha'],'started_at_utc':start,'completed_at_utc':end,'closing_observation_ref':observation_ref,'collection_evidence_ref':current['collection_evidence_ref'],'git_evidence_ref':ar['git_evidence_ref'],'current_pr_ref':prref,'files':manifest_for(lf)}
    return value,lf,{'verification_id':identity,'started_at_utc':start}


def fixture_done(at,pl,ob,ar,fs,candidates,changes,live_remote,offline=False,sel=None,seal_record=None,published=False,current_pr=None):
    """Compatibility input builder for old tests; normative API requires explicit live input."""
    if offline:return effective_done(at,pl,ob,ar,fs,candidates,changes,live_remote,True,sel,seal_record,published)
    try:
        pr=current_pr.get('closing') if current_pr else None
        v,lf,ctx=make_live_fixture(at,pl,ob,ar,fs,pr)
        return effective_done(at,pl,ob,ar,fs,candidates,changes,live_remote,False,sel,seal_record,published,live_verification=v,live_files=lf,live_context=ctx)
    except (ValueError,KeyError,TypeError,OverflowError):return False
