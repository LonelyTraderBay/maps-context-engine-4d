# Document reference fixtures only. No Git calls, product implementation, or deletion.
G=blocks['MCE4D_GIT_GOVERNANCE_SCHEMA_V1']['$defs']
gsc=blocks['MCE4D_GIT_GOVERNANCE_SCHEMA_V1']
Draft202012Validator.check_schema(gsc)
ck('governance 22 closed definitions meta-valid',len(G)==22 and all(x.get('additionalProperties') is False for x in G.values()))
def gv(name,value):return Draft202012Validator({'$schema':gsc['$schema'],'$defs':G,'$ref':'#/$defs/'+name},format_checker=FormatChecker()).is_valid(value)
grefs=[]
def gw(v):
 if isinstance(v,dict):
  if '$ref' in v:grefs.append(v['$ref'])
  for x in v.values():gw(x)
 elif isinstance(v,list):
  for x in v:gw(x)
gw(gsc)
ck('governance refs resolve',all(x.startswith('#/$defs/') and x.split('/')[-1] in G for x in grefs))
ck('governance not runtime operation registry',not any(k in json.dumps(registry) for k in G))
def canonical(v):
 if v is None:return b'null'
 if v is False:return b'false'
 if v is True:return b'true'
 if isinstance(v,int):
  if abs(v)>9007199254740991:raise ValueError('unsafe integer')
  return str(v).encode('ascii')
 if isinstance(v,str):
  v.encode('utf-8')
  return json.dumps(v,ensure_ascii=False,separators=(',',':')).replace('\u2028','\\u2028').replace('\u2029','\\u2029').encode('utf-8')
 if isinstance(v,list):return b'['+b','.join(canonical(x) for x in v)+b']'
 if isinstance(v,dict):return b'{'+b','.join(canonical(k)+b':'+canonical(v[k]) for k in sorted(v,key=lambda x:x.encode('utf-8')))+b'}'
 raise ValueError('non-JSON/fraction')
rawvectors=blocks['MCE4D_HASH_VECTORS_V1']['manifest_serialization']
ck('two raw manifest goldens',len(rawvectors)==2)
def reverse_keys(v):
 if isinstance(v,dict):return {k:reverse_keys(x) for k,x in reversed(list(v.items()))}
 if isinstance(v,list):return [reverse_keys(x) for x in v]
 return v
for v in rawvectors:
 raw=canonical(v['value'])
 ck('canonical raw golden '+v['case'],raw.hex()==v['utf8_hex'] and len(raw)==v['byte_length'] and hashlib.sha256(raw).hexdigest()==v['artifact_sha256'])
 ck('canonical key reorder '+v['case'],canonical(reverse_keys(v['value']))==raw)
 ck('literal vs escaped Unicode '+v['case'],canonical(json.loads(json.dumps(v['value'],ensure_ascii=True)))==raw)
 value=copy.deepcopy(v['value']);sd=value.pop('snapshot_digest')
 ck('raw golden schema and logical digest '+v['case'],val('CaptureManifest',v['value']) and hashlib.sha256(b'MCE4D\0C14N1\0'+E('capture-v1')+E(value)).hexdigest()==sd)
 ck('raw artifact noncanonical rejected '+v['case'],json.dumps(reverse_keys(v['value']),ensure_ascii=False,separators=(',',':')).encode()!=raw)
esc={'x':'\x00\b\f\n\r\t/<> &\u2028\u2029😀'}
ck('exact control/slash/HTML/U2028 escapes',canonical(esc)==b'{"x":"\\u0000\\b\\f\\n\\r\\t/<> &\\u2028\\u2029'+chr(0x1f600).encode()+b'"}')
ck('UTF8 not UTF16 key sorting',canonical({'\U00010000':1,'\ue000':2}).startswith(b'{"'+chr(0xe000).encode()+b'":2,'))
for x in [1.5,9007199254740992,'\udfff']:
 try:canonical(x);bad=False
 except (ValueError,UnicodeError):bad=True
 ck('physical canonical invalid '+repr(x),bad)

# F04 hardcaps are fixed while repo/source defaults can grow.
for field,cap in [('rename_result_max_bytes',33554432),('rename_results_max_bytes',134217728),('query_result_cache_bytes',33554432),('max_retained_query_results',32)]:
 good=copy.deepcopy(defaults);good['core'][field]=cap
 ck('result cap boundary accepted '+field,val('RuntimeConfig',good))
 good['core'][field]=cap+1
 ck('result cap plus1 rejected '+field,not val('RuntimeConfig',good))
 good['core'][field]=max(1,cap//2)
 ck('result lower cap accepted '+field,val('RuntimeConfig',good))
ck('runtime defaults semantic unchanged v163',defaults==origblocks['MCE4D_RUNTIME_DEFAULTS_V1'])
def Hsource(x):return hashlib.sha256(b'MCE4D\0C14N1\0'+E('runtime-config-source-v1')+E(x)).hexdigest() if x is not None else None
minimal={'schema_version':1}
ck('minimal canonical source schema',val('RuntimeConfig',minimal))
src=Hsource(minimal)
cfgdata={'operation':'runtime_config','config':defaults,'config_digest':H,'restart_required':False,'source_kind':'canonical_home','source_digest':src,'effective_sources':['built_in','canonical_home']}
ck('RuntimeConfigData canonical positive',val('RuntimeConfigData',cfgdata))
absent={**cfgdata,'source_kind':'built_in','source_digest':None,'effective_sources':['built_in']}
ck('RuntimeConfigData absent positive',val('RuntimeConfigData',absent))
for label,patch in [('missing source',{k:v for k,v in cfgdata.items() if k!='source_digest'}),('home null',{**cfgdata,'source_digest':None}),('built-in hash',{**absent,'source_digest':src}),('unknown provenance',{**cfgdata,'effective_sources':['local']}),('duplicate sources',{**cfgdata,'effective_sources':['built_in','built_in']}),('unknown field',{**cfgdata,'source_path':'private'})]:
 ck('RuntimeConfigData reject '+label,not val('RuntimeConfigData',patch))
def provenance_ok(x,file_present,action='show'):
 seq=x['effective_sources']
 if not val('RuntimeConfigData',x) or (x['source_kind']=='canonical_home')!=file_present:return False
 if action=='validate':
  allowed=['built_in','candidate_input','cli_process']
  return seq==[k for k in allowed if k in seq] and seq[:2]==['built_in','candidate_input']
 allowed=['built_in','canonical_home','approved_alternate','cli_process'] if action=='show' else ['built_in','canonical_home','cli_process']
 return seq[0]=='built_in' and seq==[k for k in allowed if k in seq] and ('canonical_home' in seq)==file_present and 'candidate_input' not in seq
ck('provenance semantic positive',provenance_ok(cfgdata,True) and provenance_ok(absent,False))
for seq in [['cli_process','built_in','canonical_home'],['built_in'],['canonical_home']]:
 ck('provenance wrong precedence/authority '+str(seq),not provenance_ok({**cfgdata,'effective_sources':seq},True))
ck('source absent distinct from minimal file',Hsource(None) is None and src is not None)
ck('source key order invariant',Hsource({'schema_version':1,'core':{'max_parse_workers':2}})==Hsource({'core':{'max_parse_workers':2},'schema_version':1}))
def cas(file,expected,replacement):return (True,replacement) if Hsource(file)==expected else (False,file)
one,new=cas(minimal,src,{'schema_version':1,'core':{'max_parse_workers':2}})
two,_=cas(new,src,{'schema_version':1,'core':{'max_parse_workers':3}})
ck('source CAS exactly one setter wins',one and not two)
ck('effective CPU/options do not change source CAS',cas(minimal,src,minimal)[0] and src!=hashlib.sha256(b'MCE4D\0C14N1\0'+E('runtime-config-v1')+E(defaults)).hexdigest())
ck('null CAS only absent',cas(None,None,minimal)[0] and not cas(minimal,None,minimal)[0])


exec(compile((run/'verify_delivery.py').read_text(encoding='utf-8'),str(run/'verify_delivery.py'),'exec'))
exec(compile((run/'verify_archive_io.py').read_text(encoding='utf-8'),str(run/'verify_archive_io.py'),'exec'))
