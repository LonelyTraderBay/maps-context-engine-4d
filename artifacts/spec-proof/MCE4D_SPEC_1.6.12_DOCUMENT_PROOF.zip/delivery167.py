"""v1.6.7 bounded pure governance reference. No Git/network/product code."""
from collections import Counter


def candidate_mapping_ok(specs, values):
    for value in values:
        key=next(iter(natural_keys({**value,'eligible_events':[value['event']]})))
        matched=[spec for spec in specs if key in natural_keys(spec)]
        known=[spec for spec in specs if spec['id']==value['check_id']]
        if len(matched)>1 or (matched and value['check_id']!=matched[0]['id']) or (known and not matched):
            return False
    return True


def source_graph_ok(pl, source, value, subject):
    fields=['check_suite_id','workflow_head_sha','job_head_sha','job_check_run_url']
    if source['source_kind']!='actions_check_run':
        return all(source[k] is None for k in fields)
    if any(source[k] is None for k in fields):
        return False
    allowed={subject}
    if value['pr_head_sha']==subject and value['tested_merge_sha']==value['tested_checkout_sha']:
        allowed.add(value['tested_merge_sha'])
    api='https://api.github.com' if pl['repository']['host']=='github.com' else 'https://'+pl['repository']['host']+'/api/v3'
    expected_url=api+'/repos/'+pl['repository']['owner']+'/'+pl['repository']['name']+'/check-runs/'+source['record_id']
    return source['workflow_head_sha'] in allowed and source['job_head_sha'] in allowed and source['job_check_run_url']==expected_url


def native_observed_ok(pl,value,subject,fs):
    source=typed(fs,value['source_evidence_ref'],'GitCheckSourceEvidence')
    normalized=normalized_native(source)
    return exact_json_equal(source_snapshot(source),load_member(fs,source['raw_api_ref'])) and source_graph_ok(pl,source,value,subject) and all(source[k]==pl['repository'][k] for k in ['host','repository_id']) and all(value[k]==normalized[k] for k in normalized) and instant(value['run_created_at_utc'])==instant(source['created_at_utc']) and all(source[k]==value[k] for k in ['source_app','context','workflow_path','job_name','job_id','matrix','event','reported_head_sha'])


def native_ledger_ok(observations):
    """Same native ID keeps immutable linkage across phases/queries; state can change."""
    ledger={}
    for observation,fs in observations:
        for value in observation['checks']:
            source=typed(fs,value['source_evidence_ref'],'GitCheckSourceEvidence')
            base=(source['host'],source['repository_id'])
            entries=[(base+(source['source_kind'],'record',source['record_id']),tuple(source[k] for k in ['reported_head_sha','source_app','context','run_id','job_id','attempt','workflow_path','event']))]
            if source['source_kind']=='actions_check_run':
                entries.extend([(base+('actions','run',source['run_id']),tuple(source[k] for k in ['workflow_head_sha','workflow_path','event','check_suite_id'])+(instant(source['created_at_utc']),)),(base+('actions','job',source['job_id']),tuple(source[k] for k in ['run_id','attempt','record_id','job_head_sha','job_name','source_app']))])
            for key,identity in entries:
                if key in ledger and ledger[key]!=identity:return False
                ledger[key]=identity
    return True


def collection_ok(pl, observation, collection, fs, start, end):
    """Compare normalized candidates to all retained pages, including workflow runs without jobs."""
    if not gv('GitCICollectionEvidence',collection):return False
    if any(collection[k]!=pl['repository'][k] for k in ['host','repository_id']) or collection['subject_sha']!=observation['subject_sha'] or collection['check_plan_sha256']!=hashlib.sha256(C14(pl)).hexdigest():return False
    if not (instant(start)<=instant(collection['started_at_utc'])<=instant(collection['completed_at_utc'])<=instant(observation['observed_at_utc'])<=instant(end)):return False
    sources={v['source_evidence_ref']:typed(fs,v['source_evidence_ref'],'GitCheckSourceEvidence') for v in observation['checks']}
    if len(sources)!=len(observation['checks']):return False
    shas={observation['subject_sha']}
    if observation['pull_request_binding_ref'] is not None:shas.add(typed(fs,observation['pull_request_binding_ref'],'GitPullRequestBinding')['tested_merge_sha'])
    expected={(endpoint,sha) for sha in shas for endpoint in ['check_runs','commit_statuses']}
    if any(spec['workflow_path'] is not None for spec in pl['checks']):expected.update(('workflow_runs',sha) for sha in shas)
    grouped={}
    for page in collection['pages']:grouped.setdefault((page['endpoint'],page['requested_sha']),[]).append(page)
    if set(grouped)!=expected:return False
    all_runs=[];query_ids=set()
    for (endpoint,sha),pages in grouped.items():
        pages=sorted(pages,key=lambda x:x['page_number'])
        qids={x['query_id'] for x in pages}
        if len(qids)!=1 or qids & query_ids:return False
        query_ids |= qids
        items=[]
        for index,page in enumerate(pages,1):
            next_page=index+1 if index<len(pages) else None
            if page['page_number']!=index or page['next_page_number']!=next_page:return False
            raw=load_member(fs,page['raw_page_ref'])
            envelope={'kind':'ci_api_page','query_id':page['query_id'],'endpoint':endpoint,'requested_sha':sha,'page_number':index,'next_page_number':next_page,'state_filter':'all','observed_at_utc':raw.get('observed_at_utc'),'items':raw.get('items')}
            if not exact_json_equal(raw,envelope) or not isinstance(raw['items'],list) or not (instant(collection['started_at_utc'])<=instant(raw['observed_at_utc'])<=instant(collection['completed_at_utc'])):return False
            for item in raw['items']:
                created=item['created_at'] if endpoint=='workflow_runs' else item['workflow_run']['created_at'] if item['workflow_run'] is not None else item['record']['created_at']
                if instant(created)>instant(raw['observed_at_utc']):return False
            items.extend(raw['items'])
        if endpoint=='workflow_runs':
            if any(x.get('head_sha')!=sha for x in items):return False
            all_runs.extend(items)
        else:
            selected=[source_snapshot(source) for source in sources.values() if source['reported_head_sha']==sha and (source['source_kind']=='commit_status')==(endpoint=='commit_statuses')]
            if Counter(C14(x) for x in items)!=Counter(C14(x) for x in selected):return False
            keys=[(x['source_kind'],str(x['record']['id'])) for x in items]
            if len(keys)!=len(set(keys)):return False
    runs={};run_identities={}
    for run_value in all_runs:
        if set(run_value)!=set(['run_id','run_attempt','head_sha','workflow_path','event','created_at','job_source_refs']):return False
        if not re.fullmatch('[1-9][0-9]{0,19}',str(run_value['run_id'])) or type(run_value['run_attempt']) is not int or run_value['run_attempt']<1 or run_value['head_sha'] not in shas or not isinstance(run_value['job_source_refs'],list):return False
        instant(run_value['created_at'])
        identity=(run_value['head_sha'],run_value['workflow_path'],run_value['event'],instant(run_value['created_at']))
        if run_value['run_id'] in run_identities and run_identities[run_value['run_id']]!=identity:return False
        run_identities[run_value['run_id']]=identity
        key=(run_value['run_id'],run_value['run_attempt'])
        if key in runs:return False
        runs[key]=run_value
        if len(run_value['job_source_refs'])!=len(set(run_value['job_source_refs'])):return False
        for ref in run_value['job_source_refs']:
            source=sources.get(ref)
            if source is None or source['source_kind']!='actions_check_run' or (source['run_id'],source['attempt'])!=key or source['workflow_head_sha']!=run_value['head_sha'] or source['workflow_path']!=run_value['workflow_path'] or source['event']!=run_value['event'] or instant(source['created_at_utc'])!=instant(run_value['created_at']):return False
    if any(instant(source['created_at_utc'])>instant(collection['completed_at_utc']) for source in sources.values()):return False
    if any(instant(x['created_at'])>instant(collection['completed_at_utc']) for x in all_runs):return False
    action_refs={ref for ref,x in sources.items() if x['source_kind']=='actions_check_run' and x['workflow_head_sha'] in shas}
    if action_refs != {ref for x in all_runs for ref in x['job_source_refs']}:return False
    for req in pl['checks']:
        if req['workflow_path'] is None:continue
        relevant=[x for x in all_runs if x['workflow_path']==req['workflow_path'] and x['event'] in req['eligible_events']]
        if not relevant:return False
        newest=max(relevant,key=lambda x:(instant(x['created_at']),int(x['run_id']),x['run_attempt']))
        matched=[value for value in observation['checks'] if value['source_evidence_ref'] in newest['job_source_refs'] and value['check_id']==req['id']]
        if not matched:return False
    return True


def evidence_files_ok(entries,fs):
    paths=[v['path'] for v in entries]
    return len(paths)==len(set(paths)) and set(paths)==set(fs) and all(safe_rel(v['path']) and len(fs[v['path']])==v['byte_length'] and hashlib.sha256(fs[v['path']]).hexdigest()==v['sha256'] for v in entries)


def live_verification_ok(at,pl,co,po,verification,fs,context,live_remote,archived_fs):
    if not gv('GitLiveVerification',verification) or not evidence_files_ok(verification['files'],fs):return False
    if context is None or set(context)!=set(['verification_id','started_at_utc']) or any(verification[k]!=context[k] for k in context):return False
    if any(verification[k]!=at[k] for k in ['assignment_ref','task_id','task_revision','delivery_id','check_plan_sha256']):return False
    if verification['subject_sha']!=co['subject_sha'] or verification['observed_remote_sha']!=co['subject_sha'] or live_remote!=co['subject_sha']:return False
    if not (instant(co['observed_at_utc'])<=instant(verification['started_at_utc'])<=instant(verification['completed_at_utc'])):return False
    current=typed(fs,verification['closing_observation_ref'],'GitDeliveryObservation')
    if any(current[k]!=co[k] for k in ['delivery_id','phase','subject_sha','parent_sha','check_plan_sha256','observed_remote_sha','destination_observation','merge_group_binding']):return False
    if current['result']!='PASS' or current['blocker'] is not None or not current['binding_verified'] or not current['required_set_verified']:return False
    if not observation_checks_ok(pl,current,fs):return False
    collection=typed(fs,verification['collection_evidence_ref'],'GitCICollectionEvidence')
    if current['collection_evidence_ref']!=verification['collection_evidence_ref'] or not collection_ok(pl,current,collection,fs,verification['started_at_utc'],verification['completed_at_utc']):return False
    parents=load_member(fs,verification['git_evidence_ref'])
    if parents.get(co['subject_sha'])!=[at['verified_payload_sha']]:return False
    required_pr=any(v['checkout_binding']=='pr_merge' for v in pl['checks'])
    current_pr=None
    if required_pr:
        snapshot=typed(fs,verification['current_pr_ref'],'GitPullRequestBinding')
        if not (instant(verification['started_at_utc'])<=instant(snapshot['observed_at_utc'])<=instant(verification['completed_at_utc'])):return False
        current_pr={'closing':snapshot}
    elif verification['current_pr_ref'] is not None:return False
    if not pr_ok(pl,current,parents,fs,current_pr,False):return False
    return native_ledger_ok([(po,archived_fs),(co,archived_fs),(current,fs)])


def effective_done(at,pl,ob,ar,fs,candidates,changes,live_remote,offline=False,sel=None,seal_record=None,published=False,live_verification=None,live_files=None,live_context=None):
    """Normative reference entry: no implicit fixture generation, live context or network."""
    try:
        if not archive_done(at,pl,ob,ar,fs,candidates,changes,live_remote,True,sel,seal_record,published,None):return False
        if offline:return True
        if live_verification is None or live_files is None:return False
        co=typed(fs,ar['closing_observation_ref'],'GitDeliveryObservation');po=typed(fs,ar['payload_observation_ref'],'GitDeliveryObservation')
        return live_verification_ok(at,pl,co,po,live_verification,live_files,live_context,live_remote,fs)
    except (ValueError,KeyError,TypeError,OverflowError):return False
