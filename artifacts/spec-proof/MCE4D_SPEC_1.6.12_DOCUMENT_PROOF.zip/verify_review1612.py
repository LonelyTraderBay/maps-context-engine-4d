"""Independent prior-review reproductions and full delivery/resume contract tests."""
from datetime import timedelta


def verify_review1612():
    start_count = len(checks)
    probes = []
    cases = []

    def test(name, actual, expected, group='V1611-04'):
        ck('Y ' + name, actual == expected)
        cases.append(dict(name=name, actual=actual, expected=expected, group=group))

    def probe(name, actual, expected):
        ck('Y review ' + name, actual == expected)
        probes.append(dict(name=name, actual=actual, expected=expected))

    def keep_live(x, o=None):
        if o is not None:
            x['lf'][x['live']['closing_observation_ref']] = C14(o)
        x['live']['files'] = manifest_for(x['lf'])

    def offset(value):
        return datetime.fromisoformat(value.replace('Z', '+00:00')).astimezone(timezone(timedelta(hours=7))).isoformat()

    probe('baseline plain', evaluate169(prepared169()), True)
    probe('baseline PR', evaluate169(prepared169(pr=True)), True)
    for field, label in [('start', 'equal lifecycle start offset spelling'), ('deadline', 'equal lifecycle deadline offset spelling')]:
        x = prepared169()
        op = typed(x['fs'], x['ob']['destination_observation']['operation_evidence_ref'], 'GitPushOperationEvidence')
        command = typed(x['fs'], op['command_record_ref'], 'GitCommandLifecycle')
        if field == 'start':
            command['result']['started_at_utc'] = offset(command['result']['started_at_utc'])
        else:
            command['contract']['deadline_at_utc'] = offset(command['contract']['deadline_at_utc'])
        x['fs'][op['command_record_ref']] = C14(command)
        retain169(x)
        probe(label, evaluate169(x), True)

    x = prepared169(pr=True)
    historical_canary169(x, False, True)
    can = typed(x['fs'], 'canary-evidence.json', 'GitCanaryEvidence')
    o = typed(x['fs'], can['observation_ref'], 'GitDeliveryObservation')
    op = typed(x['fs'], o['destination_observation']['operation_evidence_ref'], 'GitPushOperationEvidence')
    command = typed(x['fs'], op['command_record_ref'], 'GitCommandLifecycle')
    probe('canary own command ID positive', command['delivery_id'] == o['delivery_id'] and evaluate169(x), True)
    command['delivery_id'] = UC
    x['fs'][op['command_record_ref']] = C14(command)
    retain169(x)
    probe('canary other delivery command composed', evaluate169(x), False)
    probe('canary other delivery internally valid destination', destination_ok(typed(x['fs'], can['check_plan_ref'], 'GitCheckPlan'), o['destination_observation'], o['subject_sha'], x['fs']), True)

    for mutation in ['valid', 'wrong head', 'future acquisition', 'wrong repo', 'missing ref', 'wrong kind']:
        x = prepared169(pr=True)
        ref = x['live']['current_pr_ref']
        snapshot = typed(x['lf'], ref, 'GitPullRequestBinding')
        snapshot['api_evidence_ref'] = 'live/current-pr-distinct-api.json'
        raw = {'kind': 'pull_request_api_snapshot', **{k: v for k, v in snapshot.items() if k not in ['format_version', 'api_evidence_ref', 'kind']}}
        if mutation == 'wrong head': raw['head_sha'] = '7' * 40
        if mutation == 'future acquisition': raw['observed_at_utc'] = '2026-10-15T03:00:30Z'
        if mutation == 'wrong repo': raw['repository_id'] = 987
        if mutation == 'wrong kind': raw['kind'] = 'unrelated_api'
        x['lf'][ref] = C14(snapshot)
        if mutation != 'missing ref': x['lf'][snapshot['api_evidence_ref']] = C14(raw)
        keep_live(x)
        probe('distinct current PR raw ' + mutation, evaluate169(x), mutation == 'valid')

    x = prepared169()
    o = typed(x['lf'], x['live']['closing_observation_ref'], 'GitDeliveryObservation')
    o['observed_at_utc'] = '2026-10-15T03:00:30Z'
    keep_live(x, o)
    probe('live receipt outside secured end rejected', evaluate169(x), False)
    x = prepared169()
    probe('offline archive historical after branch advance', effective_done(x['at'], x['pl'], x['ob'], x['ar'], x['fs'], [x['ca']], ['S19/T001/Status'], Q, offline=True, sel=x['sel'], seal_record=seal_for(x['ar']), published=True), True)
    probe('online current remote moved rejected', effective_done(x['at'], x['pl'], x['ob'], x['ar'], x['fs'], [x['ca']], ['S19/T001/Status'], Q, sel=x['sel'], seal_record=seal_for(x['ar']), published=True, live_verification=x['live'], live_files=x['lf'], live_context=x['ctx']), False)
    x = prepared169(pr=True)
    frozen = copy.deepcopy(x)
    probe('repeated current verification valid', evaluate169(x) and evaluate169(x), True)
    probe('repeated verification inputs immutable', x == frozen, True)
    prior = json.loads((run/'regression-1.6.11.json').read_text(encoding='utf-8'))
    test('all18 review names and expected outcomes retained', [(v['name'], v['expected']) for v in probes], [(v['name'], v['expected']) for v in prior['probes']], 'regression')

    # Complete stage oracle independently derived from GIT06, before archive.
    tail = ['validate_retained_receipts', 'archive_publish_or_reuse_readback', 'pin_publication_context', 'query_live_verification', 'retain_live_readback', 'effective_done']
    expected = ['resolve_pending_or_claim', 'payload_local_checks', 'payload_commit', 'payload_push', 'payload_ci', 'closing_proposal', 'closing_commit', 'closing_push', 'closing_ci'] + tail
    next_stage = {
        'no_pending': 'resolve_pending_or_claim', 'allocated': 'payload_local_checks',
        'after_payload_local_checks': 'payload_commit', 'after_payload_commit': 'payload_push',
        'payload_push_inflight': 'reconcile_payload_push', 'payload_ci_pending': 'payload_ci',
        'after_payload_ci': 'closing_proposal', 'after_closing_proposal': 'closing_commit',
        'after_closing_commit': 'closing_push', 'closing_push_inflight': 'reconcile_closing_push',
        'closing_ci_pending': 'closing_ci', 'after_closing_ci': 'validate_retained_receipts',
        'archive_incomplete': 'archive_publish_or_reuse_readback', 'after_archive_readback': 'pin_publication_context',
        'live_incomplete': 'pin_publication_context', 'after_live_readback': 'effective_done',
        'after_effective_done': 'resolve_pending_or_claim', 'suspended_external_blocker': 'resolve_independent_ready'
    }
    protocol = blocks['MCE4D_DELIVERY_PROTOCOL_V1']
    test('closed full protocol shape', exact_json_equal(protocol, dict(format_version=1, kind='delivery_close_protocol', stages=tail, delivery_stages=expected, resume_next_stage=next_stage)), True)
    test('full delivery first execution', full_delivery_order_ok(expected), True)
    for i, stage in enumerate(expected):
        test('full delivery cannot omit ' + stage, full_delivery_order_ok(expected[:i] + expected[i+1:]), False)
        test('full delivery cannot duplicate ' + stage, full_delivery_order_ok(expected[:i] + [stage] + expected[i:]), False)
    for i in range(len(expected)-1):
        order = expected.copy(); order[i], order[i+1] = order[i+1], order[i]
        test('full delivery adjacent swap ' + str(i), full_delivery_order_ok(order), False)
    old_order = expected.copy(); old_order.remove('closing_ci'); old_order.insert(old_order.index('closing_proposal'), 'closing_ci')
    test('old S22 checking C before its proposal rejected', full_delivery_order_ok(old_order), False)
    pending = dict(delivery_id=U, task_revision=1)
    for boundary, action in next_stage.items():
        actual = dict(boundary=boundary, delivery_id=U, task_revision=1, effective_done=boundary == 'after_effective_done')
        candidate = pending
        if boundary == 'no_pending':
            actual.update(delivery_id=None, task_revision=None); candidate = None
        if boundary == 'suspended_external_blocker':
            actual.update(suspension_ref='suspension/retained.json', operation_settled=True)
        saved = copy.deepcopy((candidate, actual))
        test('resume exact boundary ' + boundary, delivery_resume_stage(boundary, candidate, actual), action)
        test('resume retains candidate and actual facts ' + boundary, (candidate, actual), saved)
        test('resume refuses wrong boundary ' + boundary, delivery_resume_stage('invented', candidate, actual), None)
        if candidate is not None:
            for name, bad in [('UUID', {**candidate, 'delivery_id': U2}), ('revision', {**candidate, 'task_revision': 2})]:
                test('resume refuses changed ' + name + ' ' + boundary, delivery_resume_stage(boundary, bad, actual), None)
            if boundary != 'after_effective_done':
                test('pending attempt cannot become next Ready ' + boundary, delivery_resume_stage('after_effective_done', candidate, actual), None)
            test('pending attempt cannot be discarded ' + boundary, delivery_resume_stage(boundary, None, actual), None)
    empty = dict(boundary='no_pending', delivery_id=None, task_revision=None, effective_done=False)
    test('no pending cannot hide existing selector', delivery_resume_stage('no_pending', pending, empty), None)
    for field in empty:
        test('resume actual field required ' + field, delivery_resume_stage('no_pending', None, {k:v for k,v in empty.items() if k != field}), None)
    suspend = dict(boundary='suspended_external_blocker', delivery_id=U, task_revision=1, effective_done=False, suspension_ref='suspension/retained.json', operation_settled=True)
    for patch in [dict(operation_settled=False), dict(suspension_ref=None), dict(suspension_ref='../escape'), dict(effective_done=True)]:
        test('independent Ready refuses unsafe suspension ' + str(patch), delivery_resume_stage('suspended_external_blocker', pending, {**suspend, **patch}), None)
    for field in ['suspension_ref', 'operation_settled']:
        test('independent Ready requires suspension field ' + field, delivery_resume_stage('suspended_external_blocker', pending, {k:v for k,v in suspend.items() if k != field}), None)
    for patch in [dict(task_revision=True), dict(task_revision=1.0), dict(operation_settled=1), dict(suspension_ref=True), dict(suspension_ref=17)]:
        test('secured suspension facts reject wrong types ' + str(patch), delivery_resume_stage('suspended_external_blocker', pending, {**suspend, **patch}), None)

    checklist = next(line for line in s.splitlines() if line.startswith('Checklist mỗi phiên:'))
    # Exact source anchors let metadata-only prose changes remain testable.
    for earlier, later in [('normal P push', 'P GitHub checks'), ('P GitHub checks', 'C proposal'), ('C proposal', 'C commit'), ('C commit', 'normal C push'), ('normal C push', 'C GitHub checks'), ('C GitHub checks', 'archive publish/reuse/readback'), ('archive publish/reuse/readback', 'fresh live verification'), ('fresh live verification', 'retain live/readback'), ('retain live/readback', 'effective DONE')]:
        test('S22 chronological pair ' + earlier, checklist.index(earlier) < checklist.index(later), True)
    test('S22 resumes pending before claiming', checklist.index('pending') < checklist.index('Ready'), True)
    test('source documents scoped external suspension', all(word in s for word in ['suspended_external_blocker', 'resolve_independent_ready', 'operation_settled', 'suspension_ref']), True)
    test('current version owner labels no stale current BP', 'Đặc tả v1.6.6 là bản vẽ/hợp đồng thi công' not in s, True, 'editorial')
    test('current closure metadata', fm['spec_version'] == resume['spec_version'] == '1.6.12' and resume['latest_review_baseline'] == '1.6.11' and resume['latest_review_closure'] == 'S52_CLOSE_12' and fm['latest_review_findings'] == fm['latest_review_findings_integrated'] == 4 and all(rule in s for rule in ['A053','D068','D069','D070','D071','PR-SOURCE-PARITY-01','PHASE-COMMAND-IDENTITY-01','LIFECYCLE-INSTANT-01','DELIVERY-FLOW-01']), True, 'sync')
    source_cases = verify_sources1612()
    result = dict(spec_version='1.6.12', groups_closed=4, prior_review_probes=probes,
                  prior_mismatches=8, current_mismatches=sum(v['actual'] != v['expected'] for v in probes),
                  prior_controls_preserved=10, prior_incorrect_acceptances_corrected=6,
                  prior_incorrect_rejections_corrected=2, new_assertions=len(checks)-start_count,
                  cases=cases, source_cases=source_cases,
                  scope='Document/reference only, including symbolic delivery/resume decisions; actual Git/API/CI/process/allocator/product NOT_RUN.')
    (run/'review-1.6.12-validation.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')


verify_review1612()
