"""Bounded pure governance reference; no Git/network/product implementation."""
from datetime import datetime, timezone
import uuid


def instant(value):
    """UTC seconds + exact fractional digits: no string timestamp order/rounding."""
    m = re.fullmatch(r'(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(?:\.(\d+))?(Z|[+-](?:[01]\d|2[0-3]):[0-5]\d)', value)
    if not m:
        raise ValueError('invalid RFC3339 instant')
    d = datetime.fromisoformat(m[1] + ('+00:00' if m[3] == 'Z' else m[3])).astimezone(timezone.utc)
    seconds = (d.date().toordinal() - datetime(1970, 1, 1).date().toordinal()) * 86400 + d.hour * 3600 + d.minute * 60 + d.second
    return seconds, (m[2] or '').rstrip('0')


def privacy_ok(r):
    return gv('GitRepositoryIdentity', r) and (r['visibility'] == 'private' or bool(r['publication_authority_ref']))


def typed(fs, ref, kind):
    value = load_member(fs, ref)
    if not gv(kind, value):
        raise ValueError('wrong typed evidence ' + kind)
    return value


def natural_keys(spec):
    context = spec['context'].casefold() if spec['kind'] == 'commit_status' else spec['context']
    prefix = (spec['kind'], context, spec['source_app'], spec['workflow_path'], spec['job_name'], C14(spec['matrix']))
    return {prefix + (event,) for event in spec['eligible_events']}


def plan_ok(pl):
    if not gv('GitCheckPlan', pl) or pl['required_set_status'] != 'VERIFIED' or not pl['canary_ref'] or not privacy_ok(pl['repository']):
        return False
    if not set(pl['closing_local_reuse_refs']) <= set(pl['local_check_refs']):
        return False
    specs = pl['checks'] + pl['merge_checks']
    if len({v['id'] for v in specs}) != len(specs):
        return False
    identities = set()
    for spec in specs:
        keys = natural_keys(spec)
        if identities & keys or len(spec['command_refs']) != len(set(spec['command_refs'])):
            return False
        identities.update(keys)
    return not any(x['checkout_binding'] == 'merge_group' for x in pl['checks']) and not any(x['checkout_binding'] != 'merge_group' for x in pl['merge_checks'])


def normalized_native(source):
    if not gv('GitCheckSourceEvidence', source):
        raise ValueError('native source shape')
    instant(source['created_at_utc'])
    provider = re.fullmatch(re.escape(source['host']) + r':(app|creator):([1-9][0-9]*)', source['source_app'])
    if not provider or provider[1] != ('creator' if source['source_kind']=='commit_status' else 'app'):
        raise ValueError('native App/creator identity')
    status, conclusion = source['native_status'], source['native_conclusion']
    if source['source_kind'] == 'commit_status':
        if source['run_id'] is not None or source['attempt'] is not None or source['job_id'] is not None or source['workflow_path'] is not None or source['job_name'] is not None:
            raise ValueError('invented status workflow fields')
        state = ('completed', 'success') if status == 'success' else ('completed', 'failure') if status in ['failure', 'error'] else ('waiting', 'unknown')
        if conclusion is not None:
            state = ('waiting', 'unknown')
        return { 'kind': 'commit_status', 'run_id': source['record_id'], 'attempt': 1, 'status': state[0], 'conclusion': state[1] }
    if source['source_kind'] == 'actions_check_run':
        if not source['run_id'] or source['attempt'] is None or source['job_id'] is None or not source['workflow_path'] or not source['job_name'] or source['event'] == 'external_app':
            raise ValueError('missing Actions workflow identity')
        rid, attempt_number = source['run_id'], source['attempt']
    else:
        if source['run_id'] is not None or source['attempt'] is not None or source['workflow_path'] is not None or source['job_name'] is not None or source['job_id'] is not None or source['event'] != 'external_app':
            raise ValueError('invented external App workflow fields')
        rid, attempt_number = source['record_id'], 1
    normalized = {'queued': 'queued', 'in_progress': 'in_progress', 'waiting': 'waiting', 'pending': 'waiting', 'requested': 'waiting', 'completed': 'completed'}.get(status, 'waiting')
    result = conclusion if status == 'completed' and conclusion in ['success', 'failure', 'cancelled', 'timed_out', 'action_required', 'skipped', 'neutral'] else 'unknown'
    if status != 'completed' and conclusion is not None:
        normalized, result = 'waiting', 'unknown'
    return {'kind': 'check_run', 'run_id': rid, 'attempt': attempt_number, 'status': normalized, 'conclusion': result}


def source_snapshot(source):
    """Pinned sanitized native projection; actual collection remains future T001/T003."""
    provider_id = int(source['source_app'].rsplit(':',1)[1])
    actions = source['source_kind']=='actions_check_run'
    if source['source_kind']=='commit_status':
        record = {'id':int(source['record_id']),'created_at':source['created_at_utc'],'state':source['native_status'],'context':source['context'],'creator':{'id':provider_id}}
    else:
        record = {'id':int(source['record_id']),'head_sha':source['reported_head_sha'],'name':source['context'],'status':source['native_status'],'conclusion':source['native_conclusion'],'app':{'id':provider_id}}
        if actions:record['check_suite']={'id':source['check_suite_id']}
        else:record['created_at']=source['created_at_utc']
    workflow = None if not actions else {'id':source['run_id'],'run_attempt':source['attempt'],'created_at':source['created_at_utc'],'event':source['event'],'path':source['workflow_path'],'head_sha':source['workflow_head_sha'],'check_suite_id':source['check_suite_id']}
    job = None if not actions else {'id':source['job_id'],'name':source['job_name'],'run_id':source['run_id'],'head_sha':source['job_head_sha'],'check_run_url':source['job_check_run_url']}
    job_scope=None if not actions else {'run_id':source['run_id'],'run_attempt':source['attempt'],'endpoint':source['job_check_run_url'].rsplit('/check-runs/',1)[0]+'/actions/runs/'+source['run_id']+'/attempts/'+str(source['attempt'])+'/jobs'}
    return {'kind':'github_source_snapshot','host':source['host'],'repository_id':source['repository_id'],'source_kind':source['source_kind'],'event':source['event'],'requested_sha':source['reported_head_sha'],'record':record,'workflow_run':workflow,'job':job,'job_query_scope':job_scope,'runner_matrix':source['matrix']}


def check_evidence_ok(pl, req, observed_check, subject, fs, require_success=True):
    source = typed(fs, observed_check['source_evidence_ref'], 'GitCheckSourceEvidence')
    normalized = normalized_native(source)
    if not exact_json_equal(source_snapshot(source), load_member(fs, source['raw_api_ref'])) or not source_graph_ok(pl, source, observed_check, subject):
        return False
    if source['host'] != pl['repository']['host'] or source['repository_id'] != pl['repository']['repository_id']:
        return False
    if any(observed_check[k] != normalized[k] for k in normalized):
        return False
    if instant(source['created_at_utc']) != instant(observed_check['run_created_at_utc']):
        return False
    if any(source[k] != observed_check[k] for k in ['source_app', 'context', 'workflow_path', 'job_name', 'job_id', 'matrix', 'event', 'reported_head_sha']):
        return False
    required_refs = {observed_check['source_evidence_ref'], source['raw_api_ref']}
    if observed_check['execution_evidence_ref'] is None:
        return not require_success and not observed_check['execution_verified'] and required_refs <= set(observed_check['evidence_refs']) and all(safe_rel(r) and bool(fs.get(r)) for r in observed_check['evidence_refs'])
    evidence = typed(fs, observed_check['execution_evidence_ref'], 'GitCheckExecutionEvidence')
    if evidence['check_id'] != req['id'] or evidence['subject_sha'] != subject or evidence['tested_checkout_sha'] != observed_check['tested_checkout_sha'] or evidence['source_evidence_ref'] != observed_check['source_evidence_ref']:
        return False
    commands = evidence['command_results']
    commands_set = {v['command_ref'] for v in commands}
    if len(commands_set) != len(commands) or not commands_set <= set(req['command_refs']):
        return False
    if require_success and (commands_set != set(req['command_refs']) or not observed_check['execution_verified'] or any(v['result'] != 'PASS' for v in commands)):
        return False
    if not all(v['revision'] == observed_check['tested_checkout_sha'] and safe_rel(v['log_ref']) and bool(fs.get(v['log_ref'])) for v in commands):
        return False
    required_refs |= {observed_check['execution_evidence_ref']} | {v['log_ref'] for v in commands}
    return required_refs <= set(observed_check['evidence_refs']) and all(safe_rel(r) and bool(fs.get(r)) for r in observed_check['evidence_refs'])


def checks_ok(pl, obs, subject, stage='delivery', group=None, current_group=None):
    """Shape/ordering/checkout predicate only; effective_done also verifies sources."""
    if not plan_ok(pl):
        return False
    specs = pl['checks'] if stage == 'delivery' else pl['merge_checks']
    if not specs:
        return False
    target = subject
    try:
        if any(not gv('GitObservedCheck', x) for x in obs) or not candidate_mapping_ok(specs, obs):
            return False
        if stage == 'merge':
            if not gv('GitMergeGroupBinding', group) or group != current_group or group['source_subject_sha'] != subject or group['repository_id'] != pl['repository']['repository_id'] or not group['authority_ref']:
                return False
            if not any(x['head_sha'] == subject and x['repository_id'] == group['repository_id'] for x in group['member_heads']):
                return False
            target = group['group_head_sha']
        for req in specs:
            relevant = [x for x in obs if x['check_id'] == req['id']]
            if not relevant:
                return False
            generations = {}
            identities = {}
            for x in relevant:
                time_key = instant(x['run_created_at_utc'])
                generation = int(x['run_id'])
                if generation < 1:
                    return False
                if generation in generations and generations[generation] != time_key:
                    return False
                generations[generation] = time_key
                key = (generation, x['attempt'])
                if key in identities and identities[key] != x:
                    return False
                identities[key] = x
            latest = max(relevant, key=lambda x: (instant(x['run_created_at_utc']), int(x['run_id']), x['attempt']))
            if any(latest[k] != req[k] for k in ['kind', 'source_app', 'workflow_path', 'job_name', 'matrix']):
                return False
            if (latest['context'].casefold() if req['kind']=='commit_status' else latest['context']) != (req['context'].casefold() if req['kind']=='commit_status' else req['context']):
                return False
            if latest['event'] not in req['eligible_events'] or latest['status'] != 'completed' or latest['conclusion'] != 'success' or not latest['execution_verified']:
                return False
            if latest['reported_head_sha'] != (target if req['reported_sha_binding'] == 'subject' else latest['tested_checkout_sha']):
                return False
            if req['checkout_binding'] in ['head', 'merge_group'] and latest['tested_checkout_sha'] != target:
                return False
            if req['checkout_binding'] == 'pr_merge' and (latest['pr_head_sha'] != subject or not latest['pr_base_sha'] or latest['tested_merge_sha'] != latest['tested_checkout_sha']):
                return False
        return True
    except (ValueError, KeyError, TypeError, OverflowError):
        return False


def local_evidence_ok(at, pl, fs, closing):
    try:
        records = {ref: typed(fs, ref, 'GitLocalCheckEvidence') for ref in at['local_evidence_refs']}
        if len(records) != len(at['local_evidence_refs']):
            return False
        expected = {(phase, command) for phase in ['payload', 'closing'] for command in pl['local_check_refs']}
        keys = [(v['phase'], v['command_ref']) for v in records.values()]
        if set(keys) != expected or len(keys) != len(expected):
            return False
        for ref, v in records.items():
            if any(v[k] != at[k] for k in ['task_id', 'task_revision', 'delivery_id']) or v['result'] != 'PASS' or not v['execution_verified'] or not all(safe_rel(x) and bool(fs.get(x)) for x in v['log_refs']):
                return False
            reused = v['reused_from_ref']
            if reused is not None:
                source = records.get(reused)
                if v['phase'] != 'closing' or v['command_ref'] not in pl['closing_local_reuse_refs'] or source is None or source['phase'] != 'payload' or source['reused_from_ref'] is not None or source['command_ref'] != v['command_ref'] or source['result'] != 'PASS' or source['revision'] != at['verified_payload_sha'] or v['revision'] != source['revision'] or v['log_refs']!=source['log_refs']:
                    return False
            elif v['revision'] != (at['verified_payload_sha'] if v['phase'] == 'payload' else closing):
                return False
        return True
    except (ValueError, KeyError, TypeError):
        return False


def selection_ok(sel, at, fs):
    try:
        if not gv('GitTaskDeliverySelection', sel) or sel['active_delivery_id'] != at['delivery_id'] or any(sel[k] != at[k] for k in ['assignment_ref', 'task_id', 'task_revision']):
            return False
        current, seen_refs, seen_ids = sel, set(), set()
        while True:
            if current['active_delivery_id'] is None or current['active_delivery_id'] in seen_ids:
                return False
            seen_ids.add(current['active_delivery_id'])
            previous_ref = current['previous_selection_ref']
            if current['task_revision'] == 1:
                return previous_ref is None and current['supersedes_delivery_id'] is None and current['invalidation_refs'] == []
            if not previous_ref or previous_ref in seen_refs or not current['invalidation_refs']:
                return False
            seen_refs.add(previous_ref)
            previous = typed(fs, previous_ref, 'GitTaskDeliverySelection')
            if any(previous[k] != current[k] for k in ['assignment_ref', 'task_id']) or previous['task_revision'] + 1 != current['task_revision'] or previous['active_delivery_id'] != current['supersedes_delivery_id'] or instant(previous['updated_at_utc']) > instant(current['updated_at_utc']):
                return False
            for ref in current['invalidation_refs']:
                inv = load_member(fs, ref)
                if inv.get('kind') != 'delivery_invalidation' or inv.get('task_id') != current['task_id'] or inv.get('assignment_ref') != current['assignment_ref'] or inv.get('old_revision') != previous['task_revision'] or inv.get('new_revision') != current['task_revision'] or inv.get('old_delivery_id') != previous['active_delivery_id'] or inv.get('new_delivery_id') != current['active_delivery_id'] or not inv.get('reason'):
                    return False
            current = previous
    except (ValueError, KeyError, TypeError):
        return False


def destination_ok(pl, d, subject, fs):
    try:
        if not gv('GitDestinationObservation', d) or not d['identity_verified'] or not d['visibility_verified'] or d['candidate_sha'] != subject or d['repository'] != pl['repository'] or not privacy_ok(d['repository']):
            return False
        op = typed(fs, d['operation_evidence_ref'], 'GitPushOperationEvidence')
        if op['push_operation_id'] != d['push_operation_id'] or op['candidate_sha'] != subject or op['credential_class'] != pl['credential_class'] or op['intervening_events']:
            return False
        pre, post = op['preflight'], op['postflight']
        if pre['query_id'] == post['query_id']:
            return False
        for read in [pre, post]:
            if read['lifecycle_id'] != op['lifecycle_id'] or read['retry_index'] != op['retry_index'] or read['candidate_sha'] != subject or read['repository'] != pl['repository'] or read['remote_config_digest'] != d['local_remote_config_digest']:
                return False
            raw = load_member(fs, read['raw_api_ref'])
            if not exact_json_equal(raw, {'kind': 'destination_api_snapshot', 'push_operation_id': op['push_operation_id'], **read, 'raw_api_ref': None}):
                return False
        times = [op['lifecycle_started_at_utc'], pre['started_at_utc'], pre['completed_at_utc'], op['push_started_at_utc'], op['push_completed_at_utc'], post['started_at_utc'], post['completed_at_utc'], op['deadline_at_utc']]
        if any(instant(a) > instant(b) for a, b in zip(times, times[1:])) or post['observed_remote_sha'] != subject:
            return False
        if instant(d['observed_at_utc']) != instant(pre['completed_at_utc']) or instant(d['push_started_at_utc']) != instant(op['push_started_at_utc']):
            return False
        command = typed(fs, op['command_record_ref'], 'GitCommandLifecycle')
        return push_lifecycle_ok(pl, d, subject, op, command)
    except (ValueError, KeyError, TypeError):
        return False


def pr_ok(pl, o, parents, fs, current, offline):
    required = any(x['checkout_binding'] == 'pr_merge' for x in pl['checks'])
    if not required:
        return o['pull_request_binding_ref'] is None
    binding = typed(fs, o['pull_request_binding_ref'], 'GitPullRequestBinding')
    if binding['head_sha'] != o['subject_sha'] or binding['host'] != pl['repository']['host'] or binding['repository_id'] != pl['repository']['repository_id'] or parents.get(binding['tested_merge_sha']) != [binding['base_sha'], binding['head_sha']]:
        return False
    if not pr_source_ok(binding, fs):
        return False
    if not offline:
        if current is None or o['phase'] not in current:
            return False
        observed_now = current[o['phase']]
        if not pr_source_ok(observed_now, fs):
            return False
        if any(observed_now.get(k) != binding[k] for k in ['host', 'repository_id', 'head_repository_id', 'pull_request_number', 'head_ref', 'base_ref', 'head_sha', 'base_sha', 'tested_merge_sha']):
            return False
        if instant(observed_now['observed_at_utc']) < instant(binding['observed_at_utc']):
            return False
    for req in pl['checks']:
        if req['checkout_binding'] == 'pr_merge':
            v = max([x for x in o['checks'] if x['check_id'] == req['id']],key=lambda x:(instant(x['run_created_at_utc']),int(x['run_id']),x['attempt']))
            if v['pr_head_sha'] != binding['head_sha'] or v['pr_base_sha'] != binding['base_sha'] or v['tested_merge_sha'] != binding['tested_merge_sha'] or v['tested_checkout_sha'] != binding['tested_merge_sha']:
                return False
    return True


def observation_checks_ok(pl, o, fs):
    if not all(native_observed_ok(pl,value,o['subject_sha'],fs) for value in o['checks']) or not checks_ok(pl, o['checks'], o['subject_sha']):
        return False
    for req in pl['checks']:
        candidates = [x for x in o['checks'] if x['check_id'] == req['id']]
        latest = max(candidates,key=lambda x:(instant(x['run_created_at_utc']),int(x['run_id']),x['attempt']))
        for value in candidates:
            if not check_evidence_ok(pl, req, value, o['subject_sha'], fs,require_success=value==latest):
                return False
    collection=typed(fs,o['collection_evidence_ref'],'GitCICollectionEvidence')
    return collection_ok(pl,o,collection,fs,collection['started_at_utc'],o['observed_at_utc'])


def canary_ok(at, pl, po, co, fs, extra_observations=None):
    ref = pl['canary_ref']
    if ref == 'delivery:' + at['delivery_id'] + ':payload':
        canary_plan, canary_observation = pl, po
    else:
        if ref.startswith('delivery:') or at['task_id'] == 'T001' and pl['phase'] == 'bootstrap':
            return False
        canary = typed(fs, ref, 'GitCanaryEvidence')
        if canary['credential_class'] != pl['credential_class']:
            return False
        canary_plan = typed(fs, canary['check_plan_ref'], 'GitCheckPlan')
        canary_observation = typed(fs, canary['observation_ref'], 'GitDeliveryObservation')
        if canary_observation['delivery_id']==at['delivery_id']:
            return False
        if not pr_ok(canary_plan,canary_observation,load_member(fs,canary['git_evidence_ref']),fs,None,True):
            return False
    if canary_plan['credential_class'] != pl['credential_class'] or any(canary_plan['repository'][k] != pl['repository'][k] for k in ['host', 'repository_id']) or canary_observation['phase'] != 'payload' or canary_observation['result'] != 'PASS' or canary_observation['check_plan_sha256'] != hashlib.sha256(C14(canary_plan)).hexdigest() or not canary_observation['binding_verified'] or not canary_observation['required_set_verified'] or canary_observation['blocker'] is not None or canary_observation['observed_remote_sha']!=canary_observation['subject_sha'] or canary_observation['merge_group_binding'] is not None:
        return False
    if not observation_checks_ok(canary_plan, canary_observation, fs) or not destination_ok(canary_plan, canary_observation['destination_observation'], canary_observation['subject_sha'], fs):
        return False
    if not phase_receipt_time_ok(canary_observation,fs) or instant(canary_observation['observed_at_utc'])>instant(po['observed_at_utc']):return False
    proven_events = canary_proven_events(canary_plan,canary_observation,fs)
    extras = extra_observations or []
    used_events = {v['event'] for o in [po, co] + [o for o, _ in extras] for v in selected_required(pl,o)}
    return used_events <= proven_events and native_ledger_ok([(canary_observation,fs),(po,fs),(co,fs)] + extras)


def archive_done(at, pl, ob, ar, fs, candidates, changes, live_remote, offline=False, sel=None, seal_record=None, published=False, current_pr=None):
    # Historical receipt validation only; never a live/final PASS by itself.
    try:
        if sel is None or seal_record is None:
            return False
        resolved = resolve(at, candidates)
        if not published or not resolved or not closing_diff_ok(changes,task_id=at['task_id']) or not archive_ok(ar, fs, seal_record) or not selection_ok(sel, at, fs):
            return False
        if any(at[k] != ar[k] for k in ['assignment_ref', 'task_id', 'task_revision', 'delivery_id']):
            return False
        if at['check_plan_sha256'] != hashlib.sha256(C14(pl)).hexdigest() or ar['check_plan_sha256'] != at['check_plan_sha256']:
            return False
        if typed(fs, at['check_plan_ref'], 'GitCheckPlan') != pl or typed(fs, ar['attempt_ref'], 'GitDeliveryAttempt') != at:
            return False
        co = typed(fs, ar['closing_observation_ref'], 'GitDeliveryObservation')
        po = typed(fs, ar['payload_observation_ref'], 'GitDeliveryObservation')
        if co != ob or at['payload_observation_ref'] != ar['payload_observation_ref'] or typed(fs, ar['selection_ref'], 'GitTaskDeliverySelection') != sel:
            return False
        parents = load_member(fs, ar['git_evidence_ref'])
        commits = at['ordered_commits']
        if not commits or commits[-1]['sha'] != at['verified_payload_sha']:
            return False
        if at['payload_mode'] == 'verified_noop':
            if len(commits) != 1 or at['base_sha'] != at['verified_payload_sha'] or at['verified_payload_sha'] not in parents:
                return False
        else:
            previous = at['base_sha']
            for commit in commits:
                if parents.get(commit['sha']) != ([previous] if previous else []):
                    return False
                previous = commit['sha']
        if parents.get(resolved) != [at['verified_payload_sha']] or not local_evidence_ok(at, pl, fs, resolved):
            return False
        for o, phase, subject in [(po, 'payload', at['verified_payload_sha']), (co, 'closing', resolved)]:
            if o['phase'] != phase or o['delivery_id'] != at['delivery_id'] or o['subject_sha'] != subject or o['observed_remote_sha'] != subject or o['check_plan_sha256'] != at['check_plan_sha256'] or o['result'] != 'PASS' or o['blocker'] is not None or not o['binding_verified'] or not o['required_set_verified'] or o['merge_group_binding'] is not None:
                return False
            if not destination_ok(pl, o['destination_observation'], subject, fs) or not observation_checks_ok(pl, o, fs) or not pr_ok(pl, o, parents, fs, None, True):
                return False
        if not native_ledger_ok([(po,fs),(co,fs)]) or po['destination_observation']['push_operation_id'] == co['destination_observation']['push_operation_id'] or co['parent_sha'] != at['verified_payload_sha'] or ar['closing_sha'] != resolved or ar['verified_payload_sha'] != at['verified_payload_sha'] or not canary_ok(at, pl, po, co, fs):
            return False
        return True
    except (ValueError, KeyError, TypeError, OverflowError):
        return False


def checkpoint_ok(value, selector, actual, fs):
    try:
        if not gv('GitExecutionCheckpoint', value):
            return False
        for key in ['assignment_ref', 'local_branch', 'head_sha', 'working_tree_digest', 'index_digest']:
            if value[key] != actual[key]:
                return False
        if value['task_id'] is None:
            return selector is None and all(value[k] is None for k in ['task_revision', 'delivery_id', 'planned_archive_path', 'command_record_ref', 'operation_id']) and value['command_state'] == actual['command_state'] == 'NOT_STARTED' and actual['operation_id'] is None
        if not gv('GitTaskDeliverySelection', selector) or any(value[k] != selector[k] for k in ['assignment_ref', 'task_id', 'task_revision']) or value['delivery_id'] != selector['active_delivery_id']:
            return False
        expected_path = None if selector['active_delivery_id'] is None else 'artifacts/git-delivery/' + selector['active_delivery_id']
        if value['planned_archive_path'] != expected_path:
            return False
        if value['command_record_ref'] is None or value['operation_id'] is None:
            return value['command_record_ref'] is None and value['operation_id'] is None and value['command_state'] == 'NOT_STARTED' and actual['command_state'] == 'NOT_STARTED' and actual['operation_id'] is None
        command = typed(fs, value['command_record_ref'], 'GitCommandLifecycle')
        return lifecycle_ok(command) and all(command[k] == value[k] for k in ['assignment_ref', 'operation_id', 'task_id', 'task_revision', 'delivery_id', 'command_state']) and value['command_state'] == actual['command_state'] and value['operation_id'] == actual['operation_id']
    except (ValueError, KeyError, TypeError):
        return False


def put_check_evidence(fs, check_value, subject, phase, req=check, repository=repo, source_kind='actions_check_run'):
    prefix = 'proof-' + phase + '-' + check_value['check_id'] + '-' + check_value['run_id'] + '-' + str(check_value['attempt'])
    sr, er, rawref, logref = [prefix + x for x in ['-source.json', '-execution.json', '-api.json', '.log']]
    source = {'format_version': 1, 'kind': 'check_source', 'source_kind': source_kind, 'host': repository['host'], 'repository_id': repository['repository_id'], 'record_id': check_value['run_id'], 'run_id': check_value['run_id'] if source_kind == 'actions_check_run' else None, 'job_id': check_value['job_id'], 'attempt': check_value['attempt'] if source_kind == 'actions_check_run' else None, 'created_at_utc': check_value['run_created_at_utc'], 'source_app': check_value['source_app'], 'context': check_value['context'], 'workflow_path': check_value['workflow_path'], 'job_name': check_value['job_name'], 'matrix': check_value['matrix'], 'event': check_value['event'], 'reported_head_sha': check_value['reported_head_sha'], 'native_status': check_value['status'] if source_kind != 'commit_status' else 'success', 'native_conclusion': check_value['conclusion'] if source_kind != 'commit_status' else None, 'raw_api_ref': rawref}
    actions = source_kind == 'actions_check_run'
    api = 'https://api.github.com' if repository['host']=='github.com' else 'https://'+repository['host']+'/api/v3'
    source.update(check_suite_id=check_value['run_id'] if actions else None,workflow_head_sha=subject if actions else None,job_head_sha=subject if actions else None,job_check_run_url=api+'/repos/'+repository['owner']+'/'+repository['name']+'/check-runs/'+source['record_id'] if actions else None)
    execution = {'format_version': 1, 'kind': 'check_execution', 'check_id': check_value['check_id'], 'subject_sha': subject, 'tested_checkout_sha': check_value['tested_checkout_sha'], 'source_evidence_ref': sr, 'command_results': [{'command_ref': command, 'revision': check_value['tested_checkout_sha'], 'result': 'PASS', 'log_ref': logref} for command in req['command_refs']]}
    if source_kind != 'commit_status' and check_value['status'] != 'completed':
        source['native_conclusion'] = None
    fs[sr], fs[rawref] = C14(source), C14(source_snapshot(source))
    if check_value['status'] != 'completed' or not check_value['execution_verified']:
        check_value.update(source_evidence_ref=sr,execution_evidence_ref=None,evidence_refs=[sr,rawref],execution_verified=False)
    else:
        fs[er],fs[logref]=C14(execution),b'reference command execution log'
        check_value.update(source_evidence_ref=sr, execution_evidence_ref=er, evidence_refs=[sr, er, rawref, logref])


def put_push_evidence(fs, d, credential='local_user'):
    opid, subject = d['push_operation_id'], d['candidate_sha']
    life = str(uuid.uuid5(uuid.UUID(opid), 'lifecycle'))
    prefix = 'push-' + opid
    query = lambda role: str(uuid.uuid5(uuid.UUID(opid), role))
    def read(role, start, end, remote):
        ref = prefix + '-' + role + '.json'
        return {'query_id': query(role), 'lifecycle_id': life, 'retry_index': 0, 'candidate_sha': subject, 'repository': copy.deepcopy(d['repository']), 'remote_config_digest': d['local_remote_config_digest'], 'started_at_utc': start, 'completed_at_utc': end, 'observed_remote_sha': remote, 'raw_api_ref': ref}
    prestart = now if subject==C else before
    d['observed_at_utc']=prestart
    pre = read('pre', prestart, prestart, None)
    post = read('post', now, now, subject)
    op = {'format_version': 1, 'kind': 'push_operation', 'push_operation_id': opid, 'lifecycle_id': life, 'retry_index': 0, 'candidate_sha': subject, 'credential_class': credential, 'command_record_ref': prefix + '-command.json', 'lifecycle_started_at_utc': prestart, 'deadline_at_utc': '2026-10-15T03:01:00Z', 'push_started_at_utc': now, 'push_completed_at_utc': now, 'intervening_events': [], 'preflight': pre, 'postflight': post}
    command = command_fixture(op=op,destination=d)
    for read_value in [pre, post]:
        fs[read_value['raw_api_ref']] = C14({'kind': 'destination_api_snapshot', 'push_operation_id': opid, **read_value, 'raw_api_ref': None})
    fs[op['command_record_ref']] = C14(command)
    d['operation_evidence_ref'] = prefix + '-operation.json'
    fs[d['operation_evidence_ref']] = C14(op)
    return op


exec(compile((run/'delivery167.py').read_text(encoding='utf-8'),str(run/'delivery167.py'),'exec'))
exec(compile((run/'fixture_support167.py').read_text(encoding='utf-8'),str(run/'fixture_support167.py'),'exec'))
exec(compile((run/'delivery168.py').read_text(encoding='utf-8'),str(run/'delivery168.py'),'exec'))
exec(compile((run/'fixture_support168.py').read_text(encoding='utf-8'),str(run/'fixture_support168.py'),'exec'))
exec(compile((run/'delivery169.py').read_text(encoding='utf-8'),str(run/'delivery169.py'),'exec'))
exec(compile((run/'fixture_support169.py').read_text(encoding='utf-8'),str(run/'fixture_support169.py'),'exec'))
exec(compile((run/'delivery1610.py').read_text(encoding='utf-8'),str(run/'delivery1610.py'),'exec'))
exec(compile((run/'fixture_support1610.py').read_text(encoding='utf-8'),str(run/'fixture_support1610.py'),'exec'))
exec(compile((run/'delivery1611.py').read_text(encoding='utf-8'),str(run/'delivery1611.py'),'exec'))
exec(compile((run/'fixture_support1611.py').read_text(encoding='utf-8'),str(run/'fixture_support1611.py'),'exec'))
exec(compile((run/'delivery1612.py').read_text(encoding='utf-8'),str(run/'delivery1612.py'),'exec'))
exec(compile((run/'delivery_protocol1612.py').read_text(encoding='utf-8'),str(run/'delivery_protocol1612.py'),'exec'))

# Explicit positive source fixtures, kept distinct from evaluator predicates.
plan['pull_request_flow']=None
attempt['noop_reason_ref']=None
check['source_app']=repo['host']+':app:15368'
ph=hashlib.sha256(C14(plan)).hexdigest()
for record in [attempt,archive,payload_obs,observation]:record['check_plan_sha256']=ph
files['plan.json']=C14(plan)
selection['previous_selection_ref'] = None
attempt['local_evidence_refs'] = ['local.json', 'local-closing.json']
local = {'format_version': 1, 'kind': 'local_check', 'command_ref': plan['local_check_refs'][0], 'task_id': 'T001', 'task_revision': 1, 'delivery_id': U, 'phase': 'payload', 'revision': P, 'result': 'PASS', 'execution_verified': True, 'log_refs': ['local-p.log'], 'reused_from_ref': None}
local_closing = {**copy.deepcopy(local), 'phase': 'closing', 'revision': C, 'log_refs': ['local-c.log']}
files['local.json'], files['local-closing.json'] = C14(local), C14(local_closing)
files['local-p.log'], files['local-c.log'] = b'payload local check PASS', b'closing local check PASS'
for o in [payload_obs, observation]:
    o['pull_request_binding_ref'] = None
    for value in o['checks']:
        value['source_app']=check['source_app']
        put_check_evidence(files, value, o['subject_sha'], o['phase'])
    put_push_evidence(files, o['destination_observation'])
    make_collection_fixture(plan,o,files)
observed = copy.deepcopy(observation['checks'][0])
install_commit_fixtures(attempt,archive,files)
files['attempt.json'], files['selection.json'], files['payload.json'], files['closing.json'] = C14(attempt), C14(selection), C14(payload_obs), C14(observation)
archive['files'] = manifest_for(files)
seal = seal_for(archive)
